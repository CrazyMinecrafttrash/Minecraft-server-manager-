'use strict';
// LAUNCHME: sets up (first run only), starts the site in the background, then checks that it really answers.
//   node launchme.js                 first run asks 3 questions, later runs just start/check it
//   node launchme.js --status        is it up?
//   node launchme.js --stop          stop it
//   node launchme.js --ip 1.2.3.4 --port 25569 --email you@example.com   skip the questions
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');
const readline = require('node:readline');
const { spawn, spawnSync } = require('node:child_process');

const root = __dirname;
const envFile = path.join(root, '.env');
const dataDir = path.join(root, 'data');
const pidFile = path.join(dataDir, 'server.pid');
const logFile = path.join(dataDir, 'server.log');

const args = process.argv.slice(2);
const flag = (n) => args.includes(`--${n}`);
const opt = (n) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : undefined; };

const [maj, min] = process.versions.node.split('.').map(Number);
if (maj < 22 || (maj === 22 && min < 13)) {
  console.error(`Node.js 22.13 or newer is needed (this is ${process.versions.node}). Get it from https://nodejs.org`);
  process.exit(1);
}

function ask(question, dflt) {
  if (!process.stdin.isTTY) return Promise.resolve(dflt);
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(`${question}${dflt ? ` [${dflt}]` : ''}: `, (a) => { rl.close(); resolve(a.trim() || dflt); });
  });
}
const run = (script, extraEnv = {}) => spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', ...script], {
  cwd: root, stdio: 'inherit', env: { ...process.env, ...extraEnv },
}).status;

function readEnv() {
  const out = {};
  if (!fs.existsSync(envFile)) return out;
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

// Asks the running site (from this machine) whether it and its database answer.
function probe(env) {
  const port = Number(env.PORT || 3000);
  const secure = Boolean(env.TLS_CERT_FILE);
  const started = Date.now();
  return new Promise((resolve) => {
    const req = (secure ? https : http).get({ host: '127.0.0.1', port, path: '/healthz', timeout: 3000, rejectUnauthorized: false }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => {
        try { const j = JSON.parse(body); resolve({ up: res.statusCode === 200 && j.ok === true, ms: Date.now() - started, uptimeSec: j.uptimeSec }); }
        catch { resolve({ up: false }); }
      });
    });
    req.on('error', () => resolve({ up: false }));
    req.on('timeout', () => { req.destroy(); resolve({ up: false }); });
  });
}

function banner(lines) {
  const w = Math.max(...lines.map((l) => l.length)) + 4;
  const bar = '='.repeat(w);
  console.log(`\n${bar}\n${lines.map((l) => `  ${l}`).join('\n')}\n${bar}\n`);
}

function isRunning() {
  try { process.kill(Number(fs.readFileSync(pidFile, 'utf8')), 0); return true; } catch { return false; }
}

async function waitUntilUp(env, seconds) {
  for (let i = 0; i < seconds * 2; i++) {
    const r = await probe(env);
    if (r.up) return r;
    await new Promise((r2) => setTimeout(r2, 500));
  }
  return { up: false };
}

(async () => {
  if (flag('stop')) {
    if (!isRunning()) { console.log('The site is not running.'); return; }
    process.kill(Number(fs.readFileSync(pidFile, 'utf8')), 'SIGTERM');
    fs.rmSync(pidFile, { force: true });
    console.log('Stopped.');
    return;
  }

  if (flag('status')) {
    const env = readEnv();
    const r = await probe(env);
    if (r.up) banner(['SERVER IS UP', `Website: ${env.APP_URL}`, `Up for ${r.uptimeSec} seconds`]);
    else banner(['SERVER IS NOT RUNNING', 'Start it with:  node launchme.js']);
    process.exit(r.up ? 0 : 1);
  }

  // 1. first-time setup: settings, secret key and HTTPS certificate
  if (!fs.existsSync(envFile)) {
    console.log('\nFirst-time setup (asked only once). Press Enter to accept the suggestion.\n');
    const ip = opt('ip') || await ask('Public IP address or domain of this server', '104.254.222.120');
    const port = opt('port') || await ask('Port to use', '25569');
    const email = opt('email') || await ask('Your admin email', 'kyle.king1106@gmail.com');
    if (run(['scripts/setup-server.js', ip, String(port), email]) !== 0) process.exit(1);
  }
  const env = readEnv();

  // 2. an admin account (the person types a password; it is never stored in a file)
  process.loadEnvFile(envFile);
  const { loadConfig } = require('./src/config');
  const { openDb, createStore } = require('./src/db');
  const config = loadConfig();
  fs.mkdirSync(config.downloadsDir, { recursive: true });
  const db = openDb(config.dbFile);
  const store = createStore(db);
  const owner = config.ownerEmails[0];
  const existing = owner ? store.getUserByEmail(owner) : null;
  const haveAdmin = Boolean(existing && existing.passwordHash);
  db.close();
  if (!haveAdmin) {
    console.log(`\nNow choose a password for your admin account (${owner}). At least 10 characters.\n`);
    let ok = false;
    for (let i = 0; i < 3 && !ok; i++) ok = run(['scripts/create-admin.js'], { ADMIN_EMAIL: owner }) === 0;
    if (!ok) { console.error('Could not create the admin account. Run:  npm run create-admin'); process.exit(1); }
  }

  // 3. start it in the background, then prove it answers
  if (isRunning() && (await probe(env)).up) {
    console.log('It was already running.');
  } else {
    fs.mkdirSync(dataDir, { recursive: true });
    const log = fs.openSync(logFile, 'a');
    const child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/index.js'], {
      cwd: root, detached: true, windowsHide: true, stdio: ['ignore', log, log], env: process.env,
    });
    child.unref();
    fs.writeFileSync(pidFile, String(child.pid));
    console.log('Starting the site...');
  }

  const result = await waitUntilUp(env, 20);
  if (result.up) {
    banner([
      'SERVER IS UP',
      '',
      `Website:   ${env.APP_URL}`,
      `Admin:     ${env.APP_URL}/admin/login.html`,
      `Health:    OK, database OK (answered in ${result.ms} ms)`,
      '',
      'It keeps running after you close this window.',
      'Check it any time:  node launchme.js --status',
      'Stop it:            node launchme.js --stop',
      `Log file:           ${path.relative(process.cwd(), logFile) || logFile}`,
    ]);
    console.log(`Remember: open TCP port ${env.PORT} in your firewall so other people can reach it.`);
    if (env.TLS_CERT_FILE) console.log('Your browser will show a one-time certificate warning (normal for an IP address).');
  } else {
    banner(['SERVER DID NOT START', 'Last lines of the log:']);
    try { console.log(fs.readFileSync(logFile, 'utf8').split('\n').slice(-25).join('\n')); } catch { /* no log yet */ }
    process.exit(1);
  }
})().catch((err) => { console.error(err.message); process.exit(1); });
