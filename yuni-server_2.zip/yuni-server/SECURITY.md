# Security guide

The website code is only one layer. Most break-ins happen through the server, a reused password or a
hijacked email account, so please work through this whole list before going public.

## What the site already does

| Threat | Protection |
|---|---|
| Stolen admin password | Admins must also enter a code from an authenticator app (2FA). Without it they only have member rights. |
| Hijacked Google/Discord account | Same: signing in with Google/Discord still needs the 2FA code for admin rights. |
| Attacker enrols their own 2FA with a stolen password | When email is set up, turning on 2FA also needs a code sent to the admin's inbox. Owners get an email when anyone turns 2FA on. |
| Someone uses an admin's open/stolen session | Dangerous actions (saving site settings or download links, adding/removing admins, deleting accounts, new recovery codes) need a 2FA code from the last 15 minutes. Admin sessions end after 30 minutes idle / 12 hours. |
| Guessing passwords or 2FA codes | Lock-outs after 5 wrong tries (15 min), per-IP rate limits, the same answer whether or not an account exists. |
| Replaying a code someone saw | Each 2FA code works once. |
| Leaked or reused passwords | Minimum 10 characters, common passwords refused, passwords from known data breaches refused (Have I Been Pwned, privacy-preserving). Passwords are hashed with scrypt. |
| Stolen database or backup | No plain passwords, session tokens are hashed, recovery codes are hashed, 2FA secrets are encrypted with `SECRET_KEY` (which is not in the database). |
| Cross-site attacks (CSRF, clickjacking, XSS) | Same-site cookies, origin checks, per-session CSRF tokens, strict Content-Security-Policy with no inline scripts, all user text escaped, framing blocked. |
| Fake download links (malware) | Only http(s)/relative links allowed; changing them needs a fresh 2FA code; every change is in the activity log with who and when. |
| Silent takeover | Owners get alert emails for: new admin, admin removed, 2FA turned on, 2FA locked, recovery code used, admin sign-in from a new IP, admin locked out, admin password changed. |

Run **`npm run security-check`** any time to check your settings.

- Early-access server addresses are filtered on the server per viewer (responses are `private` and vary by cookie). Supporter changes and the CSV export need a recent 2FA code and are audited. The CSV contains emails, so treat the file as private.

## Before going public: server checklist

**1. Accounts that control everything — do these first**
- Turn on 2FA for: your **email account** (it can reset everything), your **domain registrar**, your **hosting provider**, Cloudflare (if used), and your Google/Discord accounts.
- Use a password manager. Never reuse the server, email or admin passwords anywhere.

**2. SSH (how you log in to the server)**
- Log in with an SSH key, not a password. Then in `/etc/ssh/sshd_config` set `PasswordAuthentication no` and `PermitRootLogin no`, and restart ssh.
- Install fail2ban: `sudo apt install fail2ban` (blocks IPs that keep guessing).
- Use a normal user with `sudo`, not root. (Being in the `docker` group is equivalent to root, so only give it to people you would give root.)

**3. Firewall**
```
sudo ufw default deny incoming
sudo ufw allow OpenSSH
sudo ufw allow 80,443/tcp
sudo ufw enable
```
Docker-published ports skip ufw, which is why only Caddy (80/443) is published and the app (3000) is not. Do not add a `ports:` line to the `app` service. If you also host Minecraft on this machine, open only the game ports you need.

**4. Updates**
- `sudo apt install unattended-upgrades` (automatic security updates for the OS).
- Update the site's containers monthly: `docker compose pull && docker compose up -d --build`.

**5. Secrets**
- `chmod 600 .env`. Never commit it, paste it in Discord, or put it in a screenshot.
- Keep a copy of `SECRET_KEY` somewhere safe (password manager), separate from database backups. If it is lost, every admin must reset 2FA (`npm run reset-2fa`).
- If a secret leaks: create new Google/Discord client secrets and a new SMTP password, update `.env`, restart.

**6. Email (strongly recommended)**
Without SMTP settings there are no security alerts, no email verification and no password reset. Use a sender address on your own domain and set up SPF/DKIM so alerts do not land in spam.

**7. Backups**
`npm run backup` daily (see README), then copy the files off the server — encrypted (e.g. `restic` or `gpg`). Test restoring once. Backups contain password hashes, so treat them as sensitive.

**8. Downloads**
Scan every modpack zip before uploading (e.g. VirusTotal). Only upload files you built or got from the original author.

**9. Your Minecraft servers** (often the real target)
Keep the server software and plugins updated, use a whitelist or proper auth (`online-mode=true`), never expose RCON or the query port to the internet unless needed, and give panel/console access only to people who need it, each with their own login and 2FA.

## If you think you have been hacked

1. Run `npm run revoke-sessions` (signs everyone out everywhere).
2. Look at Admin panel → Overview → Recent activity, and `docker compose logs app`.
3. Check Accounts → Admins: remove anyone who should not be there. Check Modpacks for changed download links.
4. Change the email password, server password/SSH keys, Google/Discord client secrets and SMTP password; update `.env`; restart.
5. If an admin's phone or recovery codes may be compromised: `npm run reset-2fa -- their@email` and have them set it up again.
6. Restore from a backup made before the break-in if data was changed.

## Lost your phone?
Sign in and use one of your recovery codes, then go to Accounts → Your security → *Make new recovery codes* and set up your new phone (`npm run reset-2fa -- you@email` from the server if you have no codes left).
