'use strict';
// Makes a self-signed TLS certificate for an IP address or hostname, so the site can use HTTPS without a proxy.
//   node scripts/make-cert.js 104.254.222.120
// Pure Node.js: nothing else has to be installed (works on Windows, Linux and macOS).
const crypto = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');

// ── a tiny DER (ASN.1) writer, just enough for an X.509 certificate ──
const len = (n) => {
  if (n < 0x80) return Buffer.from([n]);
  const bytes = [];
  for (let v = n; v > 0; v = Math.floor(v / 256)) bytes.unshift(v & 0xff);
  return Buffer.from([0x80 | bytes.length, ...bytes]);
};
const tlv = (tag, ...parts) => { const body = Buffer.concat(parts); return Buffer.concat([Buffer.from([tag]), len(body.length), body]); };
const seq = (...p) => tlv(0x30, ...p);
const set = (...p) => tlv(0x31, ...p);
const octets = (b) => tlv(0x04, b);
const nul = () => Buffer.from([0x05, 0x00]);
const bool = (v) => tlv(0x01, Buffer.from([v ? 0xff : 0x00]));
const int = (buf) => { let b = Buffer.from(buf); while (b.length > 1 && b[0] === 0 && !(b[1] & 0x80)) b = b.subarray(1); if (b[0] & 0x80) b = Buffer.concat([Buffer.from([0]), b]); return tlv(0x02, b); };
const oid = (dotted) => {
  const n = dotted.split('.').map(Number);
  const out = [n[0] * 40 + n[1]];
  for (const v of n.slice(2)) {
    const chunk = [v & 0x7f];
    for (let x = Math.floor(v / 128); x > 0; x = Math.floor(x / 128)) chunk.unshift((x & 0x7f) | 0x80);
    out.push(...chunk);
  }
  return tlv(0x06, Buffer.from(out));
};
const utcTime = (d) => tlv(0x17, Buffer.from(d.toISOString().replace(/[-:T]/g, '').slice(2, 14) + 'Z', 'ascii'));

function ipBytes(address) {
  if (net.isIPv4(address)) return Buffer.from(address.split('.').map(Number));
  const [head, tail = ''] = address.split('::');
  const h = head ? head.split(':') : [];
  const t = tail ? tail.split(':') : [];
  const groups = [...h, ...Array(8 - h.length - t.length).fill('0'), ...t];
  return Buffer.concat(groups.map((g) => { const b = Buffer.alloc(2); b.writeUInt16BE(parseInt(g, 16)); return b; }));
}

const SHA256_RSA = () => seq(oid('1.2.840.113549.1.1.11'), nul());
const pem = (label, der) => `-----BEGIN ${label}-----\n${der.toString('base64').match(/.{1,64}/g).join('\n')}\n-----END ${label}-----\n`;

function buildCertificate(address, keyPair) {
  const isIp = net.isIP(address) !== 0;
  const name = seq(set(seq(oid('2.5.4.3'), tlv(0x0c, Buffer.from(address)))));
  const now = Date.now();
  const san = isIp ? tlv(0x87, ipBytes(address)) : tlv(0x82, Buffer.from(address, 'ascii'));
  const ext = (id, value, critical) => seq(oid(id), ...(critical ? [bool(true)] : []), octets(value));
  const extensions = tlv(0xa3, seq(
    ext('2.5.29.17', seq(san), false),                              // subjectAltName
    ext('2.5.29.19', seq(), true),                                  // basicConstraints: not a CA
    ext('2.5.29.15', Buffer.from([0x03, 0x02, 0x05, 0xa0]), true),  // keyUsage: digitalSignature, keyEncipherment
    ext('2.5.29.37', seq(oid('1.3.6.1.5.5.7.3.1')), false),         // extendedKeyUsage: serverAuth
  ));
  const tbs = seq(
    tlv(0xa0, int(Buffer.from([2]))),                               // version 3
    int(Buffer.concat([Buffer.from([0x01]), crypto.randomBytes(15)])), // serial number
    SHA256_RSA(),
    name,
    seq(utcTime(new Date(now - 5 * 60 * 1000)), utcTime(new Date(now + 365 * 24 * 3600 * 1000))),
    name,
    keyPair.publicKey.export({ type: 'spki', format: 'der' }),
    extensions,
  );
  const sig = crypto.sign('sha256', tbs, keyPair.privateKey);
  return seq(tbs, SHA256_RSA(), tlv(0x03, Buffer.concat([Buffer.from([0]), sig])));
}

function makeCert(address, dir) {
  if (!address || (!net.isIP(address) && !/^[A-Za-z0-9.-]+$/.test(address))) throw new Error('Give an IP address or hostname, e.g. 104.254.222.120');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const keyPair = crypto.generateKeyPairSync('rsa', { modulusLength: 3072 });
  const der = buildCertificate(address, keyPair);
  const key = path.join(dir, 'key.pem');
  const cert = path.join(dir, 'cert.pem');
  fs.writeFileSync(key, keyPair.privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  try { fs.chmodSync(key, 0o600); } catch { /* not supported on every system */ }
  fs.writeFileSync(cert, pem('CERTIFICATE', der));
  const fingerprint = new crypto.X509Certificate(der).fingerprint256;
  return { key, cert, fingerprint };
}

module.exports = { makeCert };

if (require.main === module) {
  try {
    const out = makeCert(process.argv[2], path.join(__dirname, '..', 'data', 'tls'));
    console.log(`Certificate written to ${out.cert}\nKey written to ${out.key}\nSHA-256 fingerprint (compare it with what your browser shows):\n  ${out.fingerprint}`);
  } catch (err) { console.error(err.message); process.exit(1); }
}
