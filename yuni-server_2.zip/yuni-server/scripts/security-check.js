'use strict';
// Checks this installation for common security mistakes.  npm run security-check
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const envFile = process.env.ENV_FILE || path.join(root, '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { checkInstallation } = require('../src/checks');
let config;
try {
  config = require('../src/config').loadConfig();
} catch (err) {
  console.log(`FAIL  ${err.message}`);
  process.exit(1);
}
const results = checkInstallation(config, { envFile });

let db = null;
try {
  const { openDb, createStore } = require('../src/db');
  db = openDb(config.dbFile);
  const store = createStore(db);
  for (const a of store.listAdmins()) {
    const u = store.getUserByEmail(a.email);
    if (!u) results.push({ level: 'info', msg: `Admin ${a.email} has not signed in yet.` });
    else if (!u.totpEnabled) results.push({ level: 'warn', msg: `Admin ${a.email} has not set up two-factor sign-in yet.` });
  }
} catch (err) {
  results.push({ level: 'warn', msg: `Could not open the database: ${err.message}` });
} finally { if (db) db.close(); }

const icon = { ok: ' OK ', info: 'INFO', warn: 'WARN', fail: 'FAIL' };
for (const r of results) console.log(`${icon[r.level]}  ${r.msg}`);
const bad = results.filter((r) => r.level === 'fail').length;
const warns = results.filter((r) => r.level === 'warn').length;
console.log(`\n${bad} problem(s), ${warns} warning(s).`);
process.exit(bad ? 1 : 0);
