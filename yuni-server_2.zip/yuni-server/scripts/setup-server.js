'use strict';
// One-command setup for running the site directly on a server (no Docker, no proxy).
//   node scripts/setup-server.js <public-ip-or-host> <port> <your-admin-email>
//   e.g. node scripts/setup-server.js 104.254.222.120 25569 you@example.com
// Creates .env with a fresh SECRET_KEY, a self-signed HTTPS certificate, and private permissions.
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { makeCert } = require('./make-cert');

const [address, portArg, email] = process.argv.slice(2);
const port = Number(portArg);
if (!address || !Number.isInteger(port) || port < 1 || port > 65535 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '')) {
  console.error('Usage: node scripts/setup-server.js <public-ip-or-host> <port> <your-admin-email>');
  process.exit(1);
}
const root = path.join(__dirname, '..');
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile) && !process.argv.includes('--force')) {
  console.error('.env already exists. Not touching it (it holds your SECRET_KEY). Delete it, or add --force, if you really want a new one.');
  process.exit(1);
}
const tls = makeCert(address, path.join(root, 'data', 'tls'));
const host = address.includes(':') ? `[${address}]` : address;
const lines = [
  '# Written by scripts/setup-server.js. Keep this file private and never share it.',
  'NODE_ENV=production',
  `PORT=${port}`,
  'HOST=0.0.0.0',
  `APP_URL=https://${host}:${port}`,
  'TRUST_PROXY=0',
  `TLS_CERT_FILE=${path.relative(root, tls.cert).split(path.sep).join('/')}`,
  `TLS_KEY_FILE=${path.relative(root, tls.key).split(path.sep).join('/')}`,
  `SECRET_KEY=${crypto.randomBytes(32).toString('base64')}`,
  'REQUIRE_ADMIN_2FA=1',
  'BREACHED_PASSWORD_CHECK=1',
  `ADMIN_EMAILS=${email}`,
  '',
];
fs.writeFileSync(envFile, lines.join('\n'), { mode: 0o600 });
fs.chmodSync(envFile, 0o600);
console.log(`Done.\n  Settings: ${envFile}\n  Site address: https://${host}:${port}\n  Certificate fingerprint: ${tls.fingerprint}\n\nNext:\n  1. npm run create-admin\n  2. npm start   (or install the systemd service, see README)\n  3. Open TCP port ${port} in your firewall.`);
console.log('\nBACK UP .env: if SECRET_KEY is lost, admins have to set up two-factor again.');
