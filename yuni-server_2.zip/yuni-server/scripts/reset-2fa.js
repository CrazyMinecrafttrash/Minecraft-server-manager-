'use strict';
// Turns off two-factor sign-in for one account (for an admin who lost their phone AND their
// recovery codes). Needs shell access to the server, which is the point: it cannot be done
// from the website. Usage:  npm run reset-2fa -- someone@example.com
const fs = require('node:fs');
const path = require('node:path');

const envFile = process.env.ENV_FILE || path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { loadConfig } = require('../src/config');
const { openDb, createStore } = require('../src/db');
const { normalizeEmail } = require('../src/security');

const email = normalizeEmail(process.argv[2] || '');
if (!email) { console.error('Usage: npm run reset-2fa -- someone@example.com'); process.exit(1); }

const config = loadConfig();
const db = openDb(config.dbFile);
const store = createStore(db);
const user = store.getUserByEmail(email);
if (!user) { console.error(`No account with the email ${email}.`); process.exit(1); }

store.resetTotp(user.id);
store.deleteUserSessions(user.id);
store.addAudit('server console', '2fa.reset', email, null);
db.close();
console.log(`Two-factor sign-in was reset for ${email} and they were signed out everywhere.`);
console.log('They will be asked to set it up again the next time they sign in.');
