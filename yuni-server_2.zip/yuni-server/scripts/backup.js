'use strict';
// Consistent online backup of the database. Run daily:  npm run backup
const fs = require('node:fs');
const path = require('node:path');

const envFile = process.env.ENV_FILE || path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');

const KEEP = 14;
const config = loadConfig();
fs.mkdirSync(config.backupsDir, { recursive: true, mode: 0o700 });

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const target = path.join(config.backupsDir, `yuni-${stamp}.db`);
const db = openDb(config.dbFile);
db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
db.close();
fs.chmodSync(target, 0o600);

const files = fs.readdirSync(config.backupsDir).filter((f) => /^yuni-.*\.db$/.test(f)).sort();
for (const old of files.slice(0, Math.max(0, files.length - KEEP))) fs.unlinkSync(path.join(config.backupsDir, old));
console.log(`Backup written: ${target} (keeping the newest ${KEEP})`);
