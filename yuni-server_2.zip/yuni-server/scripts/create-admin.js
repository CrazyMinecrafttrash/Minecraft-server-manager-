'use strict';
// Create (or reset) a password admin. Run on the server:  npm run create-admin
// Non-interactive:  ADMIN_EMAIL=a@b.com ADMIN_PASSWORD='...' npm run create-admin
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');

const envFile = process.env.ENV_FILE || path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { loadConfig } = require('../src/config');
const { openDb, createStore } = require('../src/db');
const { normalizeEmail, checkPassword, hashPassword } = require('../src/security');
const { isBreachedPassword } = require('../src/pwned');

function ask(question, hidden) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    if (hidden) {
      rl._writeToOutput = (s) => { if (s.includes(question)) rl.output.write(s); };
    }
    rl.question(question, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); resolve(a); });
  });
}

(async () => {
  const config = loadConfig();
  fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });
  const db = openDb(config.dbFile);
  const store = createStore(db);

  const email = normalizeEmail(process.env.ADMIN_EMAIL || await ask('Admin email: '));
  if (!email) { console.error('That is not a valid email.'); process.exit(1); }
  const password = process.env.ADMIN_PASSWORD || await ask('Password (min 10 characters, hidden): ', true);
  const problems = checkPassword(password, email);
  if (problems.length) { console.error('Password rejected: ' + problems.join(' ')); process.exit(1); }

  if (await isBreachedPassword(password, { api: config.security.breachedPasswordApi })) {
    console.error('Password rejected: it appears in a known data breach. Choose a different one.'); process.exit(1);
  }
  const hash = await hashPassword(password);
  const existing = store.getUserByEmail(email);
  if (existing) {
    store.setPassword(existing.id, hash);
    db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(existing.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(existing.id);
  } else {
    store.createUser({ email, passwordHash: hash, verified: true });
  }
  store.addAdmin(email, 'cli');
  console.log(`Done. ${email} can now sign in as an admin with that password.`);
  if (config.security.requireAdmin2fa) console.log('On first sign-in they will be asked to set up two-factor sign-in with an authenticator app.');
  db.close();
})();
