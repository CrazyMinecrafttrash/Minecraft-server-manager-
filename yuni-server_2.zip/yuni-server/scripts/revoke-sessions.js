'use strict';
// Emergency: signs EVERYONE out (all accounts, all devices). Use after a suspected break-in.
//   npm run revoke-sessions
const fs = require('node:fs');
const path = require('node:path');

const envFile = process.env.ENV_FILE || path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { loadConfig } = require('../src/config');
const { openDb, createStore } = require('../src/db');

const db = openDb(loadConfig().dbFile);
const n = db.prepare('DELETE FROM sessions').run().changes;
db.prepare('DELETE FROM oauth_states').run();
createStore(db).addAudit('server console', 'logout.everyone', `${n} sessions ended`, null);
db.close();
console.log(`Signed out ${n} session(s). Everyone must sign in again (admins with their 2FA code).`);
