(function () {
  'use strict';

  var Y = window.Yuni;
  var esc = Y.esc;

  var TABS = [
    { id: 'overview',     icon: '\uD83D\uDCCA', label: 'Overview' },
    { id: 'servers',      icon: '\uD83D\uDDA5\uFE0F', label: 'Servers' },
    { id: 'modpacks',     icon: '\uD83D\uDCE6', label: 'Modpacks' },
    { id: 'announcement', icon: '\uD83D\uDCE3', label: 'Announcement' },
    { id: 'accounts',     icon: '\uD83D\uDC65', label: 'Accounts' },
    { id: 'bugs',         icon: '\uD83D\uDC1E', label: 'Bug reports' },
    { id: 'notes',        icon: '\uD83D\uDCDD', label: 'Admin notes' },
    { id: 'patrons',      icon: '\uD83D\uDC9B', label: 'Supporters' },
    { id: 'about',        icon: '\uD83D\uDCD6', label: 'About page' },
    { id: 'support',      icon: '\uD83C\uDF81', label: 'Support page' },
    { id: 'backup',       icon: '\uD83D\uDCBE', label: 'Backup & Restore' }
  ];

  var DEFAULTS = {
    servers: [
      { icon: '\u2694\uFE0F', name: 'Survival', ip: '104.254.222.120', port: '25565', description: '', hidden: false },
      { icon: '\uD83C\uDFD7\uFE0F', name: 'Creative', ip: '104.254.222.120', port: '25566', description: '', hidden: false },
      { icon: '\uD83C\uDF24\uFE0F', name: 'SkyBlock', ip: '104.254.222.120', port: '25567', description: '', hidden: false },
      { icon: '\uD83C\uDFAE', name: 'Mini-Games', ip: '104.254.222.120', port: '25568', description: '', hidden: false }
    ],
    modpacks: [
      { serverName: 'Survival', name: 'Survival Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
      { serverName: 'Creative', name: 'Creative Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
      { serverName: 'SkyBlock', name: 'SkyBlock Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
      { serverName: 'Mini-Games', name: 'Mini-Games Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' }
    ],
    fallback: { name: 'YuniDoc Modpack', url: 'downloads/modpack.zip', download: true },
    announcement: { enabled: false, text: '', level: 'info' }
  };

  var ACTIONS = {
    'site.save': 'saved site settings', 'admin.add': 'added admin', 'admin.remove': 'removed admin',
    'user.delete': 'deleted account', 'login.password': 'signed in with password', 'login.google': 'signed in with Google',
    'login.discord': 'signed in with Discord', 'login.locked': 'account locked after failed attempts', signup: 'created an account', 'signup.request': 'requested a sign-up link', 'password.reset.request': 'requested a password link', 'password.reset': 'set a new password',
    'bug.status': 'changed bug status', '2fa.enabled': 'turned on two-factor', '2fa.locked': '2FA locked after wrong codes',
    '2fa.recovery_used': 'used a recovery code', '2fa.recovery_regenerated': 'made new recovery codes', 'login.2fa': 'passed two-factor check',
    'logout.all': 'signed out everywhere', '2fa.reset': 'two-factor was reset from the server', 'bug.delete': 'deleted bug report', 'note.delete': 'deleted note',
    'patron.grant': 'added supporter', 'patron.update': 'changed supporter', 'patron.remove': 'removed supporter', 'patron.export': 'exported supporter list'
  };

  var state = null;      // working copy being edited
  var original = null;   // last copy saved on the server
  var meta = { version: 0, updatedAt: 0, updatedBy: '' };
  var me = null;
  var admins = [];       // [{ email, isOwner, addedBy, createdAt }]
  var users = null;      // null while loading
  var audit = null;
  var missingFiles = [];
  var dirty = false;
  var tab = 'overview';
  var statuses = {};     // "ip:port" -> { s, players, max, version }
  var packFilter = '';
  var serverFilter = '';
  var bugs = null;       // null while loading
  var notes = null;
  var bugFilter = 'open';
  var bugDrafts = {};    // id -> unsaved { status, priority, adminNote }
  var editingNote = null;
  var noteDrafts = {};   // id -> unsaved text while editing
  var newNote = { text: '', pinned: false };

  var BUG_STATUS = { open: 'Open', in_progress: 'In progress', resolved: 'Resolved', wont_fix: "Won't fix" };
  var BUG_PRIORITY = { low: 'Low', normal: 'Normal', high: 'High', critical: 'Critical' };
  var BUG_CATEGORY = { website: 'Website', server: 'Game server', modpack: 'Modpack', account: 'Account / sign-in', other: 'Other' };
  var PRIO_WEIGHT = { critical: 3, high: 2, normal: 1, low: 0 };

  var $ = function (id) { return document.getElementById(id); };
  var content = $('content');

  // \u2500\u2500 helpers \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  function toast(msg, type) {
    var t = document.createElement('div');
    t.className = 'toast' + (type === 'error' ? ' error' : '');
    t.textContent = msg;
    $('toasts').appendChild(t);
    setTimeout(function () { t.remove(); }, type === 'error' ? 6000 : 2800);
  }

  function fail(err) {
    if (err && err.cancelled) { toast(err.message); return; }
    if (err && err.status === 401 && err.body && /code/i.test(err.body.error || '')) { toast(err.message, 'error'); return; }
    if (err && err.status === 401) { window.location.href = '/admin/login.html?error=expired'; return; }
    toast((err && err.message) || 'Something went wrong.', 'error');
  }

  function fmtTime(ts) {
    if (!ts) return '\u2014';
    var d = new Date(ts);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' +
           d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  }

  function setDirty(v) {
    dirty = v;
    $('btn-save').disabled = !v;
    $('btn-discard').disabled = !v;
    $('chip-dirty').style.display = v ? '' : 'none';
  }

  function updateChip() {
    var chip = $('chip-publish');
    chip.textContent = 'Live \u00B7 saved ' + fmtTime(meta.updatedAt) + (meta.updatedBy ? ' by ' + meta.updatedBy : '');
    chip.className = 'chip ok';
  }

  function addrKey(s) { return s.ip + ':' + s.port; }
  function serverNames() { return state.servers.map(function (s) { return s.name; }); }

  // \u2500\u2500 validation (the server checks again; this gives instant feedback) \u2500\u2500
  function validate() {
    var errors = [];
    var seen = {};
    state.servers.forEach(function (s, i) {
      var name = s.name.trim().toLowerCase();
      if (!s.name.trim()) errors.push({ i: i, f: 'name', msg: 'Server ' + (i + 1) + ' needs a name.' });
      else if (seen[name]) errors.push({ i: i, f: 'name', msg: 'Duplicate server name "' + s.name + '".' });
      seen[name] = true;
      if (!s.ip.trim()) errors.push({ i: i, f: 'ip', msg: '"' + s.name + '" needs an IP or hostname.' });
      else if (/\s/.test(s.ip.trim())) errors.push({ i: i, f: 'ip', msg: '"' + s.name + '": IP cannot contain spaces.' });
      if (s.port.trim() !== '') {
        var p = Number(s.port);
        if (!/^\d+$/.test(s.port.trim()) || p < 1 || p > 65535) errors.push({ i: i, f: 'port', msg: '"' + s.name + '": port must be 1\u201365535.' });
      }
    });
    return errors;
  }

  function markInvalid() {
    document.querySelectorAll('[data-scope="server"]').forEach(function (el) { el.classList.remove('invalid'); });
    validate().forEach(function (e) {
      var el = document.querySelector('[data-scope="server"][data-i="' + e.i + '"][data-f="' + e.f + '"]');
      if (el) el.classList.add('invalid');
    });
  }

  function configWarnings() {
    var w = [];
    var names = state.servers.map(function (s) { return s.name.toLowerCase(); });
    state.servers.forEach(function (s) {
      var has = state.modpacks.some(function (p) { return p.serverName.toLowerCase() === s.name.toLowerCase() && p.url; });
      if (!has && !s.hidden) w.push({ tab: 'modpacks', msg: '"' + s.name + '" has no modpack, so the guide shows the fallback pack for it.' });
    });
    state.modpacks.forEach(function (p) {
      if (!p.url) w.push({ tab: 'modpacks', msg: 'Pack "' + p.name + '" has no URL.' });
      if (!p.serverName) w.push({ tab: 'modpacks', msg: 'Pack "' + p.name + '" is not assigned to a server.' });
      else if (names.indexOf(p.serverName.toLowerCase()) === -1) w.push({ tab: 'modpacks', msg: 'Pack "' + p.name + '" points to unknown server "' + p.serverName + '".' });
    });
    if (state.servers.every(function (s) { return s.hidden; })) w.push({ tab: 'servers', msg: 'Every server is hidden, so visitors see an empty list.' });
    missingFiles.forEach(function (m) {
      w.push({ tab: 'modpacks', msg: '"' + m.pack + '" links to ' + m.url + ', but that file is not on the server yet. Upload it to the downloads folder.' });
    });
    return w;
  }

  // \u2500\u2500 data loading \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  // Step-up: dangerous changes need a fresh 2FA code. The server answers 403 + code "reauth"
  // when the last code is too old; ask for one and retry once.
  function secure(method, url, body) {
    return Y.api(method, url, body).catch(function (err) {
      if (!(err.status === 403 && err.body && err.body.code === 'reauth')) throw err;
      var code = window.prompt('Security check: enter the 6-digit code from your authenticator app to confirm this change.');
      if (!code || !code.trim()) { var c = new Error('Cancelled \u2014 nothing was changed.'); c.cancelled = true; throw c; }
      return Y.api('POST', '/api/auth/2fa/verify', { code: code.trim() }).then(function () { return Y.api(method, url, body); });
    });
  }

  var secInfo = null;
  var freshCodes = null;
  function loadSecurity() { return Y.api('GET', '/api/auth/security').then(function (r) { secInfo = r; if (tab === 'accounts') render(); }, fail); }

  function securityPanel() {
    if (!secInfo) return '';
    var low = secInfo.totpEnabled && secInfo.recoveryCodesLeft <= 3;
    return '<div class="panel"><div class="panel-header"><div><h2>Your security</h2><p>Signed in as ' + esc(me.email) + '.</p></div></div><div class="panel-body"><ul class="plain">' +
      (secInfo.totpEnabled
        ? '<li class="good">\u2713 Two-factor sign-in is on</li>'
        : '<li class="warn">\u26A0\uFE0F Two-factor sign-in is off \u2014 <a href="/admin/2fa.html?setup=1">turn it on</a></li>') +
      (secInfo.totpEnabled ? '<li' + (low ? ' class="warn"' : '') + '>' + secInfo.recoveryCodesLeft + ' recovery codes left' + (low ? ' \u2014 make new ones now' : '') + '</li>' : '') +
      '<li>Signed in on ' + secInfo.activeSessions + ' device' + (secInfo.activeSessions === 1 ? '' : 's') + '</li></ul>' +
      (freshCodes ? '<p class="hint" style="margin-top:12px">New recovery codes. Save them now; the old ones no longer work and these will not be shown again.</p><pre class="codes">' + esc(freshCodes.join('\n')) + '</pre>' : '') +
      '<div class="card-actions">' + (secInfo.totpEnabled ? '<button class="icon-btn" type="button" data-act="new-codes">Make new recovery codes</button>' : '') +
      '<span class="spacer"></span><button class="icon-btn danger" type="button" data-act="logout-all" title="Use this if you think someone else got into your account">Sign out everywhere</button></div></div></div>';
  }

  function loadAdmins() { return Y.api('GET', '/api/admin/admins').then(function (r) { admins = r.admins; if (tab === 'accounts') render(); }, fail); }
  function loadUsers() { return Y.api('GET', '/api/admin/users').then(function (r) { users = r.users; if (tab === 'accounts' || tab === 'overview') render(); }, fail); }
  function loadAudit() { return Y.api('GET', '/api/admin/audit?limit=15').then(function (r) { audit = r.entries; if (tab === 'overview') render(); }, fail); }
  function refreshIfShown() { if (tab === 'bugs' || tab === 'overview' || tab === 'notes') render(); else renderSidebar(); }
  function loadBugs() { return Y.api('GET', '/api/admin/bugs').then(function (r) { bugs = r.bugs; refreshIfShown(); }, fail); }
  function loadNotes() { return Y.api('GET', '/api/admin/notes').then(function (r) { notes = r.notes; refreshIfShown(); }, fail); }
  function openBugs() { return (bugs || []).filter(function (b) { return b.status === 'open' || b.status === 'in_progress'; }); }
  function byPriority(a, b) { return PRIO_WEIGHT[b.priority] - PRIO_WEIGHT[a.priority] || b.createdAt - a.createdAt; }
  function sortNotes() { notes.sort(function (a, b) { return (b.pinned - a.pinned) || (b.updatedAt - a.updatedAt) || (b.id - a.id); }); }
  function loadHealth() { return Y.api('GET', '/api/admin/health').then(function (r) { missingFiles = r.missingFiles; if (tab === 'overview') render(); }, fail); }

  // \u2500\u2500 server status \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  function pillHTML(key) {
    var st = statuses[key];
    if (!st) return '<span class="pill">Not checked</span>';
    if (st.s === 'checking') return '<span class="pill checking">Checking\u2026</span>';
    if (st.s === 'online') return '<span class="pill online">Online \u00B7 ' + (st.players !== null ? st.players + '/' + st.max : '?') + (st.version ? ' \u00B7 ' + esc(st.version) : '') + '</span>';
    if (st.s === 'offline') return '<span class="pill offline">Offline</span>';
    return '<span class="pill">Could not check</span>';
  }

  function updatePills() {
    document.querySelectorAll('[data-skey]').forEach(function (el) { el.innerHTML = pillHTML(el.dataset.skey); });
  }

  function checkServer(s) {
    var key = addrKey(s);
    if (!s.ip) return Promise.resolve();
    statuses[key] = { s: 'checking' };
    updatePills();
    return Y.api('GET', '/api/admin/status?host=' + encodeURIComponent(s.ip) + (s.port ? '&port=' + encodeURIComponent(s.port) : ''))
      .then(function (r) {
        if (r.error) statuses[key] = { s: 'unknown' };
        else if (r.online) statuses[key] = { s: 'online', players: r.players ? r.players.online : null, max: r.players ? r.players.max : null, version: r.version || '' };
        else statuses[key] = { s: 'offline' };
      }, function (err) { statuses[key] = { s: 'unknown' }; if (err.status === 429) toast('Slow down a little \u2014 too many status checks.', 'error'); })
      .then(updatePills);
  }

  function checkAll() {
    var seq = Promise.resolve();
    state.servers.forEach(function (s) { seq = seq.then(function () { return checkServer(s); }); });
  }

  // \u2500\u2500 rendering \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  function renderSidebar() {
    var counts = { servers: state.servers.length, modpacks: state.modpacks.length,
      bugs: bugs === null ? undefined : openBugs().length, notes: notes === null ? undefined : notes.length,
      patrons: patronSummary ? patronSummary.active : undefined };
    var j = JSON.stringify;
    var changed = {
      servers: j(state.servers) !== j(original.servers),
      modpacks: j(state.modpacks) !== j(original.modpacks) || j(state.fallback) !== j(original.fallback),
      announcement: j(state.announcement) !== j(original.announcement),
      about: j(state.about) !== j(original.about),
      support: j(state.support) !== j(original.support)
    };
    $('sidebar').innerHTML = TABS.map(function (t, n) {
      return '<button type="button" class="tab-btn' + (t.id === tab ? ' active' : '') + (changed[t.id] ? ' changed' : '') + '" data-tab="' + t.id + '"' +
        (t.id === tab ? ' aria-current="page"' : '') + ' title="' + esc(t.label) + (changed[t.id] ? ' (unsaved changes)' : '') + (n < 9 ? ' \u2014 Alt+' + (n + 1) : '') + '">' +
        '<span>' + t.icon + '</span>' + esc(t.label) +
        (counts[t.id] !== undefined ? '<span class="tab-count">' + counts[t.id] + '</span>' : (n < 9 ? '<kbd>Alt+' + (n + 1) + '</kbd>' : '')) + '</button>';
    }).join('');
    $('page-title').textContent = TABS.filter(function (t) { return t.id === tab; })[0].label;
  }

  function render() {
    renderSidebar();
    ({ overview: renderOverview, servers: renderServers, modpacks: renderModpacks,
       announcement: renderAnnouncement, accounts: renderAccounts, bugs: renderBugs, notes: renderNotes, backup: renderBackup,
       patrons: renderPatrons, about: renderAbout, support: renderSupport })[tab]();
    if (tab === 'servers') markInvalid();
  }

  function stat(label, value, sub) {
    return '<div class="stat-card"><div class="stat-label">' + esc(label) + '</div><div class="stat-value" style="' +
      (String(value).length > 6 ? 'font-size:1.05rem;padding-top:6px;' : '') + '">' + esc(value) + '</div><div class="stat-sub">' + esc(sub) + '</div></div>';
  }

  function renderOverview() {
    var visible = state.servers.filter(function (s) { return !s.hidden; }).length;
    var warnings = configWarnings();
    var zips = state.modpacks.filter(function (p) { return p.type === 'zip'; }).length;

    var html = '<div class="quick">' +
      '<button type="button" data-quick="add-server">\uFF0B Add a server<small>Opens Servers</small></button>' +
      '<button type="button" data-quick="add-pack">\uFF0B Add a modpack<small>Opens Modpacks</small></button>' +
      '<button type="button" data-tab="announcement">\uD83D\uDCE3 Edit the banner<small>' + (state.announcement.enabled ? 'Currently shown' : 'Currently off') + '</small></button>' +
      '<button type="button" data-tab="bugs">\uD83D\uDC1E Bug reports<small>' + (bugs === null ? 'Loading\u2026' : openBugs().length + ' open') + '</small></button>' +
      '<button type="button" data-tab="accounts">\uD83D\uDC65 Manage admins<small>' + (admins.length ? admins.length + ' admin' + (admins.length === 1 ? '' : 's') : 'Accounts') + '</small></button>' +
      '</div><div class="stats-row">' +
      stat('Servers', state.servers.length, visible + ' visible') +
      stat('Modpacks', state.modpacks.length, zips + ' zip \u00B7 ' + (state.modpacks.length - zips) + ' link') +
      stat('Open bugs', bugs === null ? '\u2026' : openBugs().length, bugs === null ? '' : bugs.length + ' reports in total') +
      stat('Accounts', users === null ? '\u2026' : users.length, 'people signed up') +
      stat('Supporters', state.support.enabled ? (patronSummary ? patronSummary.active : '\u2026') : 'Off', state.support.enabled ? (patronSummary ? patronSummary.expiringSoon + ' ending soon' : '') : 'Support page hidden') +
      stat('Website', uptime === null ? '\u2026' : uptime.ok ? 'Online \u2713' : 'Problem', uptime && uptime.ok ? 'up for ' + fmtUp(uptime.uptimeSec) : '') +
      stat('Last saved', fmtTime(meta.updatedAt), meta.updatedBy || '') +
      '</div>';

    html += '<div class="panel"><div class="panel-header"><div><h2>Server status</h2><p>Live check through the public mcsrvstat.us API.</p></div>' +
      '<button class="icon-btn" type="button" data-act="check-all">Check all</button></div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Server</th><th>Address</th><th>Status</th></tr></thead><tbody>' +
      (state.servers.length ? state.servers.map(function (s) {
        return '<tr><td>' + esc(s.icon) + ' ' + esc(s.name) + (s.hidden ? ' <span class="hint">(hidden)</span>' : '') + '</td><td>' + esc(addrKey(s)) +
          '</td><td data-skey="' + esc(addrKey(s)) + '">' + pillHTML(addrKey(s)) + '</td></tr>';
      }).join('') : '<tr><td colspan="3" class="hint">No servers yet.</td></tr>') +
      '</tbody></table></div></div>';

    html += '<div class="panel"><div class="panel-header"><h2>Health checks</h2></div><div class="panel-body"><ul class="plain">' +
      (warnings.length ? warnings.map(function (m) {
        return '<li class="warn"><button type="button" class="link-btn" data-tab="' + m.tab + '">\u26A0\uFE0F ' + esc(m.msg) + ' \u2192</button></li>';
      }).join('') : '<li class="good">\u2713 No problems found.</li>') + '</ul></div></div>';

    var attention = openBugs().sort(byPriority).slice(0, 5);
    var pinned = (notes || []).filter(function (n) { return n.pinned; }).slice(0, 3);
    if (attention.length || pinned.length) {
      html += '<div class="panel"><div class="panel-header"><h2>Needs attention</h2></div><div class="panel-body"><ul class="plain">' +
        attention.map(function (b) {
          return '<li><button type="button" class="link-btn" data-tab="bugs">🐞 #' + b.id + ' ' + esc(b.title) + ' <span class="hint">· ' + esc(BUG_PRIORITY[b.priority]) + '</span> →</button></li>';
        }).join('') +
        pinned.map(function (n) {
          var first = n.body.split('\n')[0];
          return '<li><button type="button" class="link-btn" data-tab="notes">📌 ' + esc(first.length > 90 ? first.slice(0, 90) + '…' : first) + ' →</button></li>';
        }).join('') + '</ul></div></div>';
    }

    html += '<div class="panel"><div class="panel-header"><div><h2>Player problem reports</h2><p>What players reported in the last 24 hours (different people counted once).</p></div>' +
      '<a class="icon-btn" href="/status.html" target="_blank" rel="noopener">Public status page \u2197</a></div><div class="panel-body">' +
      (outages === null ? '<p class="hint">Loading\u2026</p>' : !outages.last24h.length ? '<p class="hint">No problems reported. \u2713</p>' :
        '<ul class="plain">' + outages.last24h.map(function (o) {
          return '<li>' + esc(o.name) + ' \u2014 ' + o.n + ' ' + (o.kind === 'down' ? 'can\u2019t connect' : 'laggy') + '</li>';
        }).join('') + '</ul>') + '</div></div>';

    html += '<div class="panel"><div class="panel-header"><h2>Recent activity</h2></div><div class="panel-body">' +
      (audit === null ? '<p class="hint">Loading\u2026</p>' : audit.length ? '<ul class="plain">' + audit.map(function (l) {
        return '<li><span class="log-time">' + esc(fmtTime(l.ts)) + '</span>' + esc(l.actor || 'system') + ' \u2014 ' + esc(ACTIONS[l.action] || l.action) + (l.detail ? ' (' + esc(l.detail) + ')' : '') + '</li>';
      }).join('') + '</ul>' : '<p class="hint">Nothing yet.</p>') + '</div></div>';

    content.innerHTML = html;
  }

  function fld(label, scope, i, f, value, extra) {
    return '<div><label class="lbl">' + esc(label) + '</label><input class="field" data-scope="' + scope + '" data-i="' + i +
      '" data-f="' + f + '" value="' + esc(value) + '" ' + (extra || '') + '></div>';
  }

  function renderServers() {
    var html = '<div class="panel"><div class="panel-header"><div><h2>Server list</h2>' +
      '<p>Order here is the order visitors see. Hidden servers stay saved but are not shown.</p></div>' +
      '<button class="icon-btn" type="button" data-act="check-all">Check all status</button></div><div class="panel-body">' +
      (state.servers.length > 3 ? '<div class="search-row"><input class="field" id="server-filter" type="search" placeholder="Search servers by name or IP\u2026" aria-label="Search servers" value="' + esc(serverFilter) + '"></div>' : '');

    html += state.servers.map(function (s, i) {
      var last = i === state.servers.length - 1;
      return '<div class="card' + (s.hidden ? ' is-hidden' : '') + '" data-search="' + esc((s.name + ' ' + s.ip + ' ' + s.port).toLowerCase()) + '">' +
        '<div class="grid g-srv">' +
          fld('Icon', 'server', i, 'icon', s.icon, 'style="text-align:center"') +
          fld('Name', 'server', i, 'name', s.name) +
          fld('IP / hostname', 'server', i, 'ip', s.ip, 'placeholder="play.example.com"') +
          fld('Port', 'server', i, 'port', s.port, 'placeholder="25565" inputmode="numeric"') +
        '</div>' +
        '<div style="margin-top:12px">' + fld('Short description (optional)', 'server', i, 'description', s.description, 'placeholder="Vanilla+ survival, 1.20.1"') + '</div>' +
        '<div class="grid g-2" style="margin-top:12px"><div><label class="lbl">Who can see the address</label><select class="field" data-scope="server" data-i="' + i + '" data-f="access">' +
          '<option value="public"' + (s.access !== 'patrons' ? ' selected' : '') + '>Everyone</option>' +
          '<option value="patrons"' + (s.access === 'patrons' ? ' selected' : '') + '>Supporters with early access (and admins)</option></select></div>' +
          '<div><label class="lbl">Opens to everyone on (optional)</label><input class="field" type="date" data-scope="server" data-i="' + i + '" data-f="publicOn" value="' + esc(s.publicOn || '') + '"></div></div>' +
        '<div class="card-actions">' +
          '<label class="check"><input type="checkbox" data-scope="server" data-i="' + i + '" data-f="hidden"' + (s.hidden ? ' checked' : '') + '> Hidden</label>' +
          '<span data-skey="' + esc(addrKey(s)) + '">' + pillHTML(addrKey(s)) + '</span>' +
          '<span class="spacer"></span>' +
          '<button class="icon-btn" type="button" data-act="check" data-i="' + i + '">Check</button>' +
          '<button class="icon-btn" type="button" data-act="up" data-i="' + i + '"' + (i === 0 ? ' disabled' : '') + ' aria-label="Move up">\u2191</button>' +
          '<button class="icon-btn" type="button" data-act="down" data-i="' + i + '"' + (last ? ' disabled' : '') + ' aria-label="Move down">\u2193</button>' +
          '<button class="icon-btn" type="button" data-act="dup" data-i="' + i + '">Duplicate</button>' +
          '<button class="icon-btn danger" type="button" data-act="del" data-i="' + i + '">Remove</button>' +
        '</div></div>';
    }).join('');

    html += '<p class="hint" id="filter-empty" style="display:none;margin-bottom:12px">No servers match your search.</p>' +
      '<button class="btn-add" type="button" data-act="add-server">+ Add server</button></div></div>';
    content.innerHTML = html;
    var sf = $('server-filter');
    if (sf) sf.addEventListener('input', function () { serverFilter = sf.value; applyServerFilter(); });
    applyServerFilter();
  }

  function applyServerFilter() {
    var q = serverFilter.trim().toLowerCase();
    var shown = 0;
    document.querySelectorAll('#content .card[data-search]').forEach(function (c) {
      var ok = !q || c.dataset.search.indexOf(q) !== -1;
      c.style.display = ok ? '' : 'none';
      if (ok) shown++;
    });
    var empty = $('filter-empty');
    if (empty) empty.style.display = q && !shown ? '' : 'none';
  }

  function renderModpacks() {
    var names = serverNames();
    var list = state.modpacks.map(function (p, i) { return { p: p, i: i }; }).filter(function (x) {
      return !packFilter || x.p.serverName === packFilter;
    });

    var html = '<div class="panel"><div class="panel-header"><div><h2>Modpack downloads</h2>' +
      '<p>Each server can have several packs. The first one for a server is the highlighted button in the guide. ' +
      'Upload zip files to the server\u2019s <code>downloads</code> folder, then link them as <code>downloads/yourfile.zip</code>.</p></div>' +
      '<select class="field" id="pack-filter" style="width:auto"><option value="">All servers</option>' +
      names.map(function (n) { return '<option value="' + esc(n) + '"' + (n === packFilter ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('') +
      '</select></div><div class="panel-body">';

    html += list.length ? list.map(function (x) {
      var p = x.p, i = x.i;
      var opts = names.map(function (n) { return '<option value="' + esc(n) + '"' + (n === p.serverName ? ' selected' : '') + '>' + esc(n) + '</option>'; });
      if (p.serverName && names.indexOf(p.serverName) === -1) opts.unshift('<option value="' + esc(p.serverName) + '" selected>' + esc(p.serverName) + ' (missing)</option>');
      if (!p.serverName) opts.unshift('<option value="" selected>\u2014 choose server \u2014</option>');
      return '<div class="card"><div class="grid g-pack">' +
        '<div><label class="lbl">Server</label><select class="field" data-scope="pack" data-i="' + i + '" data-f="serverName">' + opts.join('') + '</select></div>' +
        fld('Pack name', 'pack', i, 'name', p.name) +
        fld('Version', 'pack', i, 'version', p.version, 'placeholder="1.2.0"') +
        '<div><label class="lbl">Type</label><select class="field" data-scope="pack" data-i="' + i + '" data-f="type">' +
          '<option value="zip"' + (p.type === 'zip' ? ' selected' : '') + '>Zip file</option>' +
          '<option value="link"' + (p.type === 'link' ? ' selected' : '') + '>Website link</option></select></div>' +
        '</div><div style="margin-top:12px">' + fld('Download URL or file path', 'pack', i, 'url', p.url, 'placeholder="downloads/modpack.zip or https://\u2026"') + '</div>' +
        '<div class="card-actions"><span class="spacer"></span>' +
          '<button class="icon-btn" type="button" data-act="pack-up" data-i="' + i + '"' + (i === 0 ? ' disabled' : '') + ' aria-label="Move up">\u2191</button>' +
          '<button class="icon-btn" type="button" data-act="pack-down" data-i="' + i + '"' + (i === state.modpacks.length - 1 ? ' disabled' : '') + ' aria-label="Move down">\u2193</button>' +
          '<button class="icon-btn" type="button" data-act="pack-dup" data-i="' + i + '">Duplicate</button>' +
          '<button class="icon-btn danger" type="button" data-act="pack-del" data-i="' + i + '">Remove</button></div></div>';
    }).join('') : '<p class="hint" style="margin-bottom:12px">No packs' + (packFilter ? ' for this server' : '') + ' yet.</p>';

    html += '<button class="btn-add" type="button" data-act="add-pack">+ Add modpack</button></div></div>';

    var fb = state.fallback;
    html += '<div class="panel"><div class="panel-header"><div><h2>Fallback download</h2>' +
      '<p>Shown in the guide for any server that has no pack of its own.</p></div></div><div class="panel-body">' +
      '<div class="grid g-2">' + fld('Pack name', 'fb', 0, 'name', fb.name) + fld('URL or file path', 'fb', 0, 'url', fb.url) + '</div>' +
      '<label class="check" style="margin-top:12px"><input type="checkbox" data-scope="fb" data-i="0" data-f="download"' + (fb.download ? ' checked' : '') + '> This is a zip file (uncheck for a website link)</label>' +
      '</div></div>';

    content.innerHTML = html;
    $('pack-filter').addEventListener('change', function () { packFilter = this.value; renderModpacks(); });
  }

  function renderAnnouncement() {
    var a = state.announcement;
    content.innerHTML = '<div class="panel"><div class="panel-header"><div><h2>Site banner</h2>' +
      '<p>A message bar shown at the top of the home page, e.g. maintenance or events.</p></div></div><div class="panel-body">' +
      '<label class="check" style="margin-bottom:14px"><input type="checkbox" data-scope="ann" data-i="0" data-f="enabled"' + (a.enabled ? ' checked' : '') + '> Show the banner</label>' +
      '<div class="grid" style="grid-template-columns:1fr 160px">' +
        fld('Message', 'ann', 0, 'text', a.text, 'maxlength="200" placeholder="Server restart tonight at 9 PM ET"') +
        '<div><label class="lbl">Style</label><select class="field" data-scope="ann" data-i="0" data-f="level">' +
          ['info', 'warn', 'success'].map(function (l) { return '<option value="' + l + '"' + (a.level === l ? ' selected' : '') + '>' + { info: 'Info', warn: 'Warning', success: 'Good news' }[l] + '</option>'; }).join('') +
        '</select></div></div>' +
      '<label class="lbl" style="margin-top:18px">Preview</label>' +
      '<div class="preview-banner lvl-' + a.level + '" id="ann-preview">' + (esc(a.text) || '<span style="opacity:.6">Your message appears here</span>') + '</div>' +
      '</div></div>';
  }

  function methods(u) {
    var m = u.providers.map(function (p) { return p === 'google' ? 'Google' : p === 'discord' ? 'Discord' : p; });
    if (u.hasPassword) m.unshift('Password');
    return m.join(', ') || '\u2014';
  }

  function renderAccounts() {
    var signedUp = {};
    (users || []).forEach(function (u) { signedUp[u.email.toLowerCase()] = u; });

    var html = securityPanel() + '<div class="panel"><div class="panel-header"><div><h2>Admins</h2>' +
      '<p>Anyone on this list becomes an admin as soon as they sign in with a <strong>verified</strong> email \u2014 through Google or Discord, or a password account you create from the server. ' +
      'Changes apply immediately.</p></div></div>' +
      '<div class="panel-body"><ul class="plain" style="margin-bottom:16px">' +
      admins.map(function (a) {
        var u = signedUp[a.email.toLowerCase()];
        var note = !u ? 'Has not signed in yet' : !u.emailVerified ? 'Email not verified yet \u2014 sign in with Google or Discord' : '';
        return '<li style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span style="flex:1;word-break:break-all">' + esc(a.email) +
          (a.email === me.email ? ' <span class="hint">(you)</span>' : '') +
          (note ? '<br><span class="hint">' + esc(note) + '</span>' : '') + '</span>' +
          (a.isOwner ? '<span class="pill" title="Set in the server settings (ADMIN_EMAILS) and cannot be removed here">Owner</span>'
            : (a.email === me.email ? '' : '<button class="icon-btn danger" type="button" data-act="rm-admin" data-email="' + esc(a.email) + '">Remove</button>')) + '</li>';
      }).join('') + '</ul>' +
      '<label class="lbl" for="new-admin">Add an admin by email</label>' +
      '<div style="display:flex;gap:10px;flex-wrap:wrap"><input class="field" id="new-admin" type="email" placeholder="friend@example.com" style="flex:1;min-width:200px">' +
      '<button class="btn btn-primary" type="button" data-act="add-admin" style="padding:9px 18px;font-size:.88rem">Add admin</button></div>' +
      '<p class="hint" style="margin-top:12px">Use the exact email their Google or Discord account uses. Discord requires a verified email on the account.</p></div></div>';

    html += '<div class="panel"><div class="panel-header"><div><h2>People who have signed in</h2><p>Everyone with an account on this site.</p></div></div>' +
      '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Email</th><th>Sign-in</th><th>Role</th><th>Last sign-in</th><th></th></tr></thead><tbody>' +
      (users === null ? '<tr><td colspan="5" class="hint">Loading\u2026</td></tr>' : users.length ? users.map(function (u) {
        var isMe = u.email === me.email;
        var actions = '';
        if (!u.isAdminListed) actions += '<button class="icon-btn" type="button" data-act="grant-admin" data-email="' + esc(u.email) + '">Make admin</button> ';
        else if (!u.isOwner && !isMe) actions += '<button class="icon-btn" type="button" data-act="rm-admin" data-email="' + esc(u.email) + '">Remove admin</button> ';
        if (!isMe && !u.isOwner) actions += '<button class="icon-btn danger" type="button" data-act="del-user" data-id="' + u.id + '" data-email="' + esc(u.email) + '">Delete</button>';
        return '<tr><td>' + esc(u.email) + (isMe ? ' <span class="hint">(you)</span>' : '') + (u.emailVerified ? '' : '<br><span class="hint">email not verified</span>') + '</td>' +
          '<td>' + esc(methods(u)) + '</td>' +
          '<td>' + (u.isAdmin ? '<span class="admin-badge" style="margin:0">ADMIN</span>' : u.isAdminListed ? 'Pending' : 'Member') +
            (u.isAdminListed ? '<br><span class="hint">' + (u.totpEnabled ? '2FA on' : '2FA not set up yet') + '</span>' : '') + '</td>' +
          '<td>' + esc(fmtTime(u.lastLoginAt)) + '</td>' +
          '<td style="text-align:right;white-space:nowrap">' + actions + '</td></tr>';
      }).join('') : '<tr><td colspan="5" class="hint">Nobody has signed up yet.</td></tr>') +
      '</tbody></table></div></div>';

    content.innerHTML = html;
  }

  // ── bug reports ────────────────────────────────────────
  function bugSelect(id, field, value, labels) {
    return '<select class="field" data-scope="bug" data-id="' + id + '" data-f="' + field + '">' +
      Object.keys(labels).map(function (k) { return '<option value="' + k + '"' + (k === value ? ' selected' : '') + '>' + esc(labels[k]) + '</option>'; }).join('') + '</select>';
  }

  function bugIsDirty(b) {
    var d = bugDrafts[b.id];
    return Boolean(d) && ((d.status !== undefined && d.status !== b.status) || (d.priority !== undefined && d.priority !== b.priority) || (d.adminNote !== undefined && d.adminNote !== b.adminNote));
  }

  function bugCard(b) {
    var d = bugDrafts[b.id] || {};
    var st = d.status !== undefined ? d.status : b.status;
    var pr = d.priority !== undefined ? d.priority : b.priority;
    var nt = d.adminNote !== undefined ? d.adminNote : b.adminNote;
    return '<div class="card" data-bug="' + b.id + '" data-search="' + esc(('#' + b.id + ' ' + b.title + ' ' + b.description + ' ' + (b.reporter || '') + ' ' + b.serverName).toLowerCase()) + '">' +
      '<div class="bug-head"><span class="bug-title">#' + b.id + ' ' + esc(b.title) + '</span>' +
        '<span class="pill prio-' + esc(b.priority) + '">' + esc(BUG_PRIORITY[b.priority] || b.priority) + '</span>' +
        '<span class="pill st-' + esc(b.status) + '">' + esc(BUG_STATUS[b.status] || b.status) + '</span></div>' +
      '<div class="hint">' + esc(BUG_CATEGORY[b.category] || b.category) + (b.serverName ? ' · ' + esc(b.serverName) : '') +
        ' · ' + esc(b.reporter || 'unknown') + ' · ' + esc(fmtTime(b.createdAt)) +
        (b.updatedBy ? ' · last updated by ' + esc(b.updatedBy) : '') + '</div>' +
      '<div class="note-body">' + esc(b.description) + '</div>' +
      '<div class="grid g-2"><div><label class="lbl">Status</label>' + bugSelect(b.id, 'status', st, BUG_STATUS) + '</div>' +
        '<div><label class="lbl">Priority</label>' + bugSelect(b.id, 'priority', pr, BUG_PRIORITY) + '</div></div>' +
      '<div style="margin-top:12px"><label class="lbl">Internal note (only admins see this)</label>' +
        '<textarea class="field" rows="2" maxlength="2000" data-scope="bug" data-id="' + b.id + '" data-f="adminNote" placeholder="What did you find? What’s the plan?">' + esc(nt) + '</textarea></div>' +
      '<div class="card-actions"><button class="icon-btn" type="button" data-act="bug-save" data-id="' + b.id + '">Save</button>' +
        (b.status !== 'resolved' ? '<button class="icon-btn" type="button" data-act="bug-resolve" data-id="' + b.id + '">Mark resolved</button>' : '') +
        '<span class="hint" data-unsaved="' + b.id + '">' + (bugIsDirty(b) ? 'Unsaved changes' : '') + '</span><span class="spacer"></span>' +
        '<button class="icon-btn danger" type="button" data-act="bug-del" data-id="' + b.id + '">Delete</button></div></div>';
  }

  function renderBugs() {
    if (bugs === null) { content.innerHTML = '<div class="panel"><div class="panel-body"><p class="hint">Loading…</p></div></div>'; return; }
    var filters = [['open', 'Open'], ['in_progress', 'In progress'], ['resolved', 'Resolved'], ['wont_fix', "Won't fix"], ['all', 'All']];
    var list = bugs.filter(function (b) { return bugFilter === 'all' || b.status === bugFilter; });
    list.sort(bugFilter === 'open' || bugFilter === 'in_progress' ? byPriority : function (a, b) { return b.createdAt - a.createdAt; });

    content.innerHTML = '<div class="panel"><div class="panel-header"><div><h2>Bug reports</h2>' +
      '<p>Sent by signed-in visitors from the “Report a bug” page. Changes here save straight away and do not need “Save changes”.</p></div></div><div class="panel-body">' +
      '<div class="seg" role="group" aria-label="Filter by status">' + filters.map(function (f) {
        var n = f[0] === 'all' ? bugs.length : bugs.filter(function (b) { return b.status === f[0]; }).length;
        return '<button type="button" data-act="bug-filter" data-v="' + f[0] + '" class="' + (bugFilter === f[0] ? 'active' : '') + '">' + esc(f[1]) + ' <span>' + n + '</span></button>';
      }).join('') + '</div>' +
      '<div class="search-row"><input class="field" id="bug-search" type="search" placeholder="Search reports by title, text, reporter…" aria-label="Search reports"></div>' +
      (list.length ? list.map(bugCard).join('') : '<p class="hint">' + (bugs.length ? 'No reports with this status.' : 'No bug reports yet. When someone sends one it appears here.') + '</p>') +
      '<p class="hint" id="bug-none" style="display:none">No reports match your search.</p></div></div>';

    var input = $('bug-search');
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase(), shown = 0;
      document.querySelectorAll('#content .card[data-search]').forEach(function (c) {
        var ok = !q || c.dataset.search.indexOf(q) !== -1;
        c.style.display = ok ? '' : 'none';
        if (ok) shown++;
      });
      $('bug-none').style.display = q && !shown && list.length ? '' : 'none';
    });
  }

  function saveBug(id, override) {
    var b = bugs.filter(function (x) { return x.id === id; })[0];
    if (!b) return;
    var d = Object.assign({}, bugDrafts[id], override || {});
    var body = {};
    ['status', 'priority', 'adminNote'].forEach(function (k) { if (d[k] !== undefined && d[k] !== b[k]) body[k] = d[k]; });
    if (!Object.keys(body).length) { toast('Nothing to save.'); return; }
    Y.api('PUT', '/api/admin/bugs/' + id, body).then(function (res) {
      bugs = bugs.map(function (x) { return x.id === id ? res.bug : x; });
      delete bugDrafts[id];
      toast('Saved.');
      loadAudit();
      render();
    }, function (err) { if (err.status === 404) loadBugs(); fail(err); });
  }

  // ── admin notes ────────────────────────────────────────
  function renderNotes() {
    if (notes === null) { content.innerHTML = '<div class="panel"><div class="panel-body"><p class="hint">Loading…</p></div></div>'; return; }
    var html = '<div class="panel"><div class="panel-header"><div><h2>Admin notes</h2>' +
      '<p>A shared notepad for admins only — reminders, to-dos, server details. Visitors never see these. Pinned notes stay on top.</p></div></div><div class="panel-body">' +
      '<label class="lbl" for="new-note">New note</label>' +
      '<textarea class="field" id="new-note" rows="3" maxlength="4000" data-scope="newnote" data-f="text" placeholder="Write a note for the other admins… (Ctrl+Enter to add)">' + esc(newNote.text) + '</textarea>' +
      '<div class="card-actions"><label class="check"><input type="checkbox" data-scope="newnote" data-f="pinned"' + (newNote.pinned ? ' checked' : '') + '> Pin to top</label><span class="spacer"></span>' +
      '<button class="btn btn-primary" type="button" data-act="note-add" style="padding:8px 18px;font-size:.86rem">Add note</button></div></div></div>';

    html += '<div class="panel"><div class="panel-header"><h2>All notes <span class="hint">(' + notes.length + ')</span></h2></div><div class="panel-body">' +
      (notes.length ? notes.map(function (n) {
        var editing = editingNote === n.id;
        return '<div class="card">' +
          '<div class="hint">' + (n.pinned ? '📌 Pinned · ' : '') + esc(n.author || 'unknown') + ' · ' + esc(fmtTime(n.createdAt)) +
            (n.updatedAt > n.createdAt + 1000 ? ' · edited by ' + esc(n.updatedBy || 'unknown') + ' ' + esc(fmtTime(n.updatedAt)) : '') + '</div>' +
          (editing
            ? '<textarea class="field" rows="4" maxlength="4000" data-scope="noteedit" data-id="' + n.id + '" style="margin-top:8px">' + esc(noteDrafts[n.id] !== undefined ? noteDrafts[n.id] : n.body) + '</textarea>'
            : '<div class="note-body">' + esc(n.body) + '</div>') +
          '<div class="card-actions">' +
            (editing
              ? '<button class="icon-btn" type="button" data-act="note-save" data-id="' + n.id + '">Save</button><button class="icon-btn" type="button" data-act="note-cancel" data-id="' + n.id + '">Cancel</button>'
              : '<button class="icon-btn" type="button" data-act="note-pin" data-id="' + n.id + '">' + (n.pinned ? 'Unpin' : 'Pin') + '</button>' +
                '<button class="icon-btn" type="button" data-act="note-edit" data-id="' + n.id + '">Edit</button>') +
            '<span class="spacer"></span><button class="icon-btn danger" type="button" data-act="note-del" data-id="' + n.id + '">Delete</button></div></div>';
      }).join('') : '<p class="hint">No notes yet.</p>') + '</div></div>';
    content.innerHTML = html;
  }

  function noteApi(method, id, body) {
    return Y.api(method, '/api/admin/notes' + (id ? '/' + id : ''), body);
  }

  function addNote() {
    var text = newNote.text.trim();
    if (!text) { toast('Write something first.', 'error'); return; }
    noteApi('POST', null, { body: text, pinned: newNote.pinned }).then(function (res) {
      notes.push(res.note); sortNotes();
      newNote = { text: '', pinned: false };
      toast('Note added.');
      render();
    }, fail);
  }

  function replaceNote(note) {
    notes = notes.map(function (n) { return n.id === note.id ? note : n; });
    sortNotes();
  }

  function renderBackup() {
    content.innerHTML = '<div class="panel"><div class="panel-header"><div><h2>Export settings</h2>' +
      '<p>Download a copy of your servers, modpacks and banner as a file you can keep or import later.</p></div></div>' +
      '<div class="panel-body"><button class="btn btn-primary" type="button" data-act="download" style="padding:10px 18px">Download settings file</button></div></div>' +
      '<div class="panel"><div class="panel-header"><div><h2>Import settings</h2><p>Load a settings file. It is applied as unsaved changes so you can review it first.</p></div></div>' +
      '<div class="panel-body"><input type="file" id="import-file" accept="application/json,.json" class="field"></div></div>' +
      '<div class="panel"><div class="panel-header"><h2>Restore defaults</h2></div><div class="panel-body">' +
      '<p class="hint" style="margin-bottom:12px">Puts the original four servers and packs back as unsaved changes.</p>' +
      '<button class="icon-btn danger" type="button" data-act="restore-defaults">Restore default settings</button></div></div>' +
      '<div class="panel"><div class="panel-header"><h2>Server backups</h2></div><div class="panel-body">' +
      '<p class="hint">Accounts and settings live in the server\u2019s database. Back it up with <code>npm run backup</code> (see the README for a daily schedule).</p></div></div>';
    $('import-file').addEventListener('change', importFile);
  }

  // \u2500\u2500 actions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  // ── about & support editors (part of the site settings draft) ──
  var NEW_ITEM = {
    'about.values': { title: '', text: '' },
    'about.team': { name: '', role: '', bio: '' },
    'support.costs': { label: '', amount: 0 },
    'support.tiers': { id: '', name: 'New tier', price: '', description: '', perks: [], earlyAccess: false, url: '' },
    'support.cosmetics': { name: '', description: '', tier: '' }
  };
  var LIST_MAX = { 'about.values': 6, 'about.team': 12, 'support.costs': 10, 'support.tiers': 6, 'support.cosmetics': 40 };

  function getPath(obj, path) { return path.split('.').reduce(function (o, k) { return o == null ? o : o[k]; }, obj); }
  function setPath(obj, path, v) {
    var ks = path.split('.');
    var last = ks.pop();
    ks.reduce(function (o, k) { return o[k]; }, obj)[last] = v;
  }

  // A text / number / list / textarea input bound to a path inside the draft, e.g. "support.tiers.0.name".
  function pf(label, path, o) {
    o = o || {};
    var v = getPath(state, path);
    var a = 'data-scope="path" data-path="' + path + '"' + (o.kind ? ' data-kind="' + o.kind + '"' : '') +
      (o.max ? ' maxlength="' + o.max + '"' : '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '');
    var control;
    if (o.kind === 'list') control = '<textarea class="field" rows="' + (o.rows || 3) + '" ' + a + '>' + esc((v || []).join('\n')) + '</textarea>';
    else if (o.area) control = '<textarea class="field" rows="' + o.area + '" ' + a + '>' + esc(v) + '</textarea>';
    else if (o.kind === 'number') control = '<input class="field" type="number" min="0" step="any" ' + a + ' value="' + esc(v) + '">';
    else control = '<input class="field" type="text" ' + a + ' value="' + esc(v) + '">';
    return '<div><label class="lbl">' + esc(label) + '</label>' + control + '</div>';
  }

  function pcheck(label, path) {
    return '<label class="check"><input type="checkbox" data-scope="path" data-path="' + path + '"' + (getPath(state, path) ? ' checked' : '') + '> ' + esc(label) + '</label>';
  }

  function listPanel(title, desc, path, renderItem, addLabel) {
    var items = getPath(state, path);
    return '<div class="panel"><div class="panel-header"><div><h2>' + esc(title) + '</h2><p>' + esc(desc) + '</p></div></div><div class="panel-body">' +
      items.map(function (it, i) {
        return '<div class="card">' + renderItem(it, path + '.' + i) +
          '<div class="card-actions"><span class="spacer"></span>' +
          '<button class="icon-btn" type="button" data-act="path-up" data-path="' + path + '" data-i="' + i + '"' + (i === 0 ? ' disabled' : '') + ' aria-label="Move up">↑</button>' +
          '<button class="icon-btn" type="button" data-act="path-down" data-path="' + path + '" data-i="' + i + '"' + (i === items.length - 1 ? ' disabled' : '') + ' aria-label="Move down">↓</button>' +
          '<button class="icon-btn danger" type="button" data-act="path-del" data-path="' + path + '" data-i="' + i + '">Remove</button></div></div>';
      }).join('') +
      (items.length < LIST_MAX[path] ? '<button class="btn-add" type="button" data-act="path-add" data-path="' + path + '">' + esc(addLabel) + '</button>'
        : '<p class="hint">You have reached the limit of ' + LIST_MAX[path] + '.</p>') +
      '</div></div>';
  }

  function renderAbout() {
    content.innerHTML =
      '<div class="panel"><div class="panel-header"><div><h2>Your story</h2><p>Shown on the About page. Make it personal: who you are, why the server exists, what it costs you. Leave a blank line between paragraphs.</p></div>' +
      '<a class="icon-btn" href="/about.html" target="_blank" rel="noopener">View page ↗</a></div><div class="panel-body">' +
      pf('Headline', 'about.headline', { max: 100 }) +
      '<div style="margin-top:12px">' + pf('Story', 'about.story', { area: 10, max: 3000 }) + '</div></div></div>' +
      listPanel('Promises', 'Short cards shown on the home page and the About page (up to 6).', 'about.values', function (v, p) {
        return '<div class="grid" style="grid-template-columns:1fr 2fr">' + pf('Title', p + '.title', { max: 50 }) + pf('Text', p + '.text', { max: 240 }) + '</div>';
      }, '+ Add promise') +
      listPanel('Team', 'Optional. Introduce the people who run the server (up to 12).', 'about.team', function (m, p) {
        return '<div class="grid g-2">' + pf('Name', p + '.name', { max: 40 }) + pf('Role', p + '.role', { max: 60 }) + '</div>' +
          '<div style="margin-top:12px">' + pf('Short bio', p + '.bio', { area: 2, max: 300 }) + '</div>';
      }, '+ Add team member');
  }

  function renderSupport() {
    var tiers = state.support.tiers;
    content.innerHTML =
      '<div class="panel"><div class="panel-header"><div><h2>Supporter programme</h2><p>Perks must stay cosmetic or early access. Nothing that affects gameplay. The Support page stays hidden until you switch this on.</p></div>' +
      '<a class="icon-btn" href="/support.html" target="_blank" rel="noopener">View page ↗</a></div><div class="panel-body">' +
      pcheck('Show the Support page and its links', 'support.enabled') + ' &nbsp; ' + pcheck('Show the supporter wall', 'support.showWall') +
      '<div style="margin-top:14px">' + pf('Headline', 'support.headline', { max: 100 }) + '</div>' +
      '<div style="margin-top:12px">' + pf('Introduction', 'support.intro', { area: 3, max: 600 }) + '</div>' +
      '<div style="margin-top:12px">' + pf('Your pledge (one per line)', 'support.pledge', { kind: 'list', rows: 4 }) + '</div></div></div>' +
      '<div class="panel"><div class="panel-header"><div><h2>Costs &amp; goal</h2><p>Showing the real numbers builds trust. Update "raised" each month.</p></div></div><div class="panel-body">' +
      '<div class="grid" style="grid-template-columns:90px 1fr 1fr">' + pf('Currency', 'support.goal.currency', { max: 4 }) +
      pf('Monthly cost', 'support.goal.monthlyCost', { kind: 'number' }) + pf('Raised this month', 'support.goal.raised', { kind: 'number' }) + '</div>' +
      '<div style="margin-top:12px">' + pf('Note under the bar (optional)', 'support.goal.note', { max: 200, ph: 'Anything above the goal goes into a reserve for new servers.' }) + '</div></div></div>' +
      listPanel('Cost breakdown', 'Optional lines like "Server hosting".', 'support.costs', function (c, p) {
        return '<div class="grid" style="grid-template-columns:2fr 1fr">' + pf('What', p + '.label', { max: 60 }) + pf('Amount per month', p + '.amount', { kind: 'number' }) + '</div>';
      }, '+ Add cost') +
      listPanel('Tiers', 'Each tier links to a payment page you set up (Ko-fi, Patreon, Stripe...). Payments never touch this server.', 'support.tiers', function (t, p) {
        return '<div class="grid" style="grid-template-columns:1fr 1fr">' + pf('Name', p + '.name', { max: 40 }) + pf('Price label', p + '.price', { max: 40, ph: '$5 / month' }) + '</div>' +
          '<div style="margin-top:12px">' + pf('Description', p + '.description', { max: 200 }) + '</div>' +
          '<div style="margin-top:12px">' + pf('Perks (one per line)', p + '.perks', { kind: 'list', rows: 4 }) + '</div>' +
          '<div style="margin-top:12px">' + pf('Payment link (https only)', p + '.url', { max: 500, ph: 'https://ko-fi.com/yourpage' }) + '</div>' +
          '<div style="margin-top:12px">' + pcheck('Includes early access to new servers', p + '.earlyAccess') + '</div>';
      }, '+ Add tier') +
      listPanel('Cosmetics', 'Optional. Only list in-game cosmetics your modpack really supports, and hand them out yourself or with a mod you already use. Looks only, never gameplay.', 'support.cosmetics', function (c, p) {
        return '<div class="grid" style="grid-template-columns:1fr 1fr">' + pf('Name', p + '.name', { max: 60 }) +
          '<div><label class="lbl">Unlocked at</label><select class="field" data-scope="path" data-path="' + p + '.tier"><option value="">Every supporter</option>' +
          tiers.filter(function (t) { return t.id; }).map(function (t) { return '<option value="' + esc(t.id) + '"' + (c.tier === t.id ? ' selected' : '') + '>' + esc(t.name) + ' and up</option>'; }).join('') +
          '</select></div></div><div style="margin-top:12px">' + pf('Description', p + '.description', { max: 200 }) + '</div>' +
          (tiers.some(function (t) { return !t.id; }) ? '<p class="hint">Save once to pick brand-new tiers here.</p>' : '');
      }, '+ Add cosmetic');
  }

  // ── supporters (live data, saved straight to the server; each change asks for a 2FA code) ──
  var outages = null;
  var uptime = null;
  function loadUptime() { return Y.api('GET', '/healthz').then(function (r) { uptime = r; if (tab === 'overview') render(); }, function () { uptime = { ok: false }; if (tab === 'overview') render(); }); }
  function fmtUp(s) { return s < 90 ? s + ' sec' : s < 5400 ? Math.round(s / 60) + ' min' : s < 172800 ? Math.round(s / 3600) + ' hours' : Math.round(s / 86400) + ' days'; }
  function loadOutages() { return Y.api('GET', '/api/admin/outages').then(function (r) { outages = r; if (tab === 'overview') render(); }, fail); }
  var patrons = null;
  var patronSummary = null;
  var patronDrafts = {};
  var grant = { emails: '', tier: '', until: '', note: '' };

  function loadPatrons() {
    return Y.api('GET', '/api/admin/patrons').then(function (r) { patrons = r.patrons; patronSummary = r.summary; if (tab === 'patrons' || tab === 'overview') render(); else renderSidebar(); }, fail);
  }
  function tierName(id) {
    var t = original.support.tiers.filter(function (x) { return x.id === id; })[0];
    return t ? t.name : id;
  }
  function dateOf(ts) { return ts ? new Date(ts).toISOString().slice(0, 10) : ''; }

  function renderPatrons() {
    var tiers = original.support.tiers;
    var html = '<div class="panel"><div class="panel-header"><div><h2>Add supporters</h2>' +
      '<p>After someone pays on your payment page, add the email they used. They get their perks once they sign in with that verified email. Tiers come from the last <em>saved</em> Support tab.</p></div></div><div class="panel-body">';
    if (!tiers.length) html += '<p class="hint">Create at least one tier in the Support tab and save first.</p>';
    else {
      if (!grant.tier) grant.tier = tiers[0].id;
      html += '<label class="lbl">Email addresses (one per line, up to 50)</label><textarea class="field" rows="3" data-scope="grant" data-f="emails">' + esc(grant.emails) + '</textarea>' +
        '<div class="grid" style="grid-template-columns:1fr 1fr 2fr;margin-top:12px"><div><label class="lbl">Tier</label><select class="field" data-scope="grant" data-f="tier">' +
        tiers.map(function (t) { return '<option value="' + esc(t.id) + '"' + (grant.tier === t.id ? ' selected' : '') + '>' + esc(t.name) + '</option>'; }).join('') + '</select></div>' +
        '<div><label class="lbl">Ends on (optional)</label><input class="field" type="date" data-scope="grant" data-f="until" value="' + esc(grant.until) + '"></div>' +
        '<div><label class="lbl">Private note</label><input class="field" type="text" maxlength="200" data-scope="grant" data-f="note" value="' + esc(grant.note) + '"></div></div>' +
        '<p style="margin-top:14px"><button class="btn btn-primary" type="button" data-act="patron-grant" style="padding:9px 18px;font-size:.88rem">Add supporters</button></p>';
    }
    html += '</div></div>';

    html += '<div class="panel"><div class="panel-header"><div><h2>Supporters</h2><p>' +
      (patronSummary ? patronSummary.active + ' active · ' + patronSummary.expiringSoon + ' ending within 7 days · ' + patronSummary.total + ' total' : 'Loading…') + '</p></div>' +
      '<button class="icon-btn" type="button" data-act="patron-export">Download CSV for the game server</button></div>';
    if (patrons === null) html += '<div class="panel-body"><p class="hint">Loading…</p></div>';
    else if (!patrons.length) html += '<div class="panel-body"><p class="hint">No supporters yet.</p></div>';
    else {
      html += '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Supporter</th><th>Tier</th><th>Ends</th><th>Hide from wall</th><th></th></tr></thead><tbody>' +
        patrons.map(function (p) {
          var d = patronDrafts[p.email] || {};
          var tier = d.tier !== undefined ? d.tier : p.tier;
          var until = d.until !== undefined ? d.until : dateOf(p.until);
          var hide = d.hideWall !== undefined ? d.hideWall : p.hideWall;
          var soon = p.active && p.until && p.until < Date.now() + 7 * 864e5;
          var e = esc(p.email);
          return '<tr><td>' + e + '<div class="hint">' + (p.mcUsername ? esc(p.mcUsername) + ' · ' : '') +
            (!p.signedUp ? 'not signed up yet' : p.emailVerified ? 'signed up' : 'email not verified') +
            (!p.active ? ' · <strong>ended</strong>' : soon ? ' · <strong>ending soon</strong>' : '') + '</div></td>' +
            '<td><select class="field" data-scope="pdraft" data-email="' + e + '" data-f="tier">' +
            original.support.tiers.map(function (t) { return '<option value="' + esc(t.id) + '"' + (tier === t.id ? ' selected' : '') + '>' + esc(t.name) + '</option>'; }).join('') +
            (original.support.tiers.some(function (t) { return t.id === tier; }) ? '' : '<option value="' + esc(tier) + '" selected>' + esc(tier) + '</option>') + '</select></td>' +
            '<td><input class="field" type="date" data-scope="pdraft" data-email="' + e + '" data-f="until" value="' + esc(until) + '"></td>' +
            '<td><input type="checkbox" data-scope="pdraft" data-email="' + e + '" data-f="hideWall"' + (hide ? ' checked' : '') + ' aria-label="Hide from wall"></td>' +
            '<td style="white-space:nowrap"><button class="icon-btn" type="button" data-act="patron-save" data-email="' + e + '"' + (patronDrafts[p.email] ? '' : ' disabled') + '>Save</button> ' +
            '<button class="icon-btn danger" type="button" data-act="patron-del" data-email="' + e + '">Remove</button></td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    html += '</div>';
    content.innerHTML = html;
  }

  function grantPatrons() {
    var emails = grant.emails.split(/[\s,;]+/).filter(Boolean);
    if (!emails.length) { toast('Enter at least one email address.', 'error'); return; }
    secure('POST', '/api/admin/patrons', { emails: emails, tier: grant.tier, until: grant.until, note: grant.note }).then(function (r) {
      toast('Added ' + r.added + ' supporter' + (r.added === 1 ? '' : 's') + '.');
      grant = { emails: '', tier: grant.tier, until: '', note: '' };
      loadPatrons(); loadAudit();
    }, fail);
  }

  function exportPatrons() {
    function get() {
      return fetch('/api/admin/patrons/export', { credentials: 'same-origin' }).then(function (res) {
        if (res.ok) return res.blob();
        return res.json().catch(function () { return {}; }).then(function (j) {
          var err = new Error(j.error || 'Could not export.'); err.status = res.status; err.body = j; throw err;
        });
      });
    }
    get().catch(function (err) {
      if (!(err.status === 403 && err.body && err.body.code === 'reauth')) throw err;
      var code = window.prompt('Security check: enter the 6-digit code from your authenticator app. This file contains personal data.');
      if (!code || !code.trim()) { var c = new Error('Cancelled — nothing was exported.'); c.cancelled = true; throw c; }
      return Y.api('POST', '/api/auth/2fa/verify', { code: code.trim() }).then(get);
    }).then(function (blob) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'yunidoc-supporters-' + new Date().toISOString().slice(0, 10) + '.csv';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      loadAudit();
    }).catch(fail);
  }

  function move(arr, i, d) {
    var j = i + d;
    if (j < 0 || j >= arr.length) return false;
    var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    return true;
  }

  function download() {
    var blob = new Blob([JSON.stringify({ site: original }, null, 2) + '\n'], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'yunidoc-settings-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    if (dirty) toast('Note: unsaved changes are not in this file.', 'error');
  }

  function importFile() {
    var f = this.files && this.files[0];
    if (!f) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(reader.result);
        var site = parsed && (parsed.site || parsed);
        if (!site || !Array.isArray(site.servers)) throw new Error('bad');
        state = {
          servers: site.servers,
          modpacks: Array.isArray(site.modpacks) ? site.modpacks : [],
          fallback: site.fallback || Y.clone(DEFAULTS.fallback),
          announcement: site.announcement || Y.clone(DEFAULTS.announcement),
          about: site.about || Y.clone(state.about),
          support: site.support || Y.clone(state.support)
        };
        state.servers.forEach(function (s) {
          s.icon = s.icon || '\uD83C\uDFAE'; s.name = s.name || ''; s.ip = s.ip || ''; s.port = String(s.port || '');
          s.description = s.description || ''; s.hidden = s.hidden === true;
          s.access = s.access === 'patrons' ? 'patrons' : 'public'; s.publicOn = s.publicOn || '';
        });
        state.modpacks.forEach(function (p) {
          p.serverName = p.serverName || ''; p.name = p.name || 'Modpack'; p.version = p.version || ''; p.type = p.type === 'link' ? 'link' : 'zip'; p.url = p.url || '';
        });
        setDirty(true);
        toast('Imported. Review it, then click Save changes.');
        switchTab('servers');
      } catch (e) { toast('That file is not a valid settings file.', 'error'); }
    };
    reader.readAsText(f);
  }

  function save() {
    var errors = validate();
    if (errors.length) {
      if (tab !== 'servers') switchTab('servers');
      markInvalid();
      toast(errors[0].msg + (errors.length > 1 ? ' (+' + (errors.length - 1) + ' more)' : ''), 'error');
      return;
    }
    $('btn-save').disabled = true;
    secure('PUT', '/api/admin/site', { site: state, baseVersion: meta.version }).then(function (res) {
      state = Y.clone(res.site);
      original = Y.clone(res.site);
      meta = res.meta;
      setDirty(false);
      updateChip();
      toast('Saved. Your changes are live.');
      loadHealth();
      loadAudit();
      render();
    }, function (err) {
      $('btn-save').disabled = !dirty;
      if (err.status === 409) {
        if (window.confirm('Someone else saved changes while you were editing. Reload to see their version? (Your unsaved edits will be lost.)')) window.location.reload();
        return;
      }
      if (err.status === 400 && err.details && err.details.length) {
        toast(err.details[0] + (err.details.length > 1 ? ' (+' + (err.details.length - 1) + ' more)' : ''), 'error');
        return;
      }
      fail(err);
    });
  }

  function discard() {
    if (!dirty || !window.confirm('Discard all unsaved changes?')) return;
    state = Y.clone(original);
    setDirty(false);
    render();
  }

  function go(id) {
    tab = id;
    try { sessionStorage.setItem('yuni_admin_tab', id); } catch (e) { /* ignore */ }
    if (id === 'accounts') { loadAdmins(); loadUsers(); loadSecurity(); }
    if (id === 'overview') { loadAudit(); loadHealth(); loadBugs(); loadNotes(); loadPatrons(); loadOutages(); loadUptime(); }
    if (id === 'bugs') loadBugs();
    if (id === 'notes') loadNotes();
    if (id === 'patrons') loadPatrons();
    render();
    window.scrollTo(0, 0);
  }

  function switchTab(id) {
    if (id === tab) { window.scrollTo(0, 0); return; }
    go(id);
    try { history.pushState(null, '', '#' + id); } catch (e) { window.location.hash = id; }
  }

  function tabFromHash() {
    var id = window.location.hash.replace('#', '');
    return TABS.some(function (t) { return t.id === id; }) ? id : null;
  }

  window.addEventListener('popstate', function () { var id = tabFromHash(); if (id && id !== tab) go(id); });
  window.addEventListener('hashchange', function () { var id = tabFromHash(); if (id && id !== tab) go(id); });

  function focusNewCard() {
    var cards = document.querySelectorAll('#content .card');
    var last = cards[cards.length - 1];
    if (!last) return;
    last.scrollIntoView({ block: 'center' });
    var name = last.querySelector('[data-f="name"]');
    if (name) { name.focus(); name.select(); }
  }

  function addServer() {
    state.servers.push({ icon: '\uD83C\uDFAE', name: 'New Server', ip: state.servers.length ? state.servers[state.servers.length - 1].ip : '', port: '25565', description: '', hidden: false, access: 'public', publicOn: '' });
    serverFilter = '';
    setDirty(true); render(); focusNewCard();
  }

  function addPack() {
    state.modpacks.push({ serverName: packFilter || (state.servers[0] ? state.servers[0].name : ''), name: 'New Modpack', version: '', type: 'zip', url: 'downloads/modpack.zip' });
    setDirty(true); render(); focusNewCard();
  }

  function addAdmin(email) {
    email = String(email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Enter a valid email address.', 'error'); return; }
    secure('POST', '/api/admin/admins', { email: email }).then(function (r) {
      admins = r.admins;
      toast('Added. They become an admin when they sign in with that verified email.');
      loadUsers(); loadAudit(); render();
    }, fail);
  }

  function removeAdmin(email) {
    secure('DELETE', '/api/admin/admins/' + encodeURIComponent(email)).then(function (r) {
      admins = r.admins;
      toast('Admin access removed.');
      loadUsers(); loadAudit(); render();
    }, fail);
  }

  document.addEventListener('click', function (e) {
    var tb = e.target.closest('[data-tab]');
    if (tb) { switchTab(tb.dataset.tab); return; }
    var q = e.target.closest('[data-quick]');
    if (q) {
      if (q.dataset.quick === 'add-server') { switchTab('servers'); addServer(); }
      else if (q.dataset.quick === 'add-pack') { switchTab('modpacks'); addPack(); }
      return;
    }
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.dataset.act;
    var i = Number(el.dataset.i);
    var changed = true;

    switch (act) {
      case 'add-server': addServer(); return;
      case 'del':
        if (!window.confirm('Remove "' + state.servers[i].name + '"? Its modpacks stay but will be unassigned until you pick another server.')) return;
        state.servers.splice(i, 1);
        break;
      case 'up': changed = move(state.servers, i, -1); break;
      case 'down': changed = move(state.servers, i, 1); break;
      case 'dup': {
        var c = Y.clone(state.servers[i]);
        var base = c.name;
        var n = 2;
        while (serverNames().indexOf(base + ' ' + n) !== -1) n++;
        c.name = base + ' ' + n;
        state.servers.splice(i + 1, 0, c);
        break;
      }
      case 'check': checkServer(state.servers[i]); return;
      case 'check-all': checkAll(); return;
      case 'add-pack': addPack(); return;
      case 'pack-del': state.modpacks.splice(i, 1); break;
      case 'pack-up': changed = move(state.modpacks, i, -1); break;
      case 'pack-down': changed = move(state.modpacks, i, 1); break;
      case 'pack-dup': state.modpacks.splice(i + 1, 0, Y.clone(state.modpacks[i])); break;
      case 'download': download(); return;
      case 'restore-defaults':
        if (!window.confirm('Replace the current (unsaved) settings with the defaults?')) return;
        var keepAbout = state.about, keepSupport = state.support;
        state = Y.clone(DEFAULTS);
        state.about = keepAbout; state.support = keepSupport;
        break;
      case 'bug-filter': bugFilter = el.dataset.v; renderBugs(); return;
      case 'bug-save': saveBug(Number(el.dataset.id)); return;
      case 'bug-resolve': saveBug(Number(el.dataset.id), { status: 'resolved' }); return;
      case 'bug-del':
        if (!window.confirm('Delete this bug report permanently? Mark it resolved instead if you want to keep a record.')) return;
        Y.api('DELETE', '/api/admin/bugs/' + el.dataset.id).then(function () {
          bugs = bugs.filter(function (b) { return String(b.id) !== el.dataset.id; });
          delete bugDrafts[el.dataset.id];
          toast('Report deleted.'); loadAudit(); render();
        }, fail);
        return;
      case 'note-add': addNote(); return;
      case 'note-pin': {
        var nid = Number(el.dataset.id);
        var cur = notes.filter(function (n) { return n.id === nid; })[0];
        noteApi('PUT', nid, { pinned: !cur.pinned }).then(function (r) { replaceNote(r.note); render(); }, fail);
        return;
      }
      case 'note-edit': {
        editingNote = Number(el.dataset.id);
        render();
        var ta = document.querySelector('textarea[data-scope="noteedit"]');
        if (ta) { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }
        return;
      }
      case 'note-cancel': delete noteDrafts[el.dataset.id]; editingNote = null; render(); return;
      case 'note-save': {
        var sid = Number(el.dataset.id);
        var text = noteDrafts[sid];
        var orig = notes.filter(function (n) { return n.id === sid; })[0];
        if (text === undefined || text === orig.body) { editingNote = null; render(); return; }
        if (!text.trim()) { toast('A note cannot be empty. Delete it instead.', 'error'); return; }
        noteApi('PUT', sid, { body: text }).then(function (r) { replaceNote(r.note); delete noteDrafts[sid]; editingNote = null; toast('Note saved.'); render(); }, fail);
        return;
      }
      case 'note-del':
        if (!window.confirm('Delete this note?')) return;
        noteApi('DELETE', Number(el.dataset.id)).then(function () {
          notes = notes.filter(function (n) { return String(n.id) !== el.dataset.id; });
          toast('Note deleted.'); loadAudit(); render();
        }, fail);
        return;
      case 'path-add': {
        var list = getPath(state, el.dataset.path);
        if (list.length >= LIST_MAX[el.dataset.path]) return;
        list.push(Y.clone(NEW_ITEM[el.dataset.path]));
        setDirty(true); render(); focusNewCard();
        return;
      }
      case 'path-del': getPath(state, el.dataset.path).splice(i, 1); break;
      case 'path-up': changed = move(getPath(state, el.dataset.path), i, -1); break;
      case 'path-down': changed = move(getPath(state, el.dataset.path), i, 1); break;
      case 'patron-grant': grantPatrons(); return;
      case 'patron-export': exportPatrons(); return;
      case 'patron-save': {
        var em = el.dataset.email, d = patronDrafts[em];
        if (!d) return;
        var body = {};
        if (d.tier !== undefined) body.tier = d.tier;
        if (d.until !== undefined) body.until = d.until;
        if (d.hideWall !== undefined) body.hideWall = d.hideWall;
        secure('PUT', '/api/admin/patrons/' + encodeURIComponent(em), body).then(function () {
          delete patronDrafts[em]; toast('Saved.'); loadPatrons(); loadAudit();
        }, fail);
        return;
      }
      case 'patron-del':
        if (!window.confirm('Remove ' + el.dataset.email + ' from the supporters? They lose their perks right away.')) return;
        secure('DELETE', '/api/admin/patrons/' + encodeURIComponent(el.dataset.email)).then(function () {
          delete patronDrafts[el.dataset.email]; toast('Removed.'); loadPatrons(); loadAudit();
        }, fail);
        return;
      case 'new-codes':
        if (!window.confirm('Make new recovery codes? Your old codes will stop working.')) return;
        secure('POST', '/api/auth/2fa/recovery-codes', {}).then(function (r) { freshCodes = r.recoveryCodes; toast('New recovery codes made. Save them now.'); loadSecurity(); }, fail);
        return;
      case 'logout-all':
        if (!window.confirm('Sign out of this account on every device, including this one?')) return;
        dirty = false;
        Y.api('POST', '/api/auth/logout-all', {}).then(function () { window.location.href = '/admin/login.html'; }, fail);
        return;
      case 'add-admin': addAdmin($('new-admin').value); return;
      case 'grant-admin': addAdmin(el.dataset.email); return;
      case 'rm-admin':
        if (!window.confirm('Remove admin access for ' + el.dataset.email + '?')) return;
        removeAdmin(el.dataset.email);
        return;
      case 'del-user':
        if (!window.confirm('Delete the account ' + el.dataset.email + '? They will be signed out.')) return;
        secure('DELETE', '/api/admin/users/' + encodeURIComponent(el.dataset.id)).then(function () {
          toast('Account deleted.');
          loadUsers(); loadAudit();
        }, fail);
        return;
      default: return;
    }
    if (changed) { setDirty(true); render(); }
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    var scope = t.dataset && t.dataset.scope;
    if (!scope) return;
    var v = t.type === 'checkbox' ? t.checked : t.value;

    // Bug reports and notes save to the server on their own; they are not part of the site-settings draft.
    if (scope === 'bug') {
      var bid = Number(t.dataset.id);
      var bug = bugs.filter(function (x) { return x.id === bid; })[0];
      var dr = bugDrafts[bid] || (bugDrafts[bid] = {});
      dr[t.dataset.f] = v;
      var marker = document.querySelector('[data-unsaved="' + bid + '"]');
      if (marker) marker.textContent = bugIsDirty(bug) ? 'Unsaved changes' : '';
      return;
    }
    if (scope === 'newnote') { newNote[t.dataset.f] = v; return; }
    if (scope === 'noteedit') { noteDrafts[t.dataset.id] = v; return; }
    if (scope === 'grant') { grant[t.dataset.f] = v; return; }
    if (scope === 'pdraft') {
      var em2 = t.dataset.email;
      (patronDrafts[em2] || (patronDrafts[em2] = {}))[t.dataset.f] = v;
      var sv = Array.prototype.filter.call(document.querySelectorAll('[data-act="patron-save"]'), function (b) { return b.dataset.email === em2; })[0];
      if (sv) sv.disabled = false;
      return;
    }
    if (scope === 'path') {
      var kind = t.dataset.kind;
      var val = v;
      if (kind === 'list') val = String(v).split('\n');
      else if (kind === 'number') val = v === '' ? 0 : Number(v);
      setPath(state, t.dataset.path, val);
      setDirty(true);
      renderSidebar();
      return;
    }
    var i = Number(t.dataset.i);
    var f = t.dataset.f;

    if (scope === 'server') {
      var s = state.servers[i];
      if (f === 'name') {
        // keep modpacks attached when a server is renamed
        state.modpacks.forEach(function (p) { if (p.serverName === s.name) p.serverName = v; });
      }
      s[f] = v;
      if (f === 'ip' || f === 'port') {
        var holder = t.closest('.card').querySelector('[data-skey]');
        if (holder) { holder.dataset.skey = addrKey(s); updatePills(); }
      }
      if (f === 'hidden') t.closest('.card').classList.toggle('is-hidden', v);
      markInvalid();
    } else if (scope === 'pack') {
      state.modpacks[i][f] = v;
    } else if (scope === 'fb') {
      state.fallback[f] = v;
    } else if (scope === 'ann') {
      state.announcement[f] = v;
      var pv = $('ann-preview');
      if (pv) {
        pv.className = 'preview-banner lvl-' + state.announcement.level;
        pv.innerHTML = esc(state.announcement.text) || '<span style="opacity:.6">Your message appears here</span>';
      }
    }
    setDirty(true);
    renderSidebar();
  });

  $('btn-save').addEventListener('click', save);
  $('btn-discard').addEventListener('click', discard);
  $('btn-logout').addEventListener('click', function () {
    if (dirty && !window.confirm('You have unsaved changes. Log out anyway?')) return;
    dirty = false;
    Y.api('POST', '/api/auth/logout', {}).then(
      function () { window.location.href = '/admin/login.html'; },
      function () { window.location.href = '/admin/login.html'; }
    );
  });

  document.addEventListener('keydown', function (e) {
    if (e.target && e.target.id === 'new-admin' && e.key === 'Enter') { e.preventDefault(); addAdmin(e.target.value); return; }
    if (e.target && e.target.id === 'new-note' && e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); addNote(); return; }
    if (e.altKey && !e.ctrlKey && !e.metaKey && /^[1-9]$/.test(e.key) && TABS[+e.key - 1]) {
      e.preventDefault();
      switchTab(TABS[+e.key - 1].id);
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      if (dirty) save();
    }
  });

  window.addEventListener('beforeunload', function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ''; }
  });

  // \u2500\u2500 start \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  Y.me().then(function (user) {
    if (!user) { window.location.href = '/admin/login.html'; return null; }
    if (!user.isAdmin) { window.location.href = user.mfa ? '/admin/2fa.html' : '/admin/member.html'; return null; }
    me = user;
    return Y.api('GET', '/api/admin/site');
  }).then(function (res) {
    if (!res) return;
    state = Y.clone(res.site);
    original = Y.clone(res.site);
    meta = res.meta;
    document.body.classList.remove('checking-auth');

    var saved = null;
    try { saved = sessionStorage.getItem('yuni_admin_tab'); } catch (e) { /* ignore */ }
    if (TABS.some(function (t) { return t.id === saved; })) tab = saved;
    if (tabFromHash()) tab = tabFromHash();
    try { history.replaceState(null, '', '#' + tab); } catch (e) { /* ignore */ }

    updateChip();
    render();
    loadAdmins(); loadUsers(); loadAudit(); loadHealth(); loadBugs(); loadNotes(); loadSecurity(); loadPatrons(); loadOutages(); loadUptime();
  }).catch(fail);
}());
