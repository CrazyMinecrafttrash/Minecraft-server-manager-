(function () {
  'use strict';

  var Y = window.Yuni;
  function $(id) { return document.getElementById(id); }
  function notice(msg, good) {
    var n = $('notice');
    n.textContent = msg;
    n.classList.toggle('good', Boolean(good));
    n.classList.add('visible');
  }
  function clearNotice() { $('notice').classList.remove('visible'); }
  function home(user) { window.location.href = user.isAdmin ? '/admin/dashboard.html' : '/admin/member.html'; }
  var wantsSetup = /[?&]setup=1/.test(window.location.search);

  Y.me().then(function (user) {
    if (!user) { window.location.href = '/admin/login.html'; return; }
    if (user.mfa === 'verify') { showVerify(); return; }
    if (user.mfa === 'setup' || (wantsSetup && user.isAdmin && !user.totpEnabled)) { startSetup(); return; }
    home(user);
  }, function () { window.location.href = '/admin/login.html'; });

  function showVerify() {
    $('subtitle').textContent = 'Enter the code from your authenticator app to open the admin panel';
    $('verify').hidden = false;
    $('code').focus();
  }

  function startSetup() {
    $('title').textContent = 'Set up two-factor sign-in';
    $('subtitle').textContent = 'Required for admins. Takes about a minute.';
    Y.api('POST', '/api/auth/2fa/setup', {}).then(function (r) {
      $('qr').innerHTML = window.YuniQR.svg(r.uri);
      $('secret').textContent = r.secret.replace(/(.{4})/g, '$1 ').trim();
      $('otp-link').href = r.uri;
      if (r.emailCodeSent) {
        $('email-code-group').hidden = false;
        notice('We also emailed you a 6-digit code to prove it is really you. Check your inbox (and spam).', true);
      }
      $('setup').hidden = false;
    }, function (err) { notice(err.message); });
  }

  $('setup-form').addEventListener('submit', function (e) {
    e.preventDefault();
    clearNotice();
    var code = $('setup-code').value.replace(/\s/g, '');
    if (!/^\d{6}$/.test(code)) { notice('Enter the 6-digit code from the app.'); return; }
    var btn = e.target.querySelector('button');
    btn.disabled = true;
    Y.api('POST', '/api/auth/2fa/enable', { code: code, emailCode: $('email-code').value.replace(/\s/g, '') }).then(function (r) {
      $('setup').hidden = true;
      showCodes(r.recoveryCodes, r.user);
    }, function (err) { notice(err.message); btn.disabled = false; });
  });

  $('verify-form').addEventListener('submit', function (e) {
    e.preventDefault();
    clearNotice();
    var code = $('code').value.trim();
    if (!code) { notice('Enter the code from your app.'); return; }
    var btn = e.target.querySelector('button');
    btn.disabled = true;
    Y.api('POST', '/api/auth/2fa/verify', { code: code }).then(function (r) {
      if (r.usedRecovery) {
        notice('Recovery code accepted. You have ' + r.recoveryCodesLeft + ' left. Make new ones in Accounts → Your security.', true);
        setTimeout(function () { home(r.user); }, 2500);
        return;
      }
      home(r.user);
    }, function (err) { notice(err.message); btn.disabled = false; $('code').select(); });
  });

  var codesText = '';
  function showCodes(codes, user) {
    $('title').textContent = 'Two-factor sign-in is on';
    $('subtitle').textContent = 'One last step';
    $('code-list').innerHTML = codes.map(function (c) { return '<div>' + Y.esc(c) + '</div>'; }).join('');
    codesText = 'YuniDoc recovery codes (each works once)\n\n' + codes.join('\n') + '\n';
    $('codes').hidden = false;
    $('continue').addEventListener('click', function () { home(user); });
  }
  $('saved').addEventListener('change', function () { $('continue').disabled = !this.checked; });
  $('copy-codes').addEventListener('click', function () {
    navigator.clipboard.writeText(codesText).then(function () { notice('Copied.', true); }, function () { notice('Copy failed. Select the codes and copy them by hand.'); });
  });
  $('download-codes').addEventListener('click', function () {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([codesText], { type: 'text/plain' }));
    a.download = 'yunidoc-recovery-codes.txt';
    document.body.appendChild(a); a.click(); a.remove();
  });
  $('logout').addEventListener('click', function () {
    Y.api('POST', '/api/auth/logout', {}).then(function () { window.location.href = '/admin/login.html'; }, function () { window.location.href = '/admin/login.html'; });
  });
}());
