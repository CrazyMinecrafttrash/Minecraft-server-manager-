(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }
  function showNotice(msg) { var n = $('notice'); n.textContent = msg; n.classList.add('visible'); }

  // Take the one-time token out of the address bar right away so it is not left in history.
  var token = new URLSearchParams(window.location.search).get('token') || '';
  history.replaceState(null, '', window.location.pathname);
  if (!token) {
    $('verify-form').hidden = true;
    showNotice('This link is missing its code. Open the link from your email again, or request a new one.');
  }

  $('verify-form').addEventListener('submit', function (e) {
    e.preventDefault();
    $('notice').classList.remove('visible');
    var password = $('password').value;
    if (password.length < 10) { showNotice('Your password must be at least 10 characters long.'); return; }
    if (password !== $('confirm-password').value) { showNotice('Passwords do not match.'); return; }

    var btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    Yuni.api('POST', '/api/auth/verify', { token: token, password: password }).then(function (res) {
      window.location.href = res.user.mfa ? '/admin/2fa.html' : res.user.isAdmin ? '/admin/dashboard.html' : '/admin/member.html';
    }, function (err) {
      showNotice(err.message);
      btn.disabled = false;
    });
  });
}());
