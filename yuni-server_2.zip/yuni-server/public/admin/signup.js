(function () {
  'use strict';

  var emailMode = false;
  function $(id) { return document.getElementById(id); }

  function showNotice(msg, good) {
    var n = $('notice');
    n.textContent = msg;
    n.classList.toggle('good', Boolean(good));
    n.classList.add('visible');
  }

  Yuni.me().then(function (user) {
    if (user) window.location.href = user.mfa ? '/admin/2fa.html' : user.isAdmin ? '/admin/dashboard.html' : '/admin/member.html';
  }, function () { /* show the form */ });

  // When the site can send email, signing up only asks for the address; the password comes after the emailed link.
  Yuni.api('GET', '/api/auth/providers').then(function (p) {
    emailMode = Boolean(p.emailVerification);
    if (emailMode) {
      $('password-fields').hidden = true;
      $('email-note').hidden = false;
      document.querySelector('h1').textContent = 'Sign up or reset password';
      document.querySelector('#signup-form button[type="submit"]').textContent = 'Email me a link';
    }
  }, function () { /* keep the password form */ });

  $('signup-form').addEventListener('submit', function (e) {
    e.preventDefault();
    $('notice').classList.remove('visible');
    var email = $('email').value.trim();
    var btn = e.target.querySelector('button[type="submit"]');

    if (emailMode) {
      if (!email) { showNotice('Please enter your email address.'); return; }
      btn.disabled = true;
      Yuni.api('POST', '/api/auth/signup', { email: email }).then(function () {
        e.target.hidden = true;
        showNotice('Check your inbox! If that address can be used, we sent a link that works once and expires in an hour. Check your spam folder too.', true);
      }, function (err) {
        showNotice(err.message);
        btn.disabled = false;
      });
      return;
    }

    var password = $('password').value;
    var confirm = $('confirm-password').value;
    if (!email || !password || !confirm) { showNotice('Please fill in every field.'); return; }
    if (password.length < 10) { showNotice('Your password must be at least 10 characters long.'); return; }
    if (password !== confirm) { showNotice('Passwords do not match.'); return; }
    btn.disabled = true;
    Yuni.api('POST', '/api/auth/signup', { email: email, password: password }).then(function () {
      window.location.href = '/admin/member.html';
    }, function (err) {
      showNotice(err.message);
      btn.disabled = false;
    });
  });
}());
