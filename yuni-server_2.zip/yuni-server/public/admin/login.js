(function () {
  'use strict';

  var ERRORS = {
    denied: 'Sign-in was cancelled.',
    state: 'That sign-in link expired or was not valid. Please try again.',
    unverified: 'Your account needs a verified email address to sign in this way.',
    provider_error: 'The sign-in service had a problem. Please try again.',
    provider_unavailable: 'That sign-in method is not set up on this site.',
    expired: 'You were signed out for inactivity. Please sign in again.'
  };

  function $(id) { return document.getElementById(id); }

  function showError(msg) {
    var box = $('error-box');
    box.textContent = msg;
    box.classList.add('visible');
  }
  function clearError() {
    var box = $('error-box');
    box.textContent = '';
    box.classList.remove('visible');
  }

  function goHome(user) {
    window.location.href = user.mfa ? '/admin/2fa.html' : user.isAdmin ? '/admin/dashboard.html' : '/profile.html';
  }

  // Already signed in? Skip the form.
  Yuni.me().then(function (user) { if (user) goHome(user); }, function () { /* show the form */ });

  // Show only the sign-in methods this site has configured.
  Yuni.api('GET', '/api/auth/providers').then(function (p) {
    ['google', 'discord'].forEach(function (name) {
      var el = $('btn-' + name);
      if (p[name]) el.removeAttribute('aria-disabled');
      else el.title = 'Not set up on this site yet';
    });
    if (p.emailVerification) $('forgot-link').hidden = false;
  }, function () { /* leave disabled */ });

  var code = new URLSearchParams(window.location.search).get('error');
  if (code) {
    showError(ERRORS[code] || 'Sign-in failed. Please try again.');
    history.replaceState(null, '', window.location.pathname);
  }

  $('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    clearError();
    var email = $('inp-email').value.trim();
    var password = $('inp-password').value;
    if (!email || !password) { showError('Please enter your email and password.'); return; }

    var btn = $('btn-signin');
    btn.textContent = 'Signing in…';
    btn.disabled = true;
    Yuni.api('POST', '/api/auth/login', { email: email, password: password }).then(function (res) {
      goHome(res.user);
    }, function (err) {
      showError(err.message);
      btn.textContent = 'Sign In';
      btn.disabled = false;
    });
  });

  $('toggle-pw').addEventListener('click', function () {
    var inp = $('inp-password');
    var showing = inp.type === 'text';
    inp.type = showing ? 'password' : 'text';
    this.textContent = showing ? '👁' : '🙈';
    this.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
  });
}());
