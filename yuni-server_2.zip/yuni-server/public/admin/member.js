(function () {
  'use strict';
  // The member area now lives on the profile page.
  window.location.replace('/profile.html');
}());
