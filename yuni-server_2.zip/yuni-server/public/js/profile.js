(function () {
  'use strict';
  var esc = Yuni.esc;
  var $ = function (id) { return document.getElementById(id); };
  var BUG_STATUS = { open: 'Open', in_progress: 'In progress', resolved: 'Resolved', wont_fix: "Won't fix" };

  function dateStr(ts) { return new Date(ts).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }); }

  function renderProfile(p, site) {
    $('mc').value = p.mcUsername || '';
    $('dn').value = p.displayName || '';
    $('wall').checked = !!p.wallOptIn;
    var supportOn = !!(site && site.support && site.support.enabled);
    $('wall-row').hidden = !supportOn;

    var st = $('patron-status');
    var perksBox = $('perks');
    perksBox.innerHTML = '';
    if (p.patron && p.patron.tier) {
      st.className = 'status-line good';
      st.textContent = 'Thank you! You are a ' + (p.patron.tierName || p.patron.tier) + (p.patron.until ? ' until ' + dateStr(p.patron.until) : '') + '.';
      var tier = site && site.support && (site.support.tiers || []).filter(function (t) { return t.id === p.patron.tier; })[0];
      if (tier && tier.perks && tier.perks.length) {
        perksBox.innerHTML = '<p style="margin:0 0 6px">Your perks:</p><ul>' + tier.perks.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>';
      }
    } else {
      st.className = 'status-line';
      st.textContent = supportOn
        ? 'You are not a supporter yet. If you already supported us, perks are switched on by hand using the email you paid with.'
        : 'Supporter perks are not open yet.';
    }
    $('supporter-box').hidden = !supportOn && !(p.patron && p.patron.tier);
  }

  function renderBadges(user, patron) {
    var b = [];
    if (user.isOwner) b.push('<span class="badge good">Owner</span>');
    else if (user.isAdmin) b.push('<span class="badge good">Admin</span>');
    if (patron && patron.tier) b.push('<span class="badge early">⭐ ' + esc(patron.tierName || patron.tier) + '</span>');
    b.push('<span class="badge' + (user.emailVerified ? ' good' : '') + '">' + (user.emailVerified ? 'Email verified' : 'Email not verified') + '</span>');
    $('badges').innerHTML = b.join('');
  }

  function renderEarly(site) {
    var early = (site.servers || []).filter(function (s) { return s.early && s.ip; });
    $('early-box').hidden = !early.length;
    $('early-list').innerHTML = early.map(function (s) {
      var addr = s.port ? s.ip + ':' + s.port : s.ip;
      return '<li><span>' + esc(s.icon) + ' ' + esc(s.name) + (s.publicOn ? ' <span class="small">(opens to everyone ' + esc(s.publicOn) + ')</span>' : '') +
        '</span><code>' + esc(addr) + '</code></li>';
    }).join('');
  }

  function renderBugs(list) {
    $('bugs').innerHTML = list.length ? list.map(function (b) {
      return '<li><span>#' + b.id + ' ' + esc(b.title) + ' <span class="small">· ' + esc(dateStr(b.createdAt)) + '</span></span><span class="badge">' + esc(BUG_STATUS[b.status] || b.status) + '</span></li>';
    }).join('') : '<li class="small">You have not sent any bug reports.</li>';
  }

  function renderSecurity(user, sec) {
    var rows = [];
    rows.push('<li><span>Email</span><span>' + esc(user.email) + '</span></li>');
    rows.push('<li><span>Two-factor sign-in</span><span class="badge' + (sec.totpEnabled ? ' good' : '') + '">' + (sec.totpEnabled ? 'On' : 'Off') + '</span></li>');
    if (sec.totpEnabled) rows.push('<li><span>Recovery codes left</span><span>' + sec.recoveryCodesLeft + '</span></li>');
    rows.push('<li><span>Signed-in devices</span><span>' + sec.activeSessions + '</span></li>');
    $('security').innerHTML = rows.join('');
  }

  function leave() { window.location.href = '/index.html'; }

  Yuni.me().then(function (user) {
    if (!user) { $('signedout').hidden = false; return null; }
    if (user.mfa) { window.location.href = '/admin/2fa.html'; return null; }
    $('signedin').hidden = false;
    $('who').textContent = user.email;
    $('avatar').textContent = user.email.charAt(0).toUpperCase();
    $('admin-link').hidden = !user.isAdmin;

    return Promise.all([
      Yuni.api('GET', '/api/me/profile'),
      Yuni.api('GET', '/api/site'),
      Yuni.api('GET', '/api/bugs/mine').catch(function () { return { bugs: [] }; }),
      Yuni.api('GET', '/api/auth/security').catch(function () { return { totpEnabled: false, recoveryCodesLeft: 0, activeSessions: 1 }; })
    ]).then(function (r) {
      var profile = r[0], site = r[1];
      document.querySelectorAll('[data-support-link]').forEach(function (el) { el.hidden = !(site.support && site.support.enabled); });
      renderBadges(user, profile.patron);
      renderProfile(profile, site);
      renderEarly(site);
      renderBugs(r[2].bugs || []);
      renderSecurity(user, r[3]);
      window.__site = site;
    });
  }).catch(function (err) {
    $('signedout').hidden = false;
    $('signedin').hidden = true;
    void err;
  });

  $('profile-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = $('profile-msg');
    msg.className = 'msg'; msg.textContent = 'Saving…';
    Yuni.api('PUT', '/api/me/profile', {
      mcUsername: $('mc').value.trim(), displayName: $('dn').value.trim(), wallOptIn: $('wall').checked
    }).then(function (p) { renderProfile(p, window.__site); msg.className = 'msg ok'; msg.textContent = 'Saved.'; },
      function (err) { msg.className = 'msg bad'; msg.textContent = err.message; });
  });

  $('btn-logout').addEventListener('click', function () {
    Yuni.api('POST', '/api/auth/logout', {}).then(leave, leave);
  });
  $('btn-logout-all').addEventListener('click', function () {
    if (!window.confirm('Sign out of this account on every device, including this one?')) return;
    Yuni.api('POST', '/api/auth/logout-all', {}).then(leave, leave);
  });
}());
