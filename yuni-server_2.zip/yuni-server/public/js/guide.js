(function () {
  'use strict';
  var esc = Yuni.esc;
  var safeUrl = Yuni.safeUrl;
  var DATA = null;
  var select = document.getElementById('server-select');

  function getServerDownloads(serverName) {
    var key = String(serverName || '').toLowerCase();
    var own = DATA.modpacks.filter(function (p) { return (p.serverName || '').toLowerCase() === key && p.url; });
    if (own.length) return own;
    var fb = DATA.fallback;
    return [{ name: fb.name || 'Modpack', version: '', type: fb.download === false ? 'link' : 'zip', url: fb.url }];
  }

  function renderDownloadList(downloads) {
    document.getElementById('download-list').innerHTML = downloads.map(function (item, index) {
      var isLink = item.type === 'link';
      var href = safeUrl(item.url) || '#';
      var label = isLink ? 'Open Website →' : 'Download Zip →';
      var attrs = isLink ? 'target="_blank" rel="noopener noreferrer"' : 'download';
      var cls = index === 0 ? 'btn btn-primary' : 'btn btn-outline';
      return '<div class="download-item">' +
        '<div class="download-item-title">' + esc(item.name || 'Modpack') +
          (item.version ? ' <span style="color:var(--muted)">· v' + esc(item.version) + '</span>' : '') + '</div>' +
        '<a class="' + cls + '" href="' + esc(href) + '" ' + attrs + '>' + label + '</a></div>';
    }).join('');
  }

  function updateGuideDownload() {
    var chosen = select.value;
    try { localStorage.setItem('yuni_selected_server', chosen); } catch (e) { /* storage may be blocked */ }
    document.getElementById('download-name').textContent = chosen ? chosen + ' Modpacks' : DATA.fallback.name;
    document.getElementById('download-description').textContent = chosen
      ? 'Choose any pack below for ' + chosen + '.' : 'Save it somewhere easy to find.';
    renderDownloadList(getServerDownloads(chosen));
  }

  function updateStepper() {
    var steps = document.querySelectorAll('.guide-step');
    var items = document.querySelectorAll('.stepper-item');
    var active = 0;
    var threshold = window.scrollY + window.innerHeight * 0.35;
    for (var i = 0; i < steps.length; i++) {
      if (threshold >= steps[i].offsetTop) active = i;
    }
    // short last steps can never reach the threshold, so treat the page bottom as the last step
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) active = steps.length - 1;
    items.forEach(function (item, index) {
      item.classList.toggle('active', index === active);
      item.classList.toggle('done', index < active);
    });
  }

  Yuni.loadSite(function (data) {
    if (!data) {
      document.getElementById('download-description').textContent = 'Could not load downloads right now. Please refresh in a moment.';
      return;
    }
    DATA = data;
    data.servers = data.servers.filter(function (s) { return !s.locked; });
    select.innerHTML = data.servers.map(function (s) {
      return '<option value="' + esc(s.name) + '">' + esc(s.name) + '</option>';
    }).join('');
    var saved = null;
    try { saved = localStorage.getItem('yuni_selected_server'); } catch (e) { /* ignore */ }
    if (saved && data.servers.some(function (s) { return s.name === saved; })) select.value = saved;
    select.addEventListener('change', updateGuideDownload);
    updateGuideDownload();
  });

  window.addEventListener('scroll', updateStepper, { passive: true });
  updateStepper();
}());
