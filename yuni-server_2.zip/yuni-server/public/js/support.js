(function () {
  'use strict';
  var esc = Yuni.esc;
  var $ = function (id) { return document.getElementById(id); };
  var support = null;

  function host(url) { try { return new URL(url).host; } catch (e) { return ''; } }

  function renderSupport(data) {
    support = data.support || { enabled: false };
    if (support.headline) $('headline').textContent = support.headline;
    $('intro').textContent = support.intro || '';
    if (!support.enabled) { $('closed').hidden = false; return; }
    $('content').hidden = false;

    $('pledge').innerHTML = (support.pledge || []).map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('');

    var g = support.goal || {};
    var cur = g.currency || '$';
    if (g.monthlyCost > 0) {
      var pct = Math.max(0, Math.min(100, Math.round((g.raised || 0) / g.monthlyCost * 100)));
      $('goal-text').textContent = cur + (g.raised || 0) + ' of ' + cur + g.monthlyCost + ' per month (' + pct + '%)';
      $('meter-bar').style.width = pct + '%';
      $('meter').setAttribute('aria-valuenow', String(pct));
      $('goal-note').textContent = g.note || '';
      $('costs').innerHTML = (support.costs || []).map(function (c) {
        return '<tr><td>' + esc(c.label) + '</td><td>' + esc(cur) + esc(c.amount) + '</td></tr>';
      }).join('');
      $('goal-box').hidden = false;
    }

    var tiers = support.tiers || [];
    $('tiers').innerHTML = tiers.map(function (t) {
      var btn = t.url
        ? '<a class="btn btn-primary" href="' + esc(Yuni.safeUrl(t.url)) + '" target="_blank" rel="noopener noreferrer">Join as ' + esc(t.name) + ' \u2192</a><span class="small" style="text-align:center">Opens ' + esc(host(t.url)) + '</span>'
        : '<span class="btn btn-outline" aria-disabled="true">Joining opens soon</span>';
      return '<div class="card-box"><h3>' + esc(t.name) + '</h3><div class="price">' + esc(t.price) + '</div>' +
        (t.earlyAccess ? '<span class="badge early">⭐ Early access</span>' : '') +
        (t.description ? '<p class="desc">' + esc(t.description) + '</p>' : '') +
        '<div class="small" style="font-weight:700;color:var(--white)">What you get</div><ul>' + (t.perks || []).map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul>' + btn + '</div>';
    }).join('');
    $('pay-note').textContent = 'Payments are handled by the provider on the button. We never see your card details.';

    var cos = support.cosmetics || [];
    $('cosmetics-box').hidden = !cos.length;
    $('cosmetics').innerHTML = cos.map(function (c) {
      var tier = tiers.filter(function (t) { return t.id === c.tier; })[0];
      return '<div class="card-box"><h3>' + esc(c.name) + '</h3>' + (c.description ? '<p class="desc">' + esc(c.description) + '</p>' : '') +
        (tier ? '<span class="badge">' + esc(tier.name) + ' and up</span>' : '') + '</div>';
    }).join('');

    var early = (data.servers || []).filter(function (s) { return s.early; });
    $('early').innerHTML = early.length ? early.map(function (s) {
      return '<div class="card-box"><h3>' + esc(s.icon) + ' ' + esc(s.name) + '</h3>' +
        (s.description ? '<p class="desc">' + esc(s.description) + '</p>' : '') +
        (s.publicOn ? '<p class="small">Opens to everyone on ' + esc(s.publicOn) + '</p>' : '') + '</div>';
    }).join('') : '<p class="small">No upcoming servers are announced yet. Supporters hear first when one is.</p>';

    loadWall(false);
  }

  function loadWall(fresh) {
    fetch('/api/patrons/wall', { credentials: 'same-origin', cache: fresh ? 'reload' : 'default' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (w) {
      var list = (w && w.wall) || [];
      $('wall-box').hidden = !list.length;
      $('wall-list').innerHTML = list.map(function (p) {
        return '<span>' + esc(p.name) + (p.tier ? '<small>' + esc(p.tier) + '</small>' : '') + '</span>';
      }).join('');
    }).catch(function () {});
  }

  function renderProfile(p) {
    $('mc').value = p.mcUsername || '';
    $('dn').value = p.displayName || '';
    $('wall').checked = !!p.wallOptIn;
    var st = $('patron-status');
    if (p.patron && p.patron.tier) {
      st.className = 'status-line good';
      st.textContent = 'Thank you! You are a ' + (p.patron.tierName || p.patron.tier) + (p.patron.until ? ' until ' + new Date(p.patron.until).toISOString().slice(0, 10) : '') +
        (p.patron.earlyAccess ? ', with early access to new servers.' : '.');
    } else {
      st.className = 'status-line';
      st.textContent = 'No active supporter status on ' + 'this account' + ' yet. After you support us, perks are switched on by hand, usually within a day.';
    }
    $('profile-form').hidden = false;
  }

  Yuni.loadSite(function (data) {
    if (!data) { $('closed').hidden = false; $('closed').textContent = 'Could not load this page right now. Please refresh.'; return; }
    renderSupport(data);
    if (!support.enabled) return;
    Yuni.me().then(function (user) {
      if (!user) { $('profile-signedout').hidden = false; return; }
      return Yuni.api('GET', '/api/me/profile').then(renderProfile);
    }).catch(function () { $('profile-signedout').hidden = false; });
  });

  $('profile-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = $('profile-msg');
    msg.className = 'msg'; msg.textContent = 'Saving…';
    Yuni.api('PUT', '/api/me/profile', {
      mcUsername: $('mc').value.trim(), displayName: $('dn').value.trim(), wallOptIn: $('wall').checked
    }).then(function (p) { renderProfile(p); msg.className = 'msg ok'; msg.textContent = 'Saved.'; loadWall(true); },
      function (err) { msg.className = 'msg bad'; msg.textContent = err.message; });
  });
}());
