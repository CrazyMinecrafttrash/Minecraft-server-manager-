(function () {
  'use strict';
  var esc = Yuni.esc;
  Yuni.loadSite(function (data) {
    var a = data && data.about;
    if (!a) {
      document.getElementById('story').innerHTML = '<p class="small">Could not load this page right now. Please refresh in a moment.</p>';
      return;
    }
    if (a.headline) document.getElementById('headline').textContent = a.headline;
    var paras = String(a.story || '').split(/\n\s*\n/).map(function (p) { return p.trim(); }).filter(Boolean);
    document.getElementById('story').innerHTML = paras.map(function (p) {
      return '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>';
    }).join('');
    var vals = a.values || [];
    document.getElementById('promise-title').hidden = !vals.length;
    document.getElementById('values').innerHTML = vals.map(function (v) {
      return '<div class="card-box"><h3>' + esc(v.title) + '</h3><p class="desc">' + esc(v.text) + '</p></div>';
    }).join('');
    var team = a.team || [];
    document.getElementById('team-title').hidden = !team.length;
    document.getElementById('team').innerHTML = team.map(function (m) {
      return '<div class="card-box team-card"><h3>' + esc(m.name) + '</h3><span class="role">' + esc(m.role) +
        '</span>' + (m.bio ? '<p class="desc">' + esc(m.bio) + '</p>' : '') + '</div>';
    }).join('');
  });
}());
