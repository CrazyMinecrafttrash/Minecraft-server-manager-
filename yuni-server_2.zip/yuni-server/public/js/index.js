(function () {
  'use strict';
  var esc = Yuni.esc;
  var grid = document.getElementById('server-grid');

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise(function (resolve, reject) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy') ? resolve() : reject(); } catch (e) { reject(e); }
      ta.remove();
    });
  }

  function findBy(attr, name) {
    return Array.prototype.filter.call(grid.querySelectorAll('[' + attr + ']'), function (el) { return el.getAttribute(attr) === name; })[0];
  }

  grid.addEventListener('click', function (e) {
    var tog = e.target.closest('[data-report-toggle]');
    if (tog) {
      var menu = findBy('data-report-menu', tog.getAttribute('data-report-toggle'));
      if (menu) menu.hidden = !menu.hidden;
      return;
    }
    var rep = e.target.closest('[data-report]');
    if (rep) {
      var holder = rep.parentNode;
      Yuni.reportProblem(rep.getAttribute('data-server'), rep.getAttribute('data-report')).then(function (msg) {
        holder.innerHTML = '<span class="small">' + esc(msg) + '</span>';
        loadHealth();
      }, function (err) { holder.innerHTML = '<span class="small">' + esc(err.message) + '</span>'; });
      return;
    }
    var btn = e.target.closest('.btn-copy');
    if (!btn) return;
    var original = btn.dataset.label || btn.textContent;
    btn.dataset.label = original;
    copyText(btn.dataset.addr).then(function () {
      btn.textContent = 'Copied!';
      btn.classList.add('copied');
    }, function () {
      btn.textContent = 'Press Ctrl+C';
    }).then(function () {
      setTimeout(function () { btn.textContent = original; btn.classList.remove('copied'); }, 2000);
    });
  });

  function renderBanner(a) {
    var old = document.getElementById('site-banner');
    if (old) old.remove();
    if (!a || !a.enabled || !a.text) return;
    var colors = {
      info:    ['rgba(88,101,242,.16)', 'rgba(88,101,242,.5)', '#c5caff'],
      warn:    ['rgba(255,190,0,.1)',   'rgba(255,190,0,.4)',  '#ffcf5a'],
      success: ['rgba(34,170,68,.12)',  'rgba(34,170,68,.45)', '#6fdc8c']
    }[a.level] || ['', '', ''];
    var bar = document.createElement('div');
    bar.id = 'site-banner';
    bar.setAttribute('role', 'status');
    bar.style.cssText = 'padding:10px 20px;text-align:center;font-size:.92rem;background:' + colors[0] +
      ';border-bottom:1px solid ' + colors[1] + ';color:' + colors[2];
    bar.textContent = a.text;
    document.querySelector('nav').insertAdjacentElement('afterend', bar);
  }

  function openDate(srv) {
    return srv.publicOn ? '<span class="small">Opens to everyone on ' + esc(srv.publicOn) + '</span>' : '';
  }
  function badgeFor(srv) {
    return srv.early ? '<p style="margin:0 0 8px"><span class="badge early">\u2B50 Early access</span> ' + openDate(srv) + '</p>' : '';
  }
  function lockedCard(srv) {
    return '<div class="server-card is-locked">' +
      '<div class="server-icon">' + esc(srv.icon) + '</div>' +
      '<h3 class="server-name">' + esc(srv.name) + '</h3>' +
      '<p style="margin:0 0 8px"><span class="badge locked">\uD83D\uDD12 Supporter early access</span></p>' +
      '<p class="server-address">Address shared with supporters</p>' +
      (srv.description ? '<p style="color:var(--muted);font-size:.85rem;margin:0 0 12px">' + esc(srv.description) + '</p>' : '') +
      openDate(srv) +
      '<p style="margin:12px 0 0"><a class="btn btn-outline" href="support.html">Become a supporter</a></p>' +
      '</div>';
  }
  function renderPromises(about) {
    var box = document.getElementById('promises');
    var vals = about && about.values || [];
    if (!vals.length) { box.hidden = true; return; }
    document.getElementById('promise-grid').innerHTML = vals.map(function (v) {
      return '<div class="promise"><h3>' + esc(v.title) + '</h3><p>' + esc(v.text) + '</p></div>';
    }).join('');
    box.hidden = false;
  }

  function loadHealth() {
    Yuni.api('GET', '/api/servers/health').then(function (h) {
      (h.servers || []).forEach(function (s) {
        var el = findBy('data-health', s.name);
        if (!el) return;
        el.innerHTML = '<span class="state-dot state-' + esc(s.state) + '"></span> ' + esc(Yuni.stateText(s.state));
      });
    }, function () { /* the chip simply stays empty */ });
  }

  Yuni.loadSite(function (data) {
    var note = document.getElementById('server-note');
    if (!data) {
      grid.innerHTML = '';
      note.textContent = 'Could not load the server list right now. Please refresh in a moment.';
      return;
    }
    var servers = data.servers || [];
    renderPromises(data.about);
    grid.innerHTML = servers.map(function (srv) {
      if (srv.locked) return lockedCard(srv);
      var addr = srv.port ? srv.ip + ':' + srv.port : srv.ip;
      return '<div class="server-card">' +
        '<div class="server-icon">' + esc(srv.icon) + '</div>' +
        '<h3 class="server-name">' + esc(srv.name) + '</h3>' + badgeFor(srv) +
        '<p class="server-address">' + esc(srv.ip) +
          (srv.port ? '<span class="server-port">:' + esc(srv.port) + '</span>' : '') + '</p>' +
        (srv.description ? '<p style="color:var(--muted);font-size:.85rem;margin:0 0 12px">' + esc(srv.description) + '</p>' : '') +
        '<button class="btn btn-copy" type="button" data-addr="' + esc(addr) + '">Copy IP</button>' +
        '<div class="server-health" data-health="' + esc(srv.name) + '"></div>' +
        '<button class="link-report" type="button" data-report-toggle="' + esc(srv.name) + '">Report a problem</button>' +
        '<div class="report-menu" data-report-menu="' + esc(srv.name) + '" hidden>' +
          '<button type="button" class="btn btn-outline" data-report="down" data-server="' + esc(srv.name) + '">Can\u2019t connect</button>' +
          '<button type="button" class="btn btn-outline" data-report="laggy" data-server="' + esc(srv.name) + '">Laggy</button>' +
        '</div>' +
        '</div>';
    }).join('');

    var ips = servers.filter(function (s) { return !s.locked; }).map(function (s) { return s.ip; }).filter(function (ip, i, a) { return ip && a.indexOf(ip) === i; });
    document.getElementById('server-sub').textContent = ips.length === 1
      ? 'All servers share the IP ' + ips[0] + ' — the port differs per game mode.'
      : 'Pick a game mode and copy its address.';
    note.textContent = servers.length ? '' : 'No servers are listed right now.';
    loadHealth();
    renderBanner(data.announcement);
  });
}());
