(function () {
  'use strict';
  var esc = Yuni.esc;
  var list = document.getElementById('list');

  function card(s) {
    var max = Math.max.apply(null, s.hours.concat([1]));
    var bars = s.hours.map(function (n, i) {
      var ago = 23 - i;
      var tip = n + (n === 1 ? ' report' : ' reports') + (ago === 0 ? ' this hour' : ' ' + ago + 'h ago');
      return '<span class="bar' + (n ? ' has' : '') + '" style="height:' + (n ? Math.max(12, Math.round(n / max * 100)) : 4) + '%" title="' + esc(tip) + '"></span>';
    }).join('');
    return '<div class="status-card" data-name="' + esc(s.name) + '">' +
      '<div class="status-top"><div><strong>' + esc(s.icon) + ' ' + esc(s.name) + '</strong>' +
      '<div class="small"><span class="state-dot state-' + esc(s.state) + '"></span> ' + esc(Yuni.stateText(s.state)) + '</div></div>' +
      '<div class="report-row"><button type="button" class="btn btn-outline" data-report="down" data-server="' + esc(s.name) + '">Can\u2019t connect</button>' +
      '<button type="button" class="btn btn-outline" data-report="laggy" data-server="' + esc(s.name) + '">Laggy</button></div></div>' +
      '<div class="bars" role="img" aria-label="Problem reports per hour over the last 24 hours">' + bars + '</div>' +
      '<div class="bars-axis small"><span>24 hours ago</span><span>' + s.reports24h + ' report' + (s.reports24h === 1 ? '' : 's') + ' in 24h</span><span>now</span></div></div>';
  }

  function load() {
    Yuni.api('GET', '/api/servers/health').then(function (h) {
      var servers = h.servers || [];
      list.innerHTML = servers.length ? servers.map(card).join('') : '<p class="small">No servers are listed right now.</p>';
      document.getElementById('foot').textContent = 'A server shows as having problems when at least two different players report a problem in the last ' + h.windowMinutes + ' minutes.';
    }, function () { list.innerHTML = '<p class="small">Could not load the status right now. Please refresh in a moment.</p>'; });
  }

  list.addEventListener('click', function (e) {
    var b = e.target.closest('[data-report]');
    if (!b) return;
    var row = b.parentNode;
    Yuni.reportProblem(b.getAttribute('data-server'), b.getAttribute('data-report')).then(function (msg) {
      row.innerHTML = '<span class="small">' + esc(msg) + '</span>';
      setTimeout(load, 600);
    }, function (err) { row.innerHTML = '<span class="small">' + esc(err.message) + '</span>'; });
  });

  load();
}());
