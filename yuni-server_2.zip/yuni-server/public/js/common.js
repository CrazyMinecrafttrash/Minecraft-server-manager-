// Shared helpers for every page. No inline scripts are used anywhere (strict Content-Security-Policy).
(function () {
  'use strict';

  var csrf = null;
  var csrfKnown = false;

  function esc(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Only http(s) links and relative paths are allowed as hrefs (blocks javascript: etc.).
  function safeUrl(url) {
    var u = String(url || '').trim();
    if (!u) return '';
    if (/^[a-z][a-z0-9+.\-]*:/i.test(u) && !/^https?:/i.test(u)) return '#';
    if (u.indexOf('//') === 0) return '#';
    return u;
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }

  function rawRequest(method, url, body) {
    var opts = { method: method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
    if (method !== 'GET') {
      opts.headers['Content-Type'] = 'application/json';
      if (csrf) opts.headers['X-CSRF-Token'] = csrf;
      opts.body = JSON.stringify(body || {});
    }
    return fetch(url, opts).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (json) {
        if (json && json.csrf) { csrf = json.csrf; csrfKnown = true; }
        if (!res.ok) {
          var err = new Error(json.error || 'Request failed (' + res.status + ')');
          err.status = res.status;
          err.details = json.details;
          err.body = json;
          throw err;
        }
        return json;
      });
    });
  }

  // Looks up who is signed in (and learns the CSRF token for later changes).
  function me() {
    return rawRequest('GET', '/api/auth/me').then(function (json) {
      csrfKnown = true;
      csrf = json.csrf || null;
      return json.user || null;
    });
  }

  function api(method, url, body) {
    if (method !== 'GET' && !csrfKnown) {
      return me().then(function () { return rawRequest(method, url, body); });
    }
    return rawRequest(method, url, body);
  }

  var sitePromise = null;
  function loadSite(callback) {
    if (!sitePromise) {
      sitePromise = api('GET', '/api/site').then(function (data) {
        // the "Support us" links stay hidden until the owners switch the programme on
        var on = !!(data && data.support && data.support.enabled);
        document.querySelectorAll('[data-support-link]').forEach(function (el) { el.hidden = !on; });
        return data;
      }, function () { return null; });
    }
    sitePromise.then(callback);
  }

  // "Sign in" / "Profile" button in the site navigation (public pages only).
  function initNav() {
    var links = document.querySelector('nav .nav-links');
    if (!links || /^\/admin\//.test(window.location.pathname)) return;
    me().then(function (user) {
      var a = document.createElement('a');
      a.className = 'nav-account';
      if (!user) {
        a.href = '/admin/login.html';
        a.textContent = 'Sign in';
      } else if (user.mfa) {
        a.href = '/admin/2fa.html';
        a.textContent = 'Finish sign-in';
      } else {
        a.href = '/profile.html';
        var dot = document.createElement('span');
        dot.className = 'nav-avatar';
        dot.textContent = (user.email || '?').charAt(0).toUpperCase();
        a.appendChild(dot);
        a.appendChild(document.createTextNode(' Profile'));
        a.classList.add('signed-in');
      }
      links.insertBefore(a, links.querySelector('.btn-discord'));
    }, function () { /* leave the nav as it is */ });
  }
  function start() { initNav(); if (!/^\/admin\//.test(window.location.pathname)) loadSite(function () {}); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();

  var STATE_TEXT = { ok: 'No problems reported', issues: 'Some players report problems', down: 'Many players report it is down' };
  function stateText(s) { return STATE_TEXT[s] || STATE_TEXT.ok; }
  // Sends a "this server has a problem" report. Resolves with a short message for the person.
  function reportProblem(server, kind) {
    return api('POST', '/api/servers/report', { server: server, kind: kind }).then(function (r) {
      return r.already ? 'You already reported this a moment ago. Thank you!' : 'Thanks! Your report was added.';
    });
  }

  window.Yuni = {  stateText: stateText, reportProblem: reportProblem, esc: esc, safeUrl: safeUrl, clone: clone, api: api, me: me, loadSite: loadSite };
}());
