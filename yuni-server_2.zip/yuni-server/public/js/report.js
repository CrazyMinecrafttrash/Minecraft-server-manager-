(function () {
  'use strict';

  var esc = Yuni.esc;
  var STATUS = { open: 'Received', in_progress: 'Being looked at', resolved: 'Resolved', wont_fix: 'Closed' };
  function $(id) { return document.getElementById(id); }

  function showNotice(msg, good) {
    var n = $('notice');
    n.textContent = msg;
    n.classList.toggle('good', Boolean(good));
    n.classList.add('visible');
  }

  function loadMine() {
    Yuni.api('GET', '/api/bugs/mine').then(function (r) {
      $('mine-box').hidden = r.bugs.length === 0;
      $('mine').innerHTML = r.bugs.map(function (b) {
        return '<li><span>' + esc(b.title) + '</span><small>' + esc(STATUS[b.status] || b.status) + ' \u00B7 ' +
          esc(new Date(b.createdAt).toLocaleDateString()) + '</small></li>';
      }).join('');
    }, function () { /* the list is optional */ });
  }

  Yuni.me().then(function (user) {
    if (!user) { $('need-login').hidden = false; return; }
    $('bug-form').hidden = false;
    loadMine();
    Yuni.loadSite(function (site) {
      if (!site) return;
      $('server').insertAdjacentHTML('beforeend', site.servers.map(function (s) {
        return '<option value="' + esc(s.name) + '">' + esc(s.name) + '</option>';
      }).join(''));
    });
  }, function () { $('need-login').hidden = false; });

  $('category').addEventListener('change', function () {
    $('server-group').hidden = this.value !== 'server' && this.value !== 'modpack';
  });
  $('description').addEventListener('input', function () { $('count').textContent = this.value.length + ' / 4000'; });

  $('bug-form').addEventListener('submit', function (e) {
    e.preventDefault();
    $('notice').classList.remove('visible');
    var title = $('title').value.trim();
    var description = $('description').value.trim();
    if (title.length < 4) { showNotice('Please give your report a short summary (at least 4 characters).'); return; }
    if (description.length < 10) { showNotice('Please describe what happened (at least 10 characters).'); return; }

    var btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    Yuni.api('POST', '/api/bugs', {
      title: title,
      description: description,
      category: $('category').value,
      serverName: $('server-group').hidden ? '' : $('server').value
    }).then(function () {
      showNotice('Thank you! Your report was sent to the admins.', true);
      $('title').value = ''; $('description').value = ''; $('count').textContent = '0 / 4000';
      btn.disabled = false;
      loadMine();
    }, function (err) {
      showNotice(err.message);
      btn.disabled = false;
    });
  });
}());
