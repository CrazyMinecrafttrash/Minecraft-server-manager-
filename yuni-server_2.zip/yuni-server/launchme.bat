@echo off
cd /d "%~dp0"
node launchme.js %*
pause
