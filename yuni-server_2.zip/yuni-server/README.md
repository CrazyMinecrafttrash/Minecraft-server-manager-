# YuniDoc server

The YuniDoc / YuniRave website as a real server: accounts, Google and Discord sign-in, an admin panel that saves straight to the server, and modpack downloads. No npm packages to install, so there is nothing to compile and no supply-chain risk. Requires **Node.js 22.13 or newer**.

## 1. Configure

```
cp .env.example .env      # then edit it
```

Set `APP_URL` to your public https address and `ADMIN_EMAILS` to your own email. Everything else is optional.

### Google sign-in
1. https://console.cloud.google.com/apis/credentials → Create credentials → OAuth client ID → Web application.
2. Authorized redirect URI: `https://YOURDOMAIN/auth/google/callback`
3. Put the ID and secret in `.env` (`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`).

### Discord sign-in
1. https://discord.com/developers/applications → New Application → OAuth2.
2. Redirect: `https://YOURDOMAIN/auth/discord/callback`
3. Put the ID and secret in `.env` (`DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`).

A sign-in button stays disabled until its keys are set. The secrets live only on the server.

### Email (verification and password reset)
Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` and `MAIL_FROM` in `.env` (any SMTP provider; use an address on your own domain and add your provider's SPF/DKIM records so mail is not marked as spam). The startup log says whether email is enabled.

With email on:
- **Sign up** asks only for an email address. A one-time link (valid 1 hour) lets the owner of that address choose a password, so nobody can register someone else's email.
- **Forgot password?** uses the same page and link, and signs the account out of every other device.
- The site gives the same answer whether or not an account exists, and sends at most one link per address per minute.
- Password accounts that were created before email was switched on must confirm through that link before they can sign in.

Without email, password sign-ups work as before but are **not** verified (and are never admins).

## 2. Run it (pick one)

**Docker + automatic HTTPS (recommended)**
1. Put your domain in `Caddyfile`, and point the domain's DNS at the server.
2. `docker compose up -d --build`

Caddy fetches and renews the certificate. Only ports 80/443 are exposed; the app itself is not reachable directly.

**Without Docker**: copy the folder to `/opt/yuni-server`, create a `yuni` user, install `deploy/yuni.service`, and put any HTTPS reverse proxy (Caddy, nginx) in front of port 3000. Keep `TRUST_PROXY=1`.

Quick local try-out: `NODE_ENV=development APP_URL=http://localhost:3000 npm start`

## Security (read SECURITY.md)
Admins must use **two-factor sign-in** (an authenticator app such as Google Authenticator, Microsoft Authenticator, Authy, 1Password or Bitwarden). The first time an admin signs in they are taken to a page with a QR code to scan; afterwards every admin sign-in asks for the 6-digit code, and risky changes ask again if the last code was more than 15 minutes ago.

Useful commands on the server:
- `npm run security-check`: checks your settings for common mistakes
- `npm run reset-2fa -- someone@example.com`: for an admin who lost their phone and recovery codes
- `npm run revoke-sessions`: emergency, signs everyone out

`SECRET_KEY` must be set in production (see `.env.example`). See **SECURITY.md** for the server hardening checklist and what to do after a break-in.

## 3. First admin

Either set `ADMIN_EMAILS` and sign in with Google/Discord using that email, or create a password admin on the server (either way you will set up 2FA on first sign-in):

```
npm run create-admin            # Docker: docker compose exec app node scripts/create-admin.js
```

More admins are added in the panel (Accounts tab). They become admins when they sign in with a **verified** email via Google or Discord.

## Bug reports and admin notes
- **Report a bug** (`/report.html`, linked from the site footer and the member page): signed-in visitors choose a category and server, write a summary and details, and see the status of their own reports. Limits: 5 reports per person per hour, 4,000 characters.
- **Admin panel → Bug reports**: filter by status, search, set status (open, in progress, resolved, won't fix) and priority, and leave an internal note. These save immediately and the reporter only ever sees the status, never your notes. The Overview shows open bugs and what needs attention.
- **Admin panel → Admin notes**: a shared notepad for admins (pin, edit, delete). Visitors cannot see it.
- Deleting an account keeps its reports but removes the person's email from them. Both features are included in `npm run backup`.

## Supporters, cosmetics and early access

The site can tell your story and run a not-for-profit supporter programme. Perks are limited to **cosmetics** and **early access to new servers**. Nothing that changes gameplay.

1. **Admin > About page**: write your story, promises and team. It appears on `/about.html` and as promise cards on the home page.
2. **Admin > Support page**: set tiers (name, price label, perks, an https payment link), the monthly cost and amount raised, a cost breakdown, cosmetics and your pledge. Tick *Show the Support page* when you are ready. Until then the page and all "Support us" links stay hidden.
3. **Payments happen on a provider you choose** (Ko-fi, Patreon, Stripe payment links...). This server never sees card details.
4. **Admin > Supporters**: after someone pays, add the email they used and pick a tier (optionally an end date). Activation is manual. Perks switch on when that person signs in with the same *verified* email (Google, Discord, or a password account with email verification on).
5. **Early-access servers**: in *Servers*, set "Who can see the address" to supporters. Their IP, port and modpacks are never sent to anyone else. Set an optional "opens to everyone on" date and the server opens automatically.
6. Supporters add their Minecraft username and choose whether to appear on the supporter wall on the Support page.
7. **In-game cosmetics are optional and manual.** The site does not talk to Minecraft. The default perks are website and Discord based (supporter wall, Discord role, early access, community votes). If your modpack has a cosmetic you want to give out, list it in the Support tab and give it by hand; *Supporters > Download CSV* lists each supporter's Minecraft name and tier to work from.

Notes: "non-profit" here means you run it not-for-profit. It is not a legal status, and this is not legal advice. Check Mojang's current commercial usage guidelines (cosmetic-only perks are the safe pattern). Supporter changes and the CSV export need a fresh 2FA code and are written to the activity log.

## Server status tracker

Every server card has a **Report a problem** link ("Can't connect" or "Laggy"), and `/status.html` shows a 24-hour chart per server. It is a community tracker like Downdetector, not an automatic ping: a server shows as having problems when at least 2 different players report within 30 minutes, and as down at 4 or more "can't connect" reports. One person can report a server once per 15 minutes, only a one-way hash of who reported is kept, and reports are deleted after 8 days. Admins see the last 24 hours in *Overview > Player problem reports*.

## Deploy without Docker (directly on your server)

**Quickest way: `launchme`.** Upload and unzip the folder on the server, then run one command:

```
node launchme.js        (Linux shortcut: sh launchme.sh    Windows: double-click launchme.bat)
```

The first time it asks three questions (suggested answers are `104.254.222.120`, `25569` and your email), sets everything up, asks you to choose an admin password, starts the site in the background, and then checks that it really answers. You should see a box saying **SERVER IS UP**. After that: `node launchme.js --status` tells you whether it is up, and `node launchme.js --stop` stops it. The admin Overview tab also shows **Website: Online** with how long it has been up, and `/healthz` is a public address for uptime monitors. The manual steps below do the same thing by hand, and are needed for a service that starts on boot.

This is for running the site straight on a Linux server with Node.js, for example at `https://104.254.222.120:25569`. Nothing else is needed: no Docker, no virtual machine, no packages to install.

1. **Install Node.js 22.13 or newer** on the server (`node --version` to check). Nothing else is needed.
2. **Copy the `yuni-server` folder** to the server, for example to `/opt/yuni-server`.
3. **Run the setup (one command):**
   ```
   cd /opt/yuni-server
   node scripts/setup-server.js 104.254.222.120 25569 you@example.com
   ```
   It writes `.env` with a fresh `SECRET_KEY`, makes a self-signed HTTPS certificate for that IP, sets safe file permissions, and turns on built-in HTTPS. Back up `.env`.
4. **Create your admin account:** `npm run create-admin` (use the email you gave in step 3).
5. **Open the port** in the server firewall and your host's panel: TCP `25569` (for example `sudo ufw allow 25569/tcp`).
6. **Start it:** `npm start` to try it. To keep it running and start on boot, use the included service file:
   ```
   sudo useradd --system --home /opt/yuni-server yuni
   sudo chown -R yuni:yuni /opt/yuni-server && sudo chmod 600 /opt/yuni-server/.env
   sudo cp deploy/yuni.service /etc/systemd/system/ && sudo systemctl daemon-reload
   sudo systemctl enable --now yuni && sudo journalctl -u yuni -f
   ```
   (On Windows, run `npm start` in the same folder and keep it alive with Task Scheduler or NSSM.)
7. Visit `https://104.254.222.120:25569`. Browsers show **"Not secure / certificate warning"** once, because a certificate for a bare IP cannot be signed by a public authority. Compare the fingerprint shown by setup (or `node scripts/make-cert.js`) with the certificate details, then continue. Admin sign-in then asks you to set up two-factor.
8. Run `npm run security-check` and fix anything it flags.

Things to know in this mode:
- **Warning for visitors:** the certificate warning looks alarming to ordinary players. For a public site, get a cheap domain name and a trusted certificate (or put the site behind Cloudflare or Caddy). Then change `APP_URL`, remove the `TLS_*` lines, and keep `TRUST_PROXY=1` if a proxy is in front.
- **Google sign-in does not work on a bare IP address** (Google refuses IP addresses as redirect addresses). Discord and password sign-in work. Email sign-up verification needs `SMTP_*` set.
- **Visitors connect directly**, so `TRUST_PROXY` must stay `0`. Otherwise people could fake their IP address and dodge rate limits and lockouts. The app warns if it is wrong.
- The certificate lasts one year. To renew, run `node scripts/make-cert.js 104.254.222.120` and restart.
- Only if you cannot use HTTPS at all: set `ALLOW_INSECURE_HTTP=1` and `APP_URL=http://...`. Then passwords and login cookies travel unencrypted. Not recommended.

## 4. Modpack files

Put zip files in the downloads folder (`data/downloads`, or in the `yuni-data` volume under `downloads/`), then link them in the panel as `downloads/yourfile.zip`. The Overview tab warns about links to files that are missing.

## 5. Backups

`npm run backup` writes a consistent copy of the database to `data/backups` (keeps 14). Schedule it daily, e.g. `0 4 * * * cd /opt/yuni-server && npm run backup`. Also copy the backups off the server.

## Security summary (details in SECURITY.md)
- Passwords: scrypt with a per-user salt. Account lockout after 5 failures; identical responses for unknown emails.
- Sessions: random tokens in HttpOnly SameSite cookies, only a hash is stored. New session on every login. Admins time out after 30 min idle / 12 h.
- Admin rights are re-checked on every request; password sign-ups are never admins.
- CSRF: same-site Origin check, JSON-only bodies, and a per-session token.
- OAuth: server-side code flow, single-use state, PKCE for Google, verified email required.
- Strict Content-Security-Policy (no inline scripts), HSTS, no framing, rate limits, parameterised SQL, validated settings, path-traversal-safe file serving.

## Limits to know
- Email sending uses a built-in SMTP client (TLS required). It was tested against a fake SMTP server; send a real test through your provider after deploying.
- Rate limiting is in memory, which suits a single process (as shipped).
- `node:sqlite` is marked experimental in Node 22; it has been stable in use, and the file is a normal SQLite database.
- Tests: `npm test` (66 tests, including a fake Google/Discord server and a fake SMTP server). The real providers and the Docker/Caddy files could not be exercised from the build environment, so do a test sign-in after deploying.
