'use strict';
// Rejects passwords that appear in known data breaches, using the Have I Been Pwned range API
// (k-anonymity: only the first 5 characters of the password's SHA-1 hash ever leave the server).
// If the service is unreachable the check is skipped rather than blocking sign-ups.

const crypto = require('node:crypto');

async function isBreachedPassword(password, { api, timeoutMs = 3000 } = {}) {
  const hash = crypto.createHash('sha1').update(String(password)).digest('hex').toUpperCase();
  const prefix = hash.slice(0, 5);
  const suffix = hash.slice(5);
  try {
    const res = await fetch(api + prefix, {
      headers: { 'Add-Padding': 'true', 'User-Agent': 'YuniDoc-server' },
      signal: AbortSignal.timeout(timeoutMs),
      redirect: 'error',
    });
    if (!res.ok) return false;
    const text = await res.text();
    return text.split('\n').some((line) => {
      const [suf, count] = line.trim().split(':');
      return suf === suffix && Number(count) > 0;
    });
  } catch {
    return false;
  }
}

module.exports = { isBreachedPassword };
