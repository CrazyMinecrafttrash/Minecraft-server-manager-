'use strict';
// Strict server-side validation of the site settings document.
// Never trust the browser: everything an admin saves passes through here.

const DEFAULT_SITE = {
  servers: [
    { icon: '⚔️', name: 'Survival', ip: '104.254.222.120', port: '25565', description: '', hidden: false },
    { icon: '🏗️', name: 'Creative', ip: '104.254.222.120', port: '25566', description: '', hidden: false },
    { icon: '🌤️', name: 'SkyBlock', ip: '104.254.222.120', port: '25567', description: '', hidden: false },
    { icon: '🎮', name: 'Mini-Games', ip: '104.254.222.120', port: '25568', description: '', hidden: false },
  ],
  modpacks: [
    { serverName: 'Survival', name: 'Survival Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
    { serverName: 'Creative', name: 'Creative Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
    { serverName: 'SkyBlock', name: 'SkyBlock Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
    { serverName: 'Mini-Games', name: 'Mini-Games Main Pack', version: '', type: 'zip', url: 'downloads/modpack.zip' },
  ],
  fallback: { name: 'YuniDoc Modpack', url: 'downloads/modpack.zip', download: true },
  announcement: { enabled: false, text: '', level: 'info' },
  about: {
    headline: 'A community server, run by players for players',
    story: 'YuniDoc is a community-run modded Minecraft project. Keeping the servers online costs real money every month, so we run it as a not-for-profit: what comes in goes to hosting and keeping the servers healthy, and nothing else.\n\nWe will never sell anything that changes how the game plays. Edit this story in the admin panel to tell people who you are and why you started.',
    values: [
      { title: 'Not pay-to-win', text: 'Nothing that affects gameplay is ever for sale. Everyone plays with the same rules, items and progression.' },
      { title: 'Not for profit', text: 'Support goes to server costs. We publish what the servers cost so you can see where it goes.' },
      { title: 'Community first', text: 'Players help decide what comes next. Supporters get cosmetics and early looks, never an advantage.' },
    ],
    team: [],
  },
  support: {
    enabled: true,
    headline: 'Become a Patron',
    intro: 'YuniDoc is run not-for-profit. Hosting the modded servers costs real money every month, and patrons are what keep them online. Joining is optional, and nothing you get ever changes how the game plays.',
    pledge: [
      'Supporter perks are cosmetic only: no items, no power, no faster progress.',
      'Everything that affects gameplay stays free for everyone.',
      'Money goes to server costs, and we show you the numbers.',
    ],
    goal: { currency: '$', monthlyCost: 0, raised: 0, note: '' },
    costs: [],
    tiers: [
      { id: 'supporter', name: 'Supporter', price: '$3 / month', description: 'Helps cover the basics and gets you in early.', perks: ['Early access to every new server', 'Supporter role in our Discord', 'Your name on the supporter wall (optional)'], earlyAccess: true, url: '' },
      { id: 'patron', name: 'Patron', price: '$6 / month', description: 'Keeps the lights on.', perks: ['Everything in Supporter', 'Patron role in our Discord', 'Vote on the theme of community events', 'Help test new servers before anyone else'], earlyAccess: true, url: '' },
    ],
    cosmetics: [],
    showWall: true,
  },
};

const MAX_SERVERS = 50;
const MAX_MODPACKS = 200;
const MAX_TIERS = 6;
const MAX_COSMETICS = 40;
const MAX_TEAM = 12;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f]/;
const HOST_RE = /^(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$|^\[[0-9A-Fa-f:]+\]$/;

// Like text(), but keeps line breaks (for stories and descriptions).
function longText(value, max, label, errors) {
  let s = value === undefined || value === null ? '' : String(value).replace(/\r\n?/g, '\n').trim();
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u0009\u000b-\u001f\u007f]/.test(s)) { errors.push(`${label} contains invalid characters.`); return ''; }
  if (s.length > max) { errors.push(`${label} must be ${max} characters or fewer.`); s = s.slice(0, max); }
  return s;
}

function money(value, label, errors) {
  const n = value === undefined || value === null || value === '' ? 0 : Number(value);
  if (!Number.isFinite(n) || n < 0 || n > 1000000) { errors.push(`${label} must be a number from 0 to 1,000,000.`); return 0; }
  return Math.round(n * 100) / 100;
}

function stringList(value, maxItems, maxLen, label, errors) {
  const list = Array.isArray(value) ? value : [];
  if (list.length > maxItems) errors.push(`${label}: at most ${maxItems} items.`);
  return list.slice(0, maxItems).map((v) => text(v, maxLen, label, errors)).filter(Boolean);
}

const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);

function text(value, max, label, errors, { required = false } = {}) {
  const s = value === undefined || value === null ? '' : String(value).trim();
  if (CONTROL.test(s)) { errors.push(`${label} contains invalid characters.`); return ''; }
  if (s.length > max) { errors.push(`${label} must be ${max} characters or fewer.`); return s.slice(0, max); }
  if (required && !s) errors.push(`${label} is required.`);
  return s;
}

// Accepts http(s) links and relative paths. Rejects javascript:, data:, //host, "..", backslashes.
function cleanUrl(value, label, errors, { required = false } = {}) {
  const s = text(value, 500, label, errors);
  if (!s) { if (required) errors.push(`${label} is required.`); return ''; }
  if (/^https?:\/\//i.test(s)) {
    try {
      const u = new URL(s);
      if (!u.hostname) throw new Error('no host');
      return s;
    } catch {
      errors.push(`${label} is not a valid web address.`);
      return '';
    }
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(s)) { errors.push(`${label} must start with http:// or https://, or be a path like downloads/pack.zip.`); return ''; }
  if (s.startsWith('//') || s.includes('\\') || s.split('/').includes('..') || /\s/.test(s)) {
    errors.push(`${label} is not a valid path.`);
    return '';
  }
  return s;
}

function cleanDate(value, label, errors) {
  const s = value === undefined || value === null ? '' : String(value).trim();
  if (!s) return '';
  const d = new Date(`${s}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s) {
    errors.push(`${label} must be a date like 2026-12-31.`);
    return '';
  }
  return s;
}

function normalizeSite(input) {
  const errors = [];
  const src = input && typeof input === 'object' ? input : {};

  // ── servers ──
  const rawServers = Array.isArray(src.servers) ? src.servers : [];
  if (rawServers.length > MAX_SERVERS) errors.push(`You can have at most ${MAX_SERVERS} servers.`);
  const seen = new Set();
  const servers = rawServers.slice(0, MAX_SERVERS).map((s, i) => {
    const row = s && typeof s === 'object' ? s : {};
    const name = text(row.name, 40, `Server ${i + 1} name`, errors, { required: true });
    const key = name.toLowerCase();
    if (name && seen.has(key)) errors.push(`Duplicate server name "${name}".`);
    seen.add(key);

    const ip = text(row.ip, 253, `"${name || i + 1}" IP`, errors, { required: true });
    if (ip && !HOST_RE.test(ip)) errors.push(`"${name || i + 1}": IP / hostname is not valid.`);

    const port = text(row.port, 5, `"${name || i + 1}" port`, errors);
    if (port && (!/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535)) {
      errors.push(`"${name || i + 1}": port must be 1–65535.`);
    }
    return {
      icon: text(row.icon, 8, `"${name || i + 1}" icon`, errors) || '🎮',
      name,
      ip,
      port,
      description: text(row.description, 160, `"${name || i + 1}" description`, errors),
      hidden: row.hidden === true,
      // 'patrons' = only supporters (and admins) see the address until publicOn (YYYY-MM-DD) arrives
      access: row.access === 'patrons' ? 'patrons' : 'public',
      publicOn: cleanDate(row.publicOn, `"${name || i + 1}" opening date`, errors),
    };
  });
  if (!servers.length) errors.push('Add at least one server.');

  // ── modpacks ──
  const rawPacks = Array.isArray(src.modpacks) ? src.modpacks : [];
  if (rawPacks.length > MAX_MODPACKS) errors.push(`You can have at most ${MAX_MODPACKS} modpacks.`);
  const modpacks = rawPacks.slice(0, MAX_MODPACKS).map((p, i) => {
    const row = p && typeof p === 'object' ? p : {};
    const name = text(row.name, 80, `Modpack ${i + 1} name`, errors, { required: true });
    return {
      serverName: text(row.serverName, 40, `"${name || i + 1}" server`, errors),
      name,
      version: text(row.version, 30, `"${name || i + 1}" version`, errors),
      type: row.type === 'link' ? 'link' : 'zip',
      url: cleanUrl(row.url, `"${name || i + 1}" download URL`, errors, { required: true }),
    };
  });

  // ── fallback ──
  const fb = src.fallback && typeof src.fallback === 'object' ? src.fallback : {};
  const fallback = {
    name: text(fb.name, 80, 'Fallback pack name', errors) || DEFAULT_SITE.fallback.name,
    url: cleanUrl(fb.url, 'Fallback download URL', errors) || DEFAULT_SITE.fallback.url,
    download: fb.download !== false,
  };

  // ── announcement ──
  const an = src.announcement && typeof src.announcement === 'object' ? src.announcement : {};
  const announcement = {
    enabled: an.enabled === true,
    text: text(an.text, 200, 'Banner message', errors),
    level: ['info', 'warn', 'success'].includes(an.level) ? an.level : 'info',
  };

  // ── about page ──
  const ab = src.about && typeof src.about === 'object' ? src.about : {};
  const rawValues = Array.isArray(ab.values) ? ab.values : [];
  const rawTeam = Array.isArray(ab.team) ? ab.team : [];
  if (rawValues.length > 6) errors.push('About: at most 6 promises.');
  if (rawTeam.length > MAX_TEAM) errors.push(`About: at most ${MAX_TEAM} team members.`);
  const about = {
    headline: text(ab.headline, 100, 'About headline', errors),
    story: longText(ab.story, 3000, 'About story', errors),
    values: rawValues.slice(0, 6).map((v, i) => {
      const r = v && typeof v === 'object' ? v : {};
      return { title: text(r.title, 50, `Promise ${i + 1} title`, errors), text: text(r.text, 240, `Promise ${i + 1} text`, errors) };
    }).filter((v) => v.title || v.text),
    team: rawTeam.slice(0, MAX_TEAM).map((m, i) => {
      const r = m && typeof m === 'object' ? m : {};
      return {
        name: text(r.name, 40, `Team member ${i + 1} name`, errors, { required: true }),
        role: text(r.role, 60, `Team member ${i + 1} role`, errors),
        bio: longText(r.bio, 300, `Team member ${i + 1} bio`, errors),
      };
    }),
  };

  // ── support / patrons page ──
  const su = src.support && typeof src.support === 'object' ? src.support : {};
  const rawTiers = Array.isArray(su.tiers) ? su.tiers : [];
  if (rawTiers.length > MAX_TIERS) errors.push(`Support: at most ${MAX_TIERS} tiers.`);
  const tierIds = new Set();
  const tiers = rawTiers.slice(0, MAX_TIERS).map((t, i) => {
    const r = t && typeof t === 'object' ? t : {};
    const name = text(r.name, 40, `Tier ${i + 1} name`, errors, { required: true });
    let id = slug(r.id) || slug(name) || `tier-${i + 1}`;
    for (let n = 2; tierIds.has(id); n++) id = `${slug(r.id) || slug(name) || 'tier'}-${n}`.slice(0, 34);
    tierIds.add(id);
    let url = text(r.url, 500, `"${name || i + 1}" payment link`, errors);
    if (url) {
      try {
        const u = new URL(url);
        if (u.protocol !== 'https:' || !u.hostname || u.username || u.password) throw new Error('bad');
      } catch { errors.push(`"${name || i + 1}" payment link must be a full https:// address.`); url = ''; }
    }
    return {
      id, name,
      price: text(r.price, 40, `"${name || i + 1}" price`, errors),
      description: text(r.description, 200, `"${name || i + 1}" description`, errors),
      perks: stringList(r.perks, 10, 120, `"${name || i + 1}" perks`, errors),
      earlyAccess: r.earlyAccess !== false,
      url,
    };
  });
  const rawCosmetics = Array.isArray(su.cosmetics) ? su.cosmetics : [];
  if (rawCosmetics.length > MAX_COSMETICS) errors.push(`Support: at most ${MAX_COSMETICS} cosmetics.`);
  const cosmetics = rawCosmetics.slice(0, MAX_COSMETICS).map((c, i) => {
    const r = c && typeof c === 'object' ? c : {};
    const tier = text(r.tier, 40, `Cosmetic ${i + 1} tier`, errors);
    if (tier && !tierIds.has(tier)) errors.push(`Cosmetic ${i + 1} refers to a tier that does not exist.`);
    return {
      name: text(r.name, 60, `Cosmetic ${i + 1} name`, errors, { required: true }),
      description: text(r.description, 160, `Cosmetic ${i + 1} description`, errors),
      tier: tierIds.has(tier) ? tier : '',
    };
  });
  const rawCosts = Array.isArray(su.costs) ? su.costs : [];
  if (rawCosts.length > 10) errors.push('Support: at most 10 cost lines.');
  const g = su.goal && typeof su.goal === 'object' ? su.goal : {};
  const support = {
    enabled: su.enabled === true,
    headline: text(su.headline, 100, 'Support headline', errors),
    intro: longText(su.intro, 1000, 'Support introduction', errors),
    pledge: stringList(su.pledge, 8, 200, 'Pledge', errors),
    goal: {
      currency: text(g.currency, 4, 'Currency symbol', errors) || '$',
      monthlyCost: money(g.monthlyCost, 'Monthly cost', errors),
      raised: money(g.raised, 'Raised this month', errors),
      note: text(g.note, 200, 'Goal note', errors),
    },
    costs: rawCosts.slice(0, 10).map((c, i) => {
      const r = c && typeof c === 'object' ? c : {};
      return { label: text(r.label, 50, `Cost ${i + 1} label`, errors, { required: true }), amount: money(r.amount, `Cost ${i + 1} amount`, errors) };
    }),
    tiers,
    cosmetics,
    showWall: su.showWall !== false,
  };

  return { value: { servers, modpacks, fallback, announcement, about, support }, errors };
}

module.exports = { DEFAULT_SITE, normalizeSite };
