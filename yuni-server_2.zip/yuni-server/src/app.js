'use strict';
// Builds the request handler: security headers → rate limits → routing → guards → static files.

const { parseCookies, RateLimiter } = require('./security');
const {
  HttpError, setSecurityHeaders, clientIp, decorate, readJson, createRouter, resolveInside, sendFile,
} = require('./http');
const { createStore } = require('./db');
const { createMailer } = require('./mail');
const { createAuth } = require('./auth');
const { createOAuth } = require('./oauth');
const { registerRoutes } = require('./routes');

const ADMIN_ONLY_FILES = new Set(['/admin/dashboard.html', '/admin/dashboard.js']);
const MEMBER_ONLY_FILES = new Set(['/admin/member.html', '/admin/member.js', '/admin/2fa.html', '/admin/2fa.js']);

function createApp({ config, db, log = true, mailer: mailerOverride }) {
  const store = createStore(db);
  const limiter = new RateLimiter();
  const auth = createAuth({ config, store });
  const oauth = createOAuth({ config, store, auth });
  const router = createRouter();
  const mailer = mailerOverride || createMailer(config);

  store.getSite(); // seed defaults on first run
  store.syncOwners(config.ownerEmails);
  registerRoutes({ router, config, store, auth, oauth, mailer });

  const maintenance = setInterval(() => {
    try { store.purgeExpired(); store.pruneAudit(); } catch (err) { console.error('maintenance failed:', err.message); }
  }, 10 * 60 * 1000);
  maintenance.unref();

  function rateLimit(req, bucket) {
    const rule = config.rate[bucket];
    const result = limiter.hit(`${bucket}:${req.ip}`, rule.max, rule.windowMs);
    if (!result.allowed) {
      const err = new HttpError(429, 'Too many requests. Please slow down and try again shortly.');
      err.retryAfter = result.retryAfterSec;
      throw err;
    }
  }

  async function runRoute(req, res, { route, params }) {
    const opt = route.options;
    req.params = params;
    res.setHeader('Cache-Control', 'no-store');
    if (opt.limit) rateLimit(req, opt.limit);

    auth.loadSession(req, res);
    const unsafe = req.method !== 'GET' && req.method !== 'HEAD';
    if (unsafe) auth.checkOrigin(req);

    if (opt.access === 'user' || opt.access === 'admin') {
      if (!req.user) throw new HttpError(401, 'Please sign in.');
      if (opt.access === 'admin' && !req.user.isAdmin) throw new HttpError(403, 'Admin access required.');
    }
    if (unsafe && req.session) auth.checkCsrf(req);
    if (unsafe) req.body = await readJson(req, config.limits.jsonBytes);

    await route.handler(req, res);
  }

  function notFound(res) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end('Not found');
  }

  async function serveStatic(req, res) {
    const p = req.path;
    if (p === '/admin' || p === '/admin/') return res.redirect('/admin/login.html');

    if (ADMIN_ONLY_FILES.has(p) || MEMBER_ONLY_FILES.has(p)) {
      auth.loadSession(req, res);
      const allowed = ADMIN_ONLY_FILES.has(p) ? req.user && req.user.isAdmin : req.user;
      if (!allowed) return p.endsWith('.js') ? notFound(res) : res.redirect('/admin/login.html');
    }

    if (p.startsWith('/downloads/')) {
      const found = await resolveInside(config.downloadsDir, p.slice('/downloads/'.length));
      if (!found) return notFound(res);
      return sendFile(req, res, found, { attachment: true, cache: 'public, max-age=300' });
    }

    const found = await resolveInside(config.publicDir, p);
    if (!found) return notFound(res);
    return sendFile(req, res, found);
  }

  async function dispatch(req, res) {
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { throw new HttpError(400, 'Bad request.'); }
    if (req.url.length > 4000) throw new HttpError(414, 'Address too long.');
    req.path = url.pathname;
    req.query = Object.fromEntries(url.searchParams);
    req.ip = clientIp(req, config.trustProxy);
    req.cookies = parseCookies(req.headers.cookie);

    rateLimit(req, 'global');

    const match = router.match(req.method, req.path);
    if (match.badRequest) throw new HttpError(400, 'Bad request.');
    if (match.route) return runRoute(req, res, match);

    if (req.method === 'GET' || req.method === 'HEAD') {
      if (match.pathMatched) throw new HttpError(405, 'Method not allowed.');
      return serveStatic(req, res);
    }
    if (match.pathMatched) throw new HttpError(405, 'Method not allowed.');
    throw new HttpError(404, 'Not found.');
  }

  function handleError(req, res, err) {
    if (res.headersSent) { res.destroy(); return; }
    if (err instanceof HttpError) {
      if (err.retryAfter) res.setHeader('Retry-After', String(err.retryAfter));
      if (err.status === 413) res.setHeader('Connection', 'close');
      const body = { error: err.message };
      if (err.details) body.details = err.details;
      if (err.code && typeof err.code === 'string' && !err.code.startsWith('ERR_')) body.code = err.code;
      return res.json(err.status, body);
    }
    console.error(JSON.stringify({ level: 'error', msg: 'unhandled error', path: req.path, error: err && err.stack }));
    return res.json(500, { error: 'Something went wrong on the server.' });
  }

  async function handler(req, res) {
    const started = Date.now();
    decorate(res);
    setSecurityHeaders(res, { secure: config.secureCookies });
    if (log) {
      res.on('finish', () => {
        // The query string is deliberately not logged (it can contain OAuth codes).
        console.log(JSON.stringify({ t: new Date().toISOString(), m: req.method, p: req.path, s: res.statusCode, ms: Date.now() - started, ip: req.ip }));
      });
    }
    try {
      await dispatch(req, res);
    } catch (err) {
      handleError(req, res, err);
    }
  }

  function close() {
    clearInterval(maintenance);
    limiter.close();
  }

  return { handler, store, close };
}

module.exports = { createApp };
