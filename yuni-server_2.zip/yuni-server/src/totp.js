'use strict';
// Two-factor authentication helpers (RFC 6238 TOTP, the codes authenticator apps show),
// recovery codes, and AES-256-GCM encryption for secrets stored in the database.

const crypto = require('node:crypto');

const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buf) {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = ((value << 8) | byte) & 0xffff;
    bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

function base32Decode(str) {
  const s = String(str).toUpperCase().replace(/[\s=]/g, '');
  let bits = 0, value = 0;
  const out = [];
  for (const c of s) {
    const i = B32.indexOf(c);
    if (i === -1) throw new Error('invalid base32');
    value = ((value << 5) | i) & 0xffff;
    bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}

const STEP_MS = 30 * 1000;

function hotp(key, counter) {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const mac = crypto.createHmac('sha1', key).update(msg).digest();
  const off = mac[mac.length - 1] & 15;
  const bin = ((mac[off] & 0x7f) << 24) | (mac[off + 1] << 16) | (mac[off + 2] << 8) | mac[off + 3];
  return String(bin % 1000000).padStart(6, '0');
}

const generateSecret = () => base32Encode(crypto.randomBytes(20));
const currentStep = (now = Date.now()) => Math.floor(now / STEP_MS);
const totpAt = (secret, step) => hotp(base32Decode(secret), step);

// Returns the matched time step, or null. Accepts one step of clock drift either way, and never a
// step at or before lastStep (so a code cannot be used twice, even by someone watching the screen).
function verifyTotp(secret, code, lastStep = 0, now = Date.now()) {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const key = base32Decode(secret);
  const step = currentStep(now);
  let matched = null;
  for (const s of [step - 1, step, step + 1]) {
    const ok = crypto.timingSafeEqual(Buffer.from(hotp(key, s)), Buffer.from(code));
    if (ok && s > lastStep && matched === null) matched = s;
  }
  return matched;
}

function otpauthUri({ issuer, account, secret }) {
  const label = encodeURIComponent(`${issuer}:${account}`);
  return `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

// ── recovery codes: 10 single-use codes, ~50 bits each, stored only as hashes ──
function generateRecoveryCodes(n = 10) {
  return Array.from({ length: n }, () => {
    const s = base32Encode(crypto.randomBytes(7)).slice(0, 10).toLowerCase();
    return `${s.slice(0, 5)}-${s.slice(5)}`;
  });
}
const normalizeRecoveryCode = (code) => String(code || '').toLowerCase().replace(/[^a-z2-7]/g, '');
const hashRecoveryCode = (code) => crypto.createHash('sha256').update('yuni-recovery:' + normalizeRecoveryCode(code)).digest('hex');

// ── encryption at rest (key comes from SECRET_KEY, never stored in the database) ──
function encrypt(key, plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  return ['v1', iv.toString('base64url'), cipher.getAuthTag().toString('base64url'), ct.toString('base64url')].join('.');
}

function decrypt(key, payload) {
  const [v, iv, tag, ct] = String(payload).split('.');
  if (v !== 'v1') throw new Error('unknown secret format');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64url'));
  decipher.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(ct, 'base64url')), decipher.final()]).toString('utf8');
}

module.exports = {
  base32Encode, base32Decode, generateSecret, verifyTotp, totpAt, currentStep, otpauthUri,
  generateRecoveryCodes, normalizeRecoveryCode, hashRecoveryCode, encrypt, decrypt,
};
