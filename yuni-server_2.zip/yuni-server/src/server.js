'use strict';
const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');

// Creates the HTTP server, or an HTTPS one when a TLS certificate is configured (no reverse proxy needed).
function createServer(config, handler) {
  const base = { maxHeaderSize: 16 * 1024 };
  const server = config.tls
    ? https.createServer({ ...base, cert: fs.readFileSync(config.tls.certFile), key: fs.readFileSync(config.tls.keyFile), minVersion: 'TLSv1.2' }, handler)
    : http.createServer(base, handler);
  server.headersTimeout = 15 * 1000;
  server.requestTimeout = 60 * 1000;
  server.keepAliveTimeout = 5 * 1000;
  return server;
}

module.exports = { createServer };
