'use strict';
// SQLite storage (Node's built-in node:sqlite — no native add-ons to install).
// All queries use bound parameters; nothing is ever built by string concatenation.

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { DEFAULT_SITE } = require('./validate');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  email          TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash  TEXT,
  email_verified INTEGER NOT NULL DEFAULT 0,
  created_at     INTEGER NOT NULL,
  last_login_at  INTEGER,
  failed_logins  INTEGER NOT NULL DEFAULT 0,
  locked_until   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS identities (
  provider         TEXT NOT NULL,
  provider_user_id TEXT NOT NULL,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (provider, provider_user_id)
);
CREATE INDEX IF NOT EXISTS identities_user ON identities(user_id);
CREATE TABLE IF NOT EXISTS sessions (
  id_hash    TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf       TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  last_seen  INTEGER NOT NULL,
  idle_ms    INTEGER NOT NULL,
  abs_ms     INTEGER NOT NULL,
  ip         TEXT,
  ua         TEXT
);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS oauth_states (
  state_hash   TEXT PRIMARY KEY,
  provider     TEXT NOT NULL,
  verifier     TEXT,
  binding_hash TEXT NOT NULL,
  expires_at   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS email_tokens (
  token_hash TEXT PRIMARY KEY,
  email      TEXT NOT NULL COLLATE NOCASE,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS email_tokens_email ON email_tokens(email);
CREATE TABLE IF NOT EXISTS admins (
  email      TEXT PRIMARY KEY COLLATE NOCASE,
  is_owner   INTEGER NOT NULL DEFAULT 0,
  added_by   TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS recovery_codes (
  user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  used_at   INTEGER,
  PRIMARY KEY (user_id, code_hash)
);
CREATE TABLE IF NOT EXISTS patrons (
  email      TEXT PRIMARY KEY COLLATE NOCASE,
  tier       TEXT NOT NULL,
  since      INTEGER NOT NULL,
  until      INTEGER,
  note       TEXT NOT NULL DEFAULT '',
  hide_wall  INTEGER NOT NULL DEFAULT 0,
  granted_by TEXT
);
CREATE TABLE IF NOT EXISTS notes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  body       TEXT NOT NULL,
  pinned     INTEGER NOT NULL DEFAULT 0,
  author     TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  updated_by TEXT
);
CREATE TABLE IF NOT EXISTS bug_reports (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reporter    TEXT,
  title       TEXT NOT NULL,
  description TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'other',
  server_name TEXT NOT NULL DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'open',
  priority    TEXT NOT NULL DEFAULT 'normal',
  admin_note  TEXT NOT NULL DEFAULT '',
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  updated_by  TEXT
);
CREATE INDEX IF NOT EXISTS bug_reports_user ON bug_reports(user_id, created_at);
CREATE TABLE IF NOT EXISTS outage_reports (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  server_name   TEXT NOT NULL COLLATE NOCASE,
  kind          TEXT NOT NULL,
  reporter_hash TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS outage_reports_server ON outage_reports(server_name, created_at);
CREATE INDEX IF NOT EXISTS outage_reports_time ON outage_reports(created_at);
CREATE TABLE IF NOT EXISTS site (
  id         INTEGER PRIMARY KEY CHECK (id = 1),
  data       TEXT NOT NULL,
  version    INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  updated_by TEXT
);
CREATE TABLE IF NOT EXISTS audit (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  ts     INTEGER NOT NULL,
  actor  TEXT,
  action TEXT NOT NULL,
  detail TEXT,
  ip     TEXT
);
`;

// Adds columns introduced after the first release, so existing databases upgrade in place.
function migrate(db) {
  const has = (table, col) => db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col);
  const add = (table, def) => { if (!has(table, def.split(' ')[0])) db.exec(`ALTER TABLE ${table} ADD COLUMN ${def}`); };
  add('users', 'totp_secret TEXT');
  add('users', 'totp_enabled INTEGER NOT NULL DEFAULT 0');
  add('users', 'totp_last_step INTEGER NOT NULL DEFAULT 0');
  add('users', 'totp_failures INTEGER NOT NULL DEFAULT 0');
  add('users', 'totp_locked_until INTEGER NOT NULL DEFAULT 0');
  add('users', 'mfa_email_code TEXT');
  add('users', 'mfa_email_exp INTEGER NOT NULL DEFAULT 0');
  add('sessions', 'mfa_at INTEGER');
  add('users', 'mc_username TEXT');
  add('users', 'display_name TEXT');
  add('users', 'wall_opt_in INTEGER NOT NULL DEFAULT 0');
}

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  db.exec(SCHEMA);
  migrate(db);
  if (file !== ':memory:') { try { fs.chmodSync(file, 0o600); } catch { /* best effort */ } }
  return db;
}

function createStore(db) {
  const q = {};
  const prep = (key, sql) => (q[key] || (q[key] = db.prepare(sql)));

  function tx(fn) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn();
      db.exec('COMMIT');
      return result;
    } catch (err) {
      try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
      throw err;
    }
  }

  const toUser = (row) => row && ({
    id: Number(row.id),
    email: row.email,
    passwordHash: row.password_hash,
    emailVerified: row.email_verified === 1,
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at,
    failedLogins: row.failed_logins,
    lockedUntil: row.locked_until,
    totpSecret: row.totp_secret,
    totpEnabled: row.totp_enabled === 1,
    totpLastStep: row.totp_last_step,
    totpFailures: row.totp_failures,
    totpLockedUntil: row.totp_locked_until,
    mfaEmailCode: row.mfa_email_code,
    mfaEmailExp: row.mfa_email_exp,
    mcUsername: row.mc_username,
    displayName: row.display_name,
    wallOptIn: row.wall_opt_in === 1,
  });

  const toPatron = (r) => r && ({
    email: r.email, tier: r.tier, since: r.since, until: r.until, note: r.note, hideWall: r.hide_wall === 1,
    grantedBy: r.granted_by, active: r.until === null || r.until > Date.now(),
    mcUsername: r.mc_username || null, displayName: r.display_name || null, wallOptIn: r.wall_opt_in === 1,
    signedUp: r.uid !== null && r.uid !== undefined, emailVerified: r.email_verified === 1,
  });
  const PATRON_SELECT = `SELECT p.*, u.id AS uid, u.mc_username, u.display_name, u.wall_opt_in, u.email_verified
                         FROM patrons p LEFT JOIN users u ON u.email = p.email`;

  const toNote = (r) => r && ({
    id: r.id, body: r.body, pinned: r.pinned === 1, author: r.author,
    createdAt: r.created_at, updatedAt: r.updated_at, updatedBy: r.updated_by,
  });
  const toBug = (r) => r && ({
    id: r.id, userId: r.user_id, reporter: r.reporter, title: r.title, description: r.description,
    category: r.category, serverName: r.server_name, status: r.status, priority: r.priority,
    adminNote: r.admin_note, createdAt: r.created_at, updatedAt: r.updated_at, updatedBy: r.updated_by,
  });

  const store = {
    tx,

    // ── users ──
    getUserById: (id) => toUser(prep('uById', 'SELECT * FROM users WHERE id = ?').get(id)),
    getUserByEmail: (email) => toUser(prep('uByEmail', 'SELECT * FROM users WHERE email = ?').get(email)),
    createUser({ email, passwordHash = null, verified = false }) {
      const r = prep('uIns', 'INSERT INTO users (email, password_hash, email_verified, created_at) VALUES (?, ?, ?, ?)')
        .run(email, passwordHash, verified ? 1 : 0, Date.now());
      return store.getUserById(Number(r.lastInsertRowid));
    },
    setPassword: (id, hash) => prep('uPw', 'UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = 0 WHERE id = ?').run(hash, id),
    recordFailure(id, maxFailures, lockMs) {
      const u = store.getUserById(id);
      if (!u) return { locked: false };
      const failures = u.failedLogins + 1;
      if (failures >= maxFailures) {
        prep('uLock', 'UPDATE users SET failed_logins = 0, locked_until = ? WHERE id = ?').run(Date.now() + lockMs, id);
        return { locked: true };
      }
      prep('uFail', 'UPDATE users SET failed_logins = ? WHERE id = ?').run(failures, id);
      return { locked: false };
    },
    recordLogin: (id) => prep('uOk', 'UPDATE users SET failed_logins = 0, locked_until = 0, last_login_at = ? WHERE id = ?').run(Date.now(), id),
    deleteUser(id) {
      tx(() => {
        // keep the bug reports but drop the person's email from them
        prep('bAnon', "UPDATE bug_reports SET reporter = 'deleted account' WHERE user_id = ?").run(id);
        prep('uDel', 'DELETE FROM users WHERE id = ?').run(id);
      });
    },
    listUsers() {
      const rows = prep('uList', `
        SELECT u.*, (SELECT group_concat(provider) FROM identities i WHERE i.user_id = u.id) AS providers
        FROM users u ORDER BY u.created_at DESC LIMIT 1000`).all();
      return rows.map((r) => ({ ...toUser(r), providers: r.providers ? r.providers.split(',') : [] }));
    },

    // ── identities ──
    findIdentityUser: (provider, pid) => toUser(prep('idFind', `
      SELECT u.* FROM identities i JOIN users u ON u.id = i.user_id WHERE i.provider = ? AND i.provider_user_id = ?`).get(provider, pid)),
    addIdentity: (provider, pid, userId) => prep('idIns', 'INSERT OR IGNORE INTO identities (provider, provider_user_id, user_id) VALUES (?, ?, ?)').run(provider, pid, userId),

    // Called only after the provider confirmed the email address.
    // If a password account already exists for that email but was never verified, it could
    // have been created by someone else, so its password is wiped and its sessions revoked.
    resolveOAuthUser(provider, profile) {
      return tx(() => {
        let user = store.findIdentityUser(provider, profile.id);
        if (user) return { user, created: false, takeover: false };
        user = store.getUserByEmail(profile.email);
        let takeover = false;
        if (user) {
          if (!user.emailVerified) {
            prep('uVerify', 'UPDATE users SET password_hash = NULL, email_verified = 1, failed_logins = 0, locked_until = 0 WHERE id = ?').run(user.id);
            store.deleteUserSessions(user.id);
            takeover = Boolean(user.passwordHash);
          }
          store.addIdentity(provider, profile.id, user.id);
          return { user: store.getUserById(user.id), created: false, takeover };
        }
        user = store.createUser({ email: profile.email, verified: true });
        store.addIdentity(provider, profile.id, user.id);
        return { user, created: true, takeover: false };
      });
    },

    // ── sessions ──
    createSession: (s) => prep('sIns', 'INSERT INTO sessions (id_hash, user_id, csrf, created_at, last_seen, idle_ms, abs_ms, ip, ua, mfa_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(s.idHash, s.userId, s.csrf, s.now, s.now, s.idleMs, s.absMs, s.ip || null, (s.ua || '').slice(0, 200), s.mfaAt || null),
    getSession: (idHash) => prep('sGet', `
      SELECT s.id_hash, s.csrf, s.created_at, s.last_seen, s.idle_ms, s.abs_ms,
             s.mfa_at, u.id AS user_id, u.email, u.email_verified, u.totp_enabled
      FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id_hash = ?`).get(idHash),
    touchSession: (idHash, now) => prep('sTouch', 'UPDATE sessions SET last_seen = ? WHERE id_hash = ?').run(now, idHash),
    deleteSession: (idHash) => prep('sDel', 'DELETE FROM sessions WHERE id_hash = ?').run(idHash),
    deleteUserSessions: (userId) => prep('sDelUser', 'DELETE FROM sessions WHERE user_id = ?').run(userId),
    deleteOtherSessions: (userId, keepHash) => prep('sDelOther', 'DELETE FROM sessions WHERE user_id = ? AND id_hash <> ?').run(userId, keepHash),
    countUserSessions: (userId) => prep('sCount', 'SELECT COUNT(*) AS n FROM sessions WHERE user_id = ?').get(userId).n,

    // ── two-factor ──
    setTotpPending: (id, encSecret) => prep('tPend', 'UPDATE users SET totp_secret = ? WHERE id = ? AND totp_enabled = 0').run(encSecret, id),
    enableTotp: (id, step) => prep('tOn', `UPDATE users SET totp_enabled = 1, totp_last_step = ?, totp_failures = 0, totp_locked_until = 0,
                                            mfa_email_code = NULL, mfa_email_exp = 0 WHERE id = ?`).run(step, id),
    totpSuccess: (id, step) => prep('tOk', 'UPDATE users SET totp_last_step = MAX(totp_last_step, ?), totp_failures = 0 WHERE id = ?').run(step, id),
    recordTotpFailure(id, maxFailures, lockMs) {
      const u = store.getUserById(id);
      const failures = (u ? u.totpFailures : 0) + 1;
      if (failures >= maxFailures) {
        prep('tLock', 'UPDATE users SET totp_failures = 0, totp_locked_until = ? WHERE id = ?').run(Date.now() + lockMs, id);
        return { locked: true };
      }
      prep('tFail', 'UPDATE users SET totp_failures = ? WHERE id = ?').run(failures, id);
      return { locked: false };
    },
    resetTotp(id) {
      tx(() => {
        prep('tReset', `UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_last_step = 0, totp_failures = 0,
                        totp_locked_until = 0, mfa_email_code = NULL, mfa_email_exp = 0 WHERE id = ?`).run(id);
        prep('rcClr', 'DELETE FROM recovery_codes WHERE user_id = ?').run(id);
      });
    },
    setMfaEmailCode: (id, hash, exp) => prep('tMail', 'UPDATE users SET mfa_email_code = ?, mfa_email_exp = ? WHERE id = ?').run(hash, exp, id),
    replaceRecoveryCodes(id, hashes) {
      tx(() => {
        prep('rcClr', 'DELETE FROM recovery_codes WHERE user_id = ?').run(id);
        for (const h of hashes) prep('rcIns', 'INSERT INTO recovery_codes (user_id, code_hash) VALUES (?, ?)').run(id, h);
      });
    },
    useRecoveryCode: (id, hash) => prep('rcUse', 'UPDATE recovery_codes SET used_at = ? WHERE user_id = ? AND code_hash = ? AND used_at IS NULL')
      .run(Date.now(), id, hash).changes > 0,
    countRecoveryCodes: (id) => prep('rcCount', 'SELECT COUNT(*) AS n FROM recovery_codes WHERE user_id = ? AND used_at IS NULL').get(id).n,
    hasAuditFrom: (actor, action, ip) => Boolean(prep('auIp', 'SELECT 1 AS ok FROM audit WHERE actor = ? AND action = ? AND ip = ? LIMIT 1').get(actor, action, ip)),
    purgeExpired(now = Date.now()) {
      prep('sPurge', 'DELETE FROM sessions WHERE ? - last_seen > idle_ms OR ? - created_at > abs_ms').run(now, now);
      prep('oPurge', 'DELETE FROM oauth_states WHERE expires_at < ?').run(now);
      prep('etPurge', 'DELETE FROM email_tokens WHERE expires_at < ?').run(now);
    },

    // ── patrons (supporters). Access is by verified email, so it works for people who sign in any way. ──
    getPatron: (email) => toPatron(prep('pGet', PATRON_SELECT + ' WHERE p.email = ?').get(email)),
    listPatrons: () => prep('pList', PATRON_SELECT + ' ORDER BY p.since DESC LIMIT 2000').all().map(toPatron),
    upsertPatron({ email, tier, until, note, by }) {
      prep('pUp', `INSERT INTO patrons (email, tier, since, until, note, granted_by) VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(email) DO UPDATE SET tier = excluded.tier, until = excluded.until, note = excluded.note, granted_by = excluded.granted_by`)
        .run(email, tier, Date.now(), until ?? null, note || '', by);
      return store.getPatron(email);
    },
    patchPatron(email, patch, by) {
      const cur = store.getPatron(email);
      if (!cur) return null;
      prep('pPatch', 'UPDATE patrons SET tier = ?, until = ?, note = ?, hide_wall = ?, granted_by = ? WHERE email = ?').run(
        patch.tier ?? cur.tier, patch.until === undefined ? cur.until : patch.until, patch.note ?? cur.note,
        (patch.hideWall === undefined ? cur.hideWall : patch.hideWall) ? 1 : 0, by, email);
      return store.getPatron(email);
    },
    removePatron: (email) => prep('pDel', 'DELETE FROM patrons WHERE email = ?').run(email).changes > 0,
    countActivePatrons: () => prep('pCount', 'SELECT COUNT(*) AS n FROM patrons WHERE until IS NULL OR until > ?').get(Date.now()).n,
    // The public supporter wall: only people who opted in with a display name, verified, active, not hidden.
    patronWall: () => prep('pWall', `SELECT u.display_name AS name, p.tier FROM patrons p JOIN users u ON u.email = p.email
                                     WHERE u.wall_opt_in = 1 AND u.display_name IS NOT NULL AND u.email_verified = 1
                                       AND p.hide_wall = 0 AND (p.until IS NULL OR p.until > ?) ORDER BY p.since ASC LIMIT 300`).all(Date.now()),
    setProfile: (id, { mcUsername, displayName, wallOptIn }) => prep('uProf', 'UPDATE users SET mc_username = ?, display_name = ?, wall_opt_in = ? WHERE id = ?')
      .run(mcUsername || null, displayName || null, wallOptIn ? 1 : 0, id),

    ping: () => prep('ping', 'SELECT 1 AS ok').get().ok === 1,

    // ── server problem reports (community "downdetector") ──
    // Only a one-way hash of who reported is kept, never an IP address.
    addOutage: ({ server, kind, reporter }) => prep('oIns', 'INSERT INTO outage_reports (server_name, kind, reporter_hash, created_at) VALUES (?, ?, ?, ?)').run(server, kind, reporter, Date.now()),
    hasRecentOutage: (server, reporter, since) => Boolean(prep('oHas', 'SELECT 1 FROM outage_reports WHERE server_name = ? AND reporter_hash = ? AND created_at > ? LIMIT 1').get(server, reporter, since)),
    // distinct people per server and kind since a time
    outageCounts: (since) => prep('oCnt', 'SELECT server_name AS name, kind, COUNT(DISTINCT reporter_hash) AS n FROM outage_reports WHERE created_at > ? GROUP BY server_name, kind').all(since),
    // distinct people per server per clock hour since a time
    outageHours: (since) => prep('oHrs', 'SELECT server_name AS name, created_at / 3600000 AS hour, COUNT(DISTINCT reporter_hash) AS n FROM outage_reports WHERE created_at > ? GROUP BY server_name, hour').all(since),
    recentOutages: (limit = 50) => prep('oRec', 'SELECT server_name AS name, kind, created_at AS at FROM outage_reports ORDER BY id DESC LIMIT ?').all(Math.min(Math.max(limit, 1), 200)),
    purgeOutages: (before) => prep('oPurge', 'DELETE FROM outage_reports WHERE created_at < ?').run(before).changes,

    // ── admin notes ──
    listNotes: () => prep('nList', 'SELECT * FROM notes ORDER BY pinned DESC, updated_at DESC, id DESC LIMIT 500').all().map(toNote),
    countNotes: () => prep('nCount', 'SELECT COUNT(*) AS n FROM notes').get().n,
    getNote: (id) => toNote(prep('nGet', 'SELECT * FROM notes WHERE id = ?').get(id)),
    createNote({ body, pinned, author }) {
      const now = Date.now();
      const r = prep('nIns', 'INSERT INTO notes (body, pinned, author, created_at, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?)')
        .run(body, pinned ? 1 : 0, author, now, now, author);
      return store.getNote(Number(r.lastInsertRowid));
    },
    updateNote(id, { body, pinned }, by) {
      const cur = store.getNote(id);
      if (!cur) return null;
      prep('nUp', 'UPDATE notes SET body = ?, pinned = ?, updated_at = ?, updated_by = ? WHERE id = ?')
        .run(body === undefined ? cur.body : body, (pinned === undefined ? cur.pinned : pinned) ? 1 : 0, Date.now(), by, id);
      return store.getNote(id);
    },
    deleteNote: (id) => prep('nDel', 'DELETE FROM notes WHERE id = ?').run(id).changes > 0,

    // ── bug reports ──
    countBugs: () => prep('bCount', 'SELECT COUNT(*) AS n FROM bug_reports').get().n,
    countBugsByUserSince: (userId, since) => prep('bRecent', 'SELECT COUNT(*) AS n FROM bug_reports WHERE user_id = ? AND created_at > ?').get(userId, since).n,
    createBug({ userId, reporter, title, description, category, serverName }) {
      const now = Date.now();
      const r = prep('bIns', `INSERT INTO bug_reports (user_id, reporter, title, description, category, server_name, created_at, updated_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(userId, reporter, title, description, category, serverName, now, now);
      return store.getBug(Number(r.lastInsertRowid));
    },
    getBug: (id) => toBug(prep('bGet', 'SELECT * FROM bug_reports WHERE id = ?').get(id)),
    listBugs: () => prep('bList', 'SELECT * FROM bug_reports ORDER BY created_at DESC, id DESC LIMIT 2000').all().map(toBug),
    listBugsByUser: (userId) => prep('bMine', 'SELECT * FROM bug_reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(userId).map(toBug),
    updateBug(id, { status, priority, adminNote }, by) {
      const cur = store.getBug(id);
      if (!cur) return null;
      prep('bUp', 'UPDATE bug_reports SET status = ?, priority = ?, admin_note = ?, updated_at = ?, updated_by = ? WHERE id = ?')
        .run(status ?? cur.status, priority ?? cur.priority, adminNote ?? cur.adminNote, Date.now(), by, id);
      return store.getBug(id);
    },
    deleteBug: (id) => prep('bDel', 'DELETE FROM bug_reports WHERE id = ?').run(id).changes > 0,

    // ── emailed links (sign-up / password reset). Only a hash of the token is stored. ──
    lastEmailTokenAt: (email) => (prep('etLast', 'SELECT MAX(created_at) AS t FROM email_tokens WHERE email = ?').get(email) || {}).t || 0,
    saveEmailToken(email, tokenHash, expiresAt) {
      tx(() => {
        prep('etClr', 'DELETE FROM email_tokens WHERE email = ?').run(email); // a new link replaces older ones
        prep('etIns', 'INSERT INTO email_tokens (token_hash, email, expires_at, created_at) VALUES (?, ?, ?, ?)')
          .run(tokenHash, email, expiresAt, Date.now());
      });
    },
    peekEmailToken(tokenHash) {
      const row = prep('etGet', 'SELECT email, expires_at FROM email_tokens WHERE token_hash = ?').get(tokenHash);
      return row && row.expires_at > Date.now() ? { email: row.email } : null;
    },
    takeEmailToken(tokenHash) {
      return tx(() => {
        const row = prep('etGet', 'SELECT email, expires_at FROM email_tokens WHERE token_hash = ?').get(tokenHash);
        if (!row) return null;
        prep('etDel', 'DELETE FROM email_tokens WHERE token_hash = ?').run(tokenHash);
        return row.expires_at > Date.now() ? { email: row.email } : null;
      });
    },
    markVerified: (id) => prep('uVer', 'UPDATE users SET email_verified = 1 WHERE id = ?').run(id),

    // ── oauth state ──
    saveOAuthState: (s) => prep('oIns', 'INSERT INTO oauth_states (state_hash, provider, verifier, binding_hash, expires_at) VALUES (?, ?, ?, ?, ?)')
      .run(s.stateHash, s.provider, s.verifier || null, s.bindingHash, s.expiresAt),
    takeOAuthState(stateHash) {
      return tx(() => {
        const row = prep('oGet', 'SELECT * FROM oauth_states WHERE state_hash = ?').get(stateHash);
        if (row) prep('oDel', 'DELETE FROM oauth_states WHERE state_hash = ?').run(stateHash);
        return row || null;
      });
    },

    // ── admins ──
    isAdminEmail: (email) => Boolean(prep('aIs', 'SELECT 1 AS ok FROM admins WHERE email = ?').get(email)),
    isOwnerEmail: (email) => Boolean(prep('aOwn', 'SELECT 1 AS ok FROM admins WHERE email = ? AND is_owner = 1').get(email)),
    listAdmins: () => prep('aList', 'SELECT email, is_owner, added_by, created_at FROM admins ORDER BY is_owner DESC, created_at ASC').all()
      .map((r) => ({ email: r.email, isOwner: r.is_owner === 1, addedBy: r.added_by, createdAt: r.created_at })),
    addAdmin: (email, addedBy, isOwner = false) => prep('aIns', 'INSERT OR IGNORE INTO admins (email, is_owner, added_by, created_at) VALUES (?, ?, ?, ?)')
      .run(email, isOwner ? 1 : 0, addedBy, Date.now()),
    removeAdmin: (email) => prep('aDel', 'DELETE FROM admins WHERE email = ? AND is_owner = 0').run(email),
    syncOwners(emails) {
      tx(() => {
        prep('aClr', 'UPDATE admins SET is_owner = 0').run();
        for (const email of emails) {
          prep('aOwnUp', `INSERT INTO admins (email, is_owner, added_by, created_at) VALUES (?, 1, 'config', ?)
                          ON CONFLICT(email) DO UPDATE SET is_owner = 1`).run(email, Date.now());
        }
      });
    },

    // ── site settings ──
    getSite() {
      let row = prep('siteGet', 'SELECT * FROM site WHERE id = 1').get();
      if (!row) {
        prep('siteSeed', 'INSERT INTO site (id, data, version, updated_at, updated_by) VALUES (1, ?, 1, ?, ?)')
          .run(JSON.stringify(DEFAULT_SITE), Date.now(), 'system');
        row = prep('siteGet', 'SELECT * FROM site WHERE id = 1').get();
      }
      return { data: JSON.parse(row.data), version: row.version, updatedAt: row.updated_at, updatedBy: row.updated_by };
    },
    // Compare-and-swap so two admins cannot silently overwrite each other.
    saveSite(data, baseVersion, actor) {
      return tx(() => {
        const current = store.getSite();
        if (current.version !== baseVersion) return { conflict: true, current };
        prep('siteSave', 'UPDATE site SET data = ?, version = version + 1, updated_at = ?, updated_by = ? WHERE id = 1')
          .run(JSON.stringify(data), Date.now(), actor);
        return { conflict: false, current: store.getSite() };
      });
    },

    // ── audit log ──
    addAudit: (actor, action, detail, ip) => prep('auIns', 'INSERT INTO audit (ts, actor, action, detail, ip) VALUES (?, ?, ?, ?, ?)')
      .run(Date.now(), actor || null, action, detail ? String(detail).slice(0, 300) : null, ip || null),
    listAudit: (limit = 50) => prep('auList', 'SELECT ts, actor, action, detail, ip FROM audit ORDER BY id DESC LIMIT ?').all(Math.min(Math.max(limit, 1), 200)),
    pruneAudit: () => prep('auPrune', 'DELETE FROM audit WHERE id NOT IN (SELECT id FROM audit ORDER BY id DESC LIMIT 5000)').run(),
  };
  return store;
}

module.exports = { openDb, createStore };
