'use strict';
// Reads settings from environment variables (see .env.example).

const path = require('node:path');
const crypto = require('node:crypto');

function list(value) {
  return String(value || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
}

function int(value, fallback) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? n : fallback;
}

const MIN = 60 * 1000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

function loadConfig(env = process.env) {
  const root = path.resolve(__dirname, '..');
  const nodeEnv = env.NODE_ENV || 'development';
  const isProd = nodeEnv === 'production';
  const port = int(env.PORT, 3000);

  const appUrl = String(env.APP_URL || `http://localhost:${port}`).replace(/\/+$/, '');
  const parsed = new URL(appUrl); // throws on a malformed URL

  // Serving visitors directly (no Caddy/nginx in front): the app can speak HTTPS itself.
  const tlsCert = env.TLS_CERT_FILE ? path.resolve(env.TLS_CERT_FILE) : '';
  const tlsKey = env.TLS_KEY_FILE ? path.resolve(env.TLS_KEY_FILE) : '';
  if (Boolean(tlsCert) !== Boolean(tlsKey)) throw new Error('Set both TLS_CERT_FILE and TLS_KEY_FILE (or neither).');
  const allowInsecureHttp = /^(1|true|yes|on)$/i.test(env.ALLOW_INSECURE_HTTP || '');
  if (tlsCert && parsed.protocol !== 'https:') throw new Error('TLS_CERT_FILE is set, so APP_URL must start with https://');
  if (isProd && parsed.protocol !== 'https:' && !allowInsecureHttp) {
    throw new Error('APP_URL must start with https:// when NODE_ENV=production. (Plain http needs ALLOW_INSECURE_HTTP=1 and is not recommended: passwords would travel unencrypted.)');
  }
  const direct = Boolean(tlsCert) || allowInsecureHttp; // no reverse proxy in front
  if (parsed.pathname !== '/' && parsed.pathname !== '') {
    throw new Error('APP_URL must not contain a path (use https://example.com)');
  }

  const dataDir = path.resolve(env.DATA_DIR || path.join(root, 'data'));

  // SECRET_KEY encrypts 2FA secrets in the database. Required in production.
  let secretKey;
  if (env.SECRET_KEY) {
    if (env.SECRET_KEY.length < 32) throw new Error('SECRET_KEY must be at least 32 characters long.');
    secretKey = crypto.createHash('sha256').update(env.SECRET_KEY).digest();
  } else if (isProd) {
    throw new Error('SECRET_KEY is required in production. Generate one with:  node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'base64\'))"');
  } else {
    secretKey = crypto.createHash('sha256').update('yuni-development-only-key').digest();
  }
  const flag = (v, dflt) => (v === undefined || v === '' ? dflt : /^(1|true|yes|on)$/i.test(v));

  const provider = (name, defaults) => {
    const prefix = name.toUpperCase();
    const clientId = env[`${prefix}_CLIENT_ID`] || '';
    const clientSecret = env[`${prefix}_CLIENT_SECRET`] || '';
    return { name, clientId, clientSecret, enabled: Boolean(clientId && clientSecret), ...defaults };
  };

  return {
    nodeEnv,
    isProd,
    host: env.HOST || '127.0.0.1',
    port,
    appUrl,
    origin: parsed.origin,
    secureCookies: parsed.protocol === 'https:',
    // Number of reverse proxies in front. Must be 0 when visitors connect directly, or they could fake their IP.
    trustProxy: int(env.TRUST_PROXY, isProd && !direct ? 1 : 0),
    tls: tlsCert ? { certFile: tlsCert, keyFile: tlsKey } : null,
    allowInsecureHttp,
    direct,
    publicDir: path.join(root, 'public'),
    dataDir,
    dbFile: env.DB_FILE ? path.resolve(env.DB_FILE) : path.join(dataDir, 'yuni.db'),
    downloadsDir: path.resolve(env.DOWNLOADS_DIR || path.join(dataDir, 'downloads')),
    backupsDir: path.join(dataDir, 'backups'),
    ownerEmails: list(env.ADMIN_EMAILS),

    providers: {
      google: provider('google', {
        authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
        tokenUrl: 'https://oauth2.googleapis.com/token',
        userinfoUrl: 'https://openidconnect.googleapis.com/v1/userinfo',
        scope: 'openid email',
        pkce: true,
      }),
      discord: provider('discord', {
        authUrl: 'https://discord.com/oauth2/authorize',
        tokenUrl: 'https://discord.com/api/oauth2/token',
        userinfoUrl: 'https://discord.com/api/users/@me',
        scope: 'identify email',
        pkce: false,
      }),
    },

    // Outgoing email (verification and password-reset links). Without SMTP_HOST + MAIL_FROM it is off.
    mail: {
      host: env.SMTP_HOST || '',
      port: int(env.SMTP_PORT, 587),
      secure: env.SMTP_SECURE ? /^(1|true|yes)$/i.test(env.SMTP_SECURE) : int(env.SMTP_PORT, 587) === 465,
      user: env.SMTP_USER || '',
      pass: env.SMTP_PASS || '',
      from: env.MAIL_FROM || '',
      enabled: Boolean(env.SMTP_HOST && env.MAIL_FROM),
      allowPlain: false,          // test-only: allow SMTP without TLS
      ca: undefined,              // test-only: extra trusted CA
      tokenTtlMs: HOUR,
      cooldownMs: MIN,
    },

    security: {
      secretKey,
      requireAdmin2fa: flag(env.REQUIRE_ADMIN_2FA, true),
      stepUpMs: 15 * MIN,          // dangerous admin actions need a 2FA code from the last 15 minutes
      mfaMaxFailures: 5,
      mfaLockMs: 15 * MIN,
      mfaEmailCodeMs: 15 * MIN,
      breachedPasswordCheck: flag(env.BREACHED_PASSWORD_CHECK, isProd),
      breachedPasswordApi: 'https://api.pwnedpasswords.com/range/',
    },

    statusApi: 'https://api.mcsrvstat.us/3/',

    session: {
      memberIdleMs: 7 * DAY,
      memberAbsoluteMs: 30 * DAY,
      adminIdleMs: 30 * MIN,
      adminAbsoluteMs: 12 * HOUR,
    },

    lockout: { maxFailures: 5, durationMs: 15 * MIN },

    // fixed-window limits, per client IP
    rate: {
      global: { max: 600, windowMs: MIN },
      auth: { max: 20, windowMs: 15 * MIN },
      status: { max: 30, windowMs: MIN },
      report: { max: 20, windowMs: HOUR },
    },

    limits: { jsonBytes: 256 * 1024 },
  };
}

module.exports = { loadConfig };
