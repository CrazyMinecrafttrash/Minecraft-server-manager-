'use strict';
// Sessions, CSRF and request guards.
//
// Sessions are random 256-bit tokens kept in an HttpOnly cookie. Only a SHA-256 hash of the
// token is stored in the database, so a leaked database cannot be used to hijack sessions.
// Admin rights are looked up on EVERY request, so removing an admin takes effect immediately.
//
// Two-factor: someone on the admin list only gets admin rights in a session where they have also
// entered a code from their authenticator app (sessions.mfa_at). Until then they are "pending":
// signed in, but with member rights only.

const { randomToken, sha256, safeEqual, serializeCookie } = require('./security');
const { HttpError } = require('./http');

function createAuth({ config, store }) {
  const sidName = config.secureCookies ? '__Host-yuni_sid' : 'yuni_sid';
  const cookieBase = { secure: config.secureCookies };

  function setSessionCookie(res, token, maxAgeMs) {
    res.addCookie(serializeCookie(sidName, token, { ...cookieBase, maxAgeSec: maxAgeMs / 1000 }));
  }

  function clearSessionCookie(res) {
    res.addCookie(serializeCookie(sidName, '', { ...cookieBase, maxAgeSec: 0 }));
  }

  function publicUser(user) {
    return {
      email: user.email,
      emailVerified: user.emailVerified,
      isAdmin: user.isAdmin,
      isOwner: user.isOwner,
      totpEnabled: user.totpEnabled,
      // 'setup' = must turn on 2FA before getting admin rights; 'verify' = must enter a code
      mfa: user.mfaPending ? (user.totpEnabled ? 'verify' : 'setup') : null,
    };
  }

  // Works out what a signed-in person may do, given whether this session has passed 2FA.
  function describe({ id, email, verified, totpEnabled, mfaAt }) {
    const listed = verified && store.isAdminEmail(email);
    const needsMfa = listed && (config.security.requireAdmin2fa || totpEnabled);
    const mfaOk = !needsMfa || Boolean(mfaAt);
    return {
      id, email, emailVerified: verified, totpEnabled,
      isListedAdmin: listed,
      mfaPending: needsMfa && !mfaOk,
      isAdmin: listed && mfaOk,
      isOwner: listed && mfaOk && store.isOwnerEmail(email),
    };
  }

  // Fills req.user / req.session (both null when signed out).
  function loadSession(req, res) {
    req.user = null;
    req.session = null;
    const token = req.cookies[sidName];
    if (!token || token.length > 128) return;
    const idHash = sha256(token);
    const row = store.getSession(idHash);
    if (!row) { clearSessionCookie(res); return; }

    const now = Date.now();
    if (now - row.last_seen > row.idle_ms || now - row.created_at > row.abs_ms) {
      store.deleteSession(idHash);
      clearSessionCookie(res);
      return;
    }
    if (now - row.last_seen > 60 * 1000) store.touchSession(idHash, now);

    req.user = describe({
      id: Number(row.user_id), email: row.email, verified: row.email_verified === 1,
      totpEnabled: row.totp_enabled === 1, mfaAt: row.mfa_at,
    });
    req.session = { idHash, csrf: row.csrf, mfaAt: row.mfa_at || 0 };
  }

  // Always issues a brand-new session id (prevents session fixation). It is also called again
  // after a 2FA code is accepted, so the higher-privilege session never reuses the old id.
  function startSession(req, res, user, { mfaAt = null } = {}) {
    if (req.session) store.deleteSession(req.session.idHash);
    const verified = user.emailVerified;
    const listed = verified && store.isAdminEmail(user.email);
    const idleMs = listed ? config.session.adminIdleMs : config.session.memberIdleMs;
    const absMs = listed ? config.session.adminAbsoluteMs : config.session.memberAbsoluteMs;
    const token = randomToken(32);
    const csrf = randomToken(24);
    store.createSession({
      idHash: sha256(token), userId: user.id, csrf, now: Date.now(), idleMs, absMs,
      ip: req.ip, ua: req.headers['user-agent'], mfaAt,
    });
    setSessionCookie(res, token, absMs);
    req.user = describe({ id: user.id, email: user.email, verified, totpEnabled: Boolean(user.totpEnabled), mfaAt });
    req.session = { idHash: sha256(token), csrf, mfaAt: mfaAt || 0 };
    return { csrf, user: req.user };
  }

  function endSession(req, res) {
    if (req.session) store.deleteSession(req.session.idHash);
    clearSessionCookie(res);
    req.user = null;
    req.session = null;
  }

  // Browsers always send Origin on cross-site POSTs; refuse anything not from our own site.
  function checkOrigin(req) {
    const origin = req.headers.origin;
    if (origin) {
      if (origin !== config.origin) throw new HttpError(403, 'Cross-site request blocked.');
      return;
    }
    const site = req.headers['sec-fetch-site'];
    if (site === 'same-origin' || site === 'none') return;
    throw new HttpError(403, 'Cross-site request blocked.');
  }

  function checkCsrf(req) {
    const sent = req.headers['x-csrf-token'];
    if (typeof sent !== 'string' || !safeEqual(sent, req.session.csrf)) {
      throw new HttpError(403, 'Your session check failed. Reload the page and try again.');
    }
  }

  return {
    sidName, loadSession, startSession, endSession, publicUser, checkOrigin, checkCsrf,
  };
}

module.exports = { createAuth };
