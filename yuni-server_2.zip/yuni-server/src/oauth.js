'use strict';
// "Sign in with Google / Discord" using the authorization-code flow, done entirely on the server:
//   - the client secret never reaches the browser
//   - `state` is single-use and bound to this browser by a cookie (blocks login CSRF)
//   - PKCE is used where the provider supports it
//   - the provider must confirm the email address is verified

const { createHash } = require('node:crypto');
const { randomToken, sha256, safeEqual, serializeCookie, normalizeEmail } = require('./security');

const STATE_TTL_MS = 10 * 60 * 1000;

function createOAuth({ config, store, auth }) {
  const bindName = config.secureCookies ? '__Host-yuni_oauth' : 'yuni_oauth';
  const userAgent = `YuniDoc (${config.appUrl})`;

  const redirectUri = (name) => `${config.appUrl}/auth/${name}/callback`;
  const fail = (res, code) => res.redirect(`/admin/login.html?error=${encodeURIComponent(code)}`);
  const clearBinding = (res) => res.addCookie(serializeCookie(bindName, '', { secure: config.secureCookies, maxAgeSec: 0, path: '/' }));

  async function postForm(url, fields) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json', 'User-Agent': userAgent },
      body: new URLSearchParams(fields),
      signal: AbortSignal.timeout(8000),
      redirect: 'error',
    });
    if (!res.ok) throw new Error(`token endpoint returned ${res.status}`);
    return res.json();
  }

  async function getJson(url, accessToken) {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: 'application/json', 'User-Agent': userAgent },
      signal: AbortSignal.timeout(8000),
      redirect: 'error',
    });
    if (!res.ok) throw new Error(`userinfo returned ${res.status}`);
    return res.json();
  }

  // Normalises each provider's profile to { id, email, verified }.
  function readProfile(name, data) {
    if (name === 'google') {
      return { id: data.sub, email: data.email, verified: data.email_verified === true };
    }
    return { id: data.id, email: data.email, verified: data.verified === true };
  }

  function start(req, res) {
    const name = req.params.provider;
    const provider = config.providers[name];
    if (!provider || !provider.enabled) return fail(res, 'provider_unavailable');

    const state = randomToken(24);
    const binding = randomToken(24);
    const verifier = provider.pkce ? randomToken(48) : null;
    store.saveOAuthState({
      stateHash: sha256(state), provider: name, verifier, bindingHash: sha256(binding), expiresAt: Date.now() + STATE_TTL_MS,
    });

    const params = new URLSearchParams({
      client_id: provider.clientId,
      redirect_uri: redirectUri(name),
      response_type: 'code',
      scope: provider.scope,
      state,
    });
    if (verifier) {
      params.set('code_challenge', createHash('sha256').update(verifier).digest('base64url'));
      params.set('code_challenge_method', 'S256');
    }
    if (name === 'google') params.set('prompt', 'select_account');
    if (name === 'discord') params.set('prompt', 'none');

    res.addCookie(serializeCookie(bindName, binding, { secure: config.secureCookies, maxAgeSec: STATE_TTL_MS / 1000, path: '/' }));
    return res.redirect(`${provider.authUrl}?${params.toString()}`);
  }

  async function callback(req, res) {
    const name = req.params.provider;
    const provider = config.providers[name];
    const binding = req.cookies[bindName];
    clearBinding(res);
    if (!provider || !provider.enabled) return fail(res, 'provider_unavailable');

    const { code, state, error } = req.query;
    if (error) return fail(res, 'denied');
    if (typeof code !== 'string' || typeof state !== 'string' || typeof binding !== 'string'
        || code.length > 2048 || state.length > 256) return fail(res, 'state');

    const row = store.takeOAuthState(sha256(state));
    if (!row || row.provider !== name || row.expires_at < Date.now() || !safeEqual(row.binding_hash, sha256(binding))) {
      return fail(res, 'state');
    }

    let profile;
    try {
      const fields = {
        grant_type: 'authorization_code',
        code,
        redirect_uri: redirectUri(name),
        client_id: provider.clientId,
        client_secret: provider.clientSecret,
      };
      if (row.verifier) fields.code_verifier = row.verifier;
      const token = await postForm(provider.tokenUrl, fields);
      if (typeof token.access_token !== 'string') throw new Error('no access token');
      profile = readProfile(name, await getJson(provider.userinfoUrl, token.access_token));
    } catch (err) {
      console.error(JSON.stringify({ level: 'warn', msg: 'oauth exchange failed', provider: name, error: err.message }));
      return fail(res, 'provider_error');
    }

    const email = normalizeEmail(profile.email);
    if (!email || !profile.verified || typeof profile.id !== 'string' || !profile.id || profile.id.length > 100) {
      return fail(res, 'unverified');
    }

    const { user, created, takeover } = store.resolveOAuthUser(name, { id: profile.id, email });
    store.recordLogin(user.id);
    const session = auth.startSession(req, res, user);
    store.addAudit(user.email, `login.${name}`, [created ? 'new account' : '', takeover ? 'unverified password account was reset' : ''].filter(Boolean).join('; '), req.ip);
    if (session.user.mfaPending) return res.redirect('/admin/2fa.html');
    return res.redirect(session.user.isAdmin ? '/admin/dashboard.html' : '/profile.html');
  }

  return { start, callback };
}

module.exports = { createOAuth };
