'use strict';
// Password hashing, random tokens, cookies and a small in-memory rate limiter.

const crypto = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(crypto.scrypt);

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = (value) => crypto.createHash('sha256').update(String(value)).digest('hex');

function safeEqual(a, b) {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  if (A.length !== B.length) return false;
  return crypto.timingSafeEqual(A, B);
}

// ── Passwords (scrypt, per-user random salt) ───────────────
const SCRYPT = { N: 2 ** 15, r: 8, p: 1, keylen: 64, maxmem: 64 * 1024 * 1024 };

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password.normalize('NFKC'), salt, SCRYPT.keylen, {
    N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem,
  });
  return ['scrypt', SCRYPT.N, SCRYPT.r, SCRYPT.p, salt.toString('base64url'), key.toString('base64url')].join('$');
}

async function verifyPassword(password, stored) {
  try {
    const [scheme, N, r, p, salt, hash] = String(stored).split('$');
    if (scheme !== 'scrypt') return false;
    const expected = Buffer.from(hash, 'base64url');
    const key = await scrypt(password.normalize('NFKC'), Buffer.from(salt, 'base64url'), expected.length, {
      N: Number(N), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem,
    });
    return crypto.timingSafeEqual(key, expected);
  } catch {
    return false;
  }
}

// Used so that "unknown email" takes as long as "wrong password".
let dummyHash;
async function burnPasswordTime(password) {
  dummyHash = dummyHash || hashPassword(randomToken());
  await verifyPassword(password, await dummyHash);
}

const COMMON_PASSWORDS = new Set([
  'password', 'password1', 'password123', '1234567890', '12345678910', 'qwertyuiop', 'qwerty12345',
  'iloveyou123', 'minecraft', 'minecraft1', 'minecraft123', 'letmein123', 'welcome123', 'admin12345',
  'abcdefghij', '0123456789', 'passw0rd123', 'changeme123', 'yunidoc123',
]);

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[^\s@<>()[\]\\,;:"]+$/;

function normalizeEmail(value) {
  const email = String(value || '').trim().toLowerCase();
  if (email.length > 254 || !EMAIL_RE.test(email)) return null;
  return email;
}

// Returns a list of problems (empty = fine).
function checkPassword(password, email) {
  const problems = [];
  if (typeof password !== 'string') return ['Password is required.'];
  if (password.length < 10) problems.push('Use at least 10 characters.');
  if (password.length > 128) problems.push('Use 128 characters or fewer.');
  const lower = password.toLowerCase();
  if (COMMON_PASSWORDS.has(lower) || /^(.)\1+$/.test(password)) problems.push('That password is too common.');
  const local = String(email || '').split('@')[0];
  if (local.length >= 4 && lower.includes(local.toLowerCase())) problems.push('Do not include your email name in the password.');
  return problems;
}

// ── Cookies ────────────────────────────────────────────────
function parseCookies(header) {
  const out = Object.create(null);
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 1) continue;
    const name = part.slice(0, i).trim();
    const value = part.slice(i + 1).trim();
    if (name && !(name in out)) out[name] = value;
  }
  return out;
}

function serializeCookie(name, value, { maxAgeSec, secure, httpOnly = true, sameSite = 'Lax', path = '/' } = {}) {
  let c = `${name}=${value}; Path=${path}; SameSite=${sameSite}`;
  if (httpOnly) c += '; HttpOnly';
  if (secure) c += '; Secure';
  if (maxAgeSec !== undefined) c += `; Max-Age=${Math.max(0, Math.floor(maxAgeSec))}`;
  return c;
}

// ── Rate limiting (fixed window, in memory — fine for a single process) ──
class RateLimiter {
  constructor() {
    this.hits = new Map();
    this.timer = setInterval(() => this.sweep(), 60 * 1000);
    this.timer.unref();
  }

  hit(key, max, windowMs) {
    const now = Date.now();
    let entry = this.hits.get(key);
    if (!entry || entry.reset <= now) {
      entry = { count: 0, reset: now + windowMs };
      this.hits.set(key, entry);
    }
    entry.count += 1;
    return {
      allowed: entry.count <= max,
      retryAfterSec: Math.max(1, Math.ceil((entry.reset - now) / 1000)),
    };
  }

  sweep() {
    const now = Date.now();
    for (const [key, entry] of this.hits) if (entry.reset <= now) this.hits.delete(key);
    if (this.hits.size > 200000) this.hits.clear(); // hard memory cap
  }

  close() { clearInterval(this.timer); }
}

module.exports = {
  randomToken, sha256, safeEqual,
  hashPassword, verifyPassword, burnPasswordTime, checkPassword, normalizeEmail,
  parseCookies, serializeCookie, RateLimiter,
};
