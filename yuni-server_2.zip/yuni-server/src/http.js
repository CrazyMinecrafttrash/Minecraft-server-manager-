'use strict';
// A very small HTTP toolkit: routing, JSON bodies, static files, security headers.

const fs = require('node:fs');
const path = require('node:path');

class HttpError extends Error {
  constructor(status, message, details, code) {
    super(message);
    this.status = status;
    this.details = details;
    if (code) this.code = code;
  }
}

// ── Security headers (set on every response) ───────────────
function setSecurityHeaders(res, { secure }) {
  const csp = [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data:",
    "font-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ];
  if (secure) csp.push('upgrade-insecure-requests');
  res.setHeader('Content-Security-Policy', csp.join('; '));
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=()');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  if (secure) res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
}

// ── Request / response helpers ─────────────────────────────
function clientIp(req, trustProxy) {
  const socketIp = req.socket.remoteAddress || '';
  if (!trustProxy) return socketIp.replace(/^::ffff:/, '');
  // Take the address added by our own (trusted) proxy, counting from the right.
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
  const ip = forwarded[forwarded.length - trustProxy] || socketIp;
  return ip.replace(/^::ffff:/, '');
}

function decorate(res) {
  res.json = (status, body) => {
    if (res.headersSent) return;
    const data = JSON.stringify(body);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data) });
    res.end(data);
  };
  res.redirect = (location, status = 302) => {
    res.writeHead(status, { Location: location, 'Content-Length': 0 });
    res.end();
  };
  res.addCookie = (cookie) => {
    const prev = res.getHeader('Set-Cookie');
    res.setHeader('Set-Cookie', prev ? [].concat(prev, cookie) : cookie);
  };
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limit) { reject(new HttpError(413, 'Request is too large.')); return; }
    const chunks = [];
    let size = 0;
    let failed = false;
    req.on('data', (chunk) => {
      if (failed) return;
      size += chunk.length;
      if (size > limit) { failed = true; reject(new HttpError(413, 'Request is too large.')); return; }
      chunks.push(chunk);
    });
    req.on('end', () => { if (!failed) resolve(Buffer.concat(chunks)); });
    req.on('error', (err) => { if (!failed) reject(err); });
  });
}

async function readJson(req, limit) {
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  const raw = await readBody(req, limit);
  if (raw.length === 0) return {};
  if (type !== 'application/json') throw new HttpError(415, 'Content-Type must be application/json.');
  try {
    const value = JSON.parse(raw.toString('utf8'));
    if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('not an object');
    return value;
  } catch {
    throw new HttpError(400, 'Request body is not valid JSON.');
  }
}

// ── Router ─────────────────────────────────────────────────
function createRouter() {
  const routes = [];
  return {
    // add(method, pattern, options, handler)  — pattern may contain :params
    add(method, pattern, options, handler) {
      const keys = [];
      const source = pattern
        .replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
        .replace(/\/:([A-Za-z]+)/g, (_m, key) => { keys.push(key); return '/([^/]+)'; });
      routes.push({ method, re: new RegExp(`^${source}/?$`), keys, options: options || {}, handler });
    },
    match(method, pathname) {
      let pathMatched = false;
      for (const route of routes) {
        const m = route.re.exec(pathname);
        if (!m) continue;
        pathMatched = true;
        if (route.method !== method) continue;
        const params = {};
        try {
          route.keys.forEach((key, i) => { params[key] = decodeURIComponent(m[i + 1]); });
        } catch {
          return { badRequest: true };
        }
        return { route, params };
      }
      return { pathMatched };
    },
  };
}

// ── Static files ───────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.zip': 'application/zip',
  '.mrpack': 'application/zip', '.jar': 'application/java-archive',
};

// Resolves a URL path to a real file inside `root`, or null. Blocks traversal, dotfiles, symlink escapes.
async function resolveInside(root, urlPath) {
  let decoded;
  try { decoded = decodeURIComponent(urlPath); } catch { return null; }
  if (decoded.includes('\0') || decoded.includes('\\')) return null;
  const segments = decoded.split('/').filter(Boolean);
  if (segments.some((s) => s.startsWith('.') || s === '..')) return null;
  const rootReal = await fs.promises.realpath(root).catch(() => null);
  if (!rootReal) return null;
  let target = path.join(rootReal, ...segments);
  try {
    let stat = await fs.promises.stat(target);
    if (stat.isDirectory()) { target = path.join(target, 'index.html'); stat = await fs.promises.stat(target); }
    const real = await fs.promises.realpath(target);
    if (real !== rootReal && !real.startsWith(rootReal + path.sep)) return null;
    if (!stat.isFile()) return null;
    return { file: real, stat };
  } catch {
    return null;
  }
}

function sendFile(req, res, { file, stat }, { attachment = false, cache = 'no-cache' } = {}) {
  const ext = path.extname(file).toLowerCase();
  const etag = `W/"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': cache,
    ETag: etag,
    'Last-Modified': stat.mtime.toUTCString(),
    'Accept-Ranges': 'bytes',
  };
  if (attachment) headers['Content-Disposition'] = `attachment; filename="${path.basename(file).replace(/[^\w.\- ]/g, '_')}"`;

  if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); res.end(); return; }

  let start = 0;
  let end = stat.size - 1;
  let status = 200;
  const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || ''));
  if (range && (range[1] || range[2]) && stat.size > 0) {
    if (range[1] === '') { start = Math.max(0, stat.size - Number(range[2])); } else { start = Number(range[1]); if (range[2]) end = Math.min(end, Number(range[2])); }
    if (start > end || start >= stat.size) {
      res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
      res.end();
      return;
    }
    status = 206;
    headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
  }
  headers['Content-Length'] = stat.size === 0 ? 0 : end - start + 1;
  res.writeHead(status, headers);
  if (req.method === 'HEAD' || stat.size === 0) { res.end(); return; }
  const stream = fs.createReadStream(file, { start, end });
  stream.on('error', () => res.destroy());
  stream.pipe(res);
}

module.exports = {
  HttpError, setSecurityHeaders, clientIp, decorate, readJson, createRouter, resolveInside, sendFile,
};
