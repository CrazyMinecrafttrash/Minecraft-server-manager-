'use strict';

const fs = require('node:fs');
const path = require('node:path');

// Load .env if present (real environment variables win).
const envFile = process.env.ENV_FILE || path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);

const { loadConfig } = require('./config');
const { openDb } = require('./db');
const { createApp } = require('./app');
const { createServer } = require('./server');

const config = loadConfig();
fs.mkdirSync(config.downloadsDir, { recursive: true });

const db = openDb(config.dbFile);
const app = createApp({ config, db });

if (config.ownerEmails.length === 0 && app.store.listAdmins().length === 0) {
  console.warn('WARNING: no admins exist yet. Run "npm run create-admin" or set ADMIN_EMAILS in .env.');
}
for (const r of require('./checks').checkInstallation(config, { envFile })) {
  if (r.level === 'warn' || r.level === 'fail') console.warn(`SECURITY ${r.level.toUpperCase()}: ${r.msg}`);
}
console.log(config.mail.enabled
  ? `Email: enabled (${config.mail.host}:${config.mail.port}), sign-ups must confirm their address`
  : 'Email: DISABLED (set SMTP_HOST and MAIL_FROM). Password sign-ups will NOT be email-verified.');
for (const p of Object.values(config.providers)) {
  console.log(`${p.name} sign-in: ${p.enabled ? 'enabled' : 'disabled (no client id/secret set)'}`);
}

const server = createServer(config, app.handler);

server.listen(config.port, config.host, () => {
  console.log(`YuniDoc listening on ${config.tls ? 'https' : 'http'}://${config.host}:${config.port} (public URL: ${config.appUrl})`);
});

function shutdown(signal) {
  console.log(`${signal} received, shutting down`);
  server.close(() => {
    app.close();
    db.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
