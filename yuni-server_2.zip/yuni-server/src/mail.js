'use strict';
// Minimal SMTP client (no dependencies). Supports implicit TLS (port 465) and STARTTLS (port 587),
// AUTH PLAIN/LOGIN. It refuses to send credentials or mail over an unencrypted connection.

const net = require('node:net');
const tls = require('node:tls');
const crypto = require('node:crypto');
const os = require('node:os');

const TIMEOUT_MS = 15000;
const NO_CRLF = /[\r\n\0]/;

function address(from) {
  const m = /<([^<>\s]+)>/.exec(from);
  return (m ? m[1] : from).trim();
}

function encodeHeader(value) {
  if (NO_CRLF.test(value)) throw new Error('Illegal characters in mail header');
  return /^[\x20-\x7e]*$/.test(value) ? value : `=?UTF-8?B?${Buffer.from(value, 'utf8').toString('base64')}?=`;
}

function buildMessage({ from, to, subject, text, domain }) {
  const wrapped = Buffer.from(text, 'utf8').toString('base64').replace(/.{1,76}/g, '$&\r\n');
  return [
    `From: ${encodeHeader(from)}`,
    `To: ${encodeHeader(to)}`,
    `Subject: ${encodeHeader(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomUUID()}@${domain}>`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    'Auto-Submitted: auto-generated',
    '',
    wrapped,
  ].join('\r\n');
}

// Line-oriented reader that understands multi-line SMTP replies ("250-..." then "250 ...").
function createReader(getSocket) {
  let buffer = '';
  let waiting = null;
  const lines = [];
  function feed(chunk) {
    buffer += chunk.toString('utf8');
    let i;
    while ((i = buffer.indexOf('\r\n')) !== -1) { lines.push(buffer.slice(0, i)); buffer = buffer.slice(i + 2); }
    pump();
  }
  function pump() {
    if (!waiting) return;
    const end = lines.findIndex((l) => /^\d{3} /.test(l) || /^\d{3}$/.test(l));
    if (end === -1) return;
    const block = lines.splice(0, end + 1);
    const w = waiting; waiting = null;
    clearTimeout(w.timer);
    w.resolve({ code: Number(block[end].slice(0, 3)), lines: block });
  }
  function read() {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { waiting = null; reject(new Error('SMTP timeout')); getSocket().destroy(); }, TIMEOUT_MS);
      waiting = { resolve, reject, timer };
      pump();
    });
  }
  function fail(err) { if (waiting) { clearTimeout(waiting.timer); const w = waiting; waiting = null; w.reject(err); } }
  return { feed, read, fail };
}

async function sendMail(cfg, { to, subject, text }) {
  if (NO_CRLF.test(to) || NO_CRLF.test(subject)) throw new Error('Illegal characters in mail fields');
  const fromAddr = address(cfg.from);
  if (!fromAddr || NO_CRLF.test(cfg.from)) throw new Error('MAIL_FROM is not valid');
  const domain = fromAddr.split('@')[1] || 'localhost';

  let socket;
  const reader = createReader(() => socket);

  function attach(sock) {
    socket = sock;
    sock.on('data', reader.feed);
    sock.on('error', (e) => reader.fail(e));
    sock.on('close', () => reader.fail(new Error('SMTP connection closed')));
    sock.setTimeout(TIMEOUT_MS, () => sock.destroy(new Error('SMTP timeout')));
  }
  const tlsOptions = { host: cfg.host, servername: cfg.host, ca: cfg.ca, minVersion: 'TLSv1.2' };

  await new Promise((resolve, reject) => {
    const s = cfg.secure
      ? tls.connect({ ...tlsOptions, port: cfg.port }, resolve)
      : net.connect({ host: cfg.host, port: cfg.port }, resolve);
    s.once('error', reject);
    attach(s);
  });

  const say = (line) => socket.write(line + '\r\n');
  async function cmd(line, ok) {
    say(line);
    const r = await reader.read();
    if (!ok.includes(r.code)) throw new Error(`SMTP error after "${line.split(' ')[0]}": ${r.lines.join(' ')}`.slice(0, 300));
    return r;
  }

  try {
    const greeting = await reader.read();
    if (greeting.code !== 220) throw new Error('SMTP server refused the connection');
    let ehlo = await cmd(`EHLO ${os.hostname().replace(/[^A-Za-z0-9.-]/g, '') || 'localhost'}`, [250]);
    let encrypted = cfg.secure;

    if (!cfg.secure) {
      if (ehlo.lines.some((l) => /STARTTLS/i.test(l))) {
        await cmd('STARTTLS', [220]);
        socket.removeAllListeners('data'); socket.removeAllListeners('close'); socket.removeAllListeners('error');
        const raw = socket;
        await new Promise((resolve, reject) => {
          const t = tls.connect({ ...tlsOptions, socket: raw }, resolve);
          t.once('error', reject);
          attach(t);
        });
        ehlo = await cmd('EHLO localhost', [250]);
        encrypted = true;
      } else if (!cfg.allowPlain) {
        throw new Error('SMTP server does not offer STARTTLS; refusing to send over an unencrypted connection');
      }
    }

    if (cfg.user) {
      if (!encrypted && !cfg.allowPlain) throw new Error('Refusing to send SMTP credentials without TLS');
      const mechs = (ehlo.lines.find((l) => /AUTH/i.test(l)) || '').toUpperCase();
      if (mechs.includes('PLAIN') || !mechs) {
        await cmd('AUTH PLAIN ' + Buffer.from(`\0${cfg.user}\0${cfg.pass}`).toString('base64'), [235]);
      } else if (mechs.includes('LOGIN')) {
        await cmd('AUTH LOGIN', [334]);
        await cmd(Buffer.from(cfg.user).toString('base64'), [334]);
        await cmd(Buffer.from(cfg.pass).toString('base64'), [235]);
      } else {
        throw new Error('SMTP server offers no supported login method');
      }
    }

    await cmd(`MAIL FROM:<${fromAddr}>`, [250]);
    await cmd(`RCPT TO:<${to}>`, [250, 251]);
    await cmd('DATA', [354]);
    const body = buildMessage({ from: cfg.from, to, subject, text, domain }).replace(/^\./gm, '..');
    say(body + '\r\n.');
    const done = await reader.read();
    if (done.code !== 250) throw new Error('SMTP server rejected the message: ' + done.lines.join(' ').slice(0, 200));
    try { say('QUIT'); } catch { /* ignore */ }
  } finally {
    socket.destroy();
  }
}

function createMailer(config) {
  return {
    enabled: config.mail.enabled,
    send: (message) => sendMail(config.mail, message),
  };
}

module.exports = { createMailer, sendMail };
