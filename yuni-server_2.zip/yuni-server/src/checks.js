'use strict';
// Security self-checks, run at startup (warnings in the log) and by "npm run security-check".
const fs = require('node:fs');

function mode(file) {
  try { return fs.statSync(file).mode & 0o777; } catch { return null; }
}

function checkInstallation(config, { envFile } = {}) {
  const out = [];
  const ok = (msg) => out.push({ level: 'ok', msg });
  const warn = (msg) => out.push({ level: 'warn', msg });
  const fail = (msg) => out.push({ level: 'fail', msg });

  if (config.isProd) ok('Running in production mode.');
  else warn('NODE_ENV is not "production" (fine for testing, not for the public site).');

  if (config.tls) ok('Built-in HTTPS is on (the app serves its own TLS certificate).');
  else if (config.appUrl.startsWith('https://')) ok('Site address uses HTTPS.');
  else if (config.allowInsecureHttp) warn('Plain HTTP is allowed (ALLOW_INSECURE_HTTP). Passwords and login cookies travel unencrypted, so anyone on the network path can steal them. Turn on built-in HTTPS: node scripts/setup-server.js.');
  else (config.isProd ? fail : warn)('APP_URL is not https://.');

  if (process.env.SECRET_KEY) ok('SECRET_KEY is set (2FA secrets are encrypted).');
  else (config.isProd ? fail : warn)('SECRET_KEY is not set.');

  if (config.security.requireAdmin2fa) ok('Two-factor sign-in is required for admins.');
  else fail('REQUIRE_ADMIN_2FA is off: admins can sign in with only a password.');

  if (config.mail.enabled) ok('Email is set up (verification, password reset and security alerts work).');
  else warn('Email is not set up: no email verification, no password reset and NO security alerts. Set SMTP_* in .env.');

  if (config.security.breachedPasswordCheck) ok('Passwords from known data breaches are rejected.');
  else warn('Breached-password check is off (BREACHED_PASSWORD_CHECK).');

  if (config.ownerEmails.length) ok(`Owners: ${config.ownerEmails.join(', ')}`);
  else warn('ADMIN_EMAILS is empty: nobody is an owner, so nobody receives security alerts.');

  if (config.direct && config.trustProxy > 0) {
    warn(`TRUST_PROXY is ${config.trustProxy} but visitors connect directly. Set TRUST_PROXY=0 or people can fake their IP address and dodge rate limits and lockouts.`);
  }
  if (config.isProd && !config.direct && config.host !== '127.0.0.1' && config.host !== '::1' && !process.env.DOCKER) {
    warn(`The app listens on ${config.host}. Unless a firewall blocks port ${config.port}, people can bypass the HTTPS proxy and fake their IP address.`);
  }

  if (envFile && fs.existsSync(envFile)) {
    const m = mode(envFile);
    if (m !== null && (m & 0o077)) warn(`${envFile} can be read by other users on this machine (chmod 600 it).`);
    else ok('.env file permissions are private.');
  }
  const dm = mode(config.dataDir);
  if (dm !== null && (dm & 0o077)) warn(`${config.dataDir} can be read by other users on this machine (chmod 700 it).`);

  return out;
}

module.exports = { checkInstallation };
