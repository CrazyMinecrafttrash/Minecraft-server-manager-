'use strict';
// Every API endpoint. Route options:
//   access: 'public' (default) | 'user' | 'admin'     — enforced by the dispatcher in app.js
//   limit:  'auth' | 'status'                          — extra rate-limit bucket

const fs = require('node:fs');
const path = require('node:path');
const { HttpError } = require('./http');
const {
  normalizeEmail, checkPassword, hashPassword, verifyPassword, burnPasswordTime, randomToken, sha256, safeEqual,
} = require('./security');
const { normalizeSite } = require('./validate');
const crypto = require('node:crypto');
const totp = require('./totp');
const { isBreachedPassword } = require('./pwned');

const HOST_RE = /^(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/;

function registerRoutes({ router, config, store, auth, oauth, mailer }) {
  const add = (method, pattern, options, handler) => router.add(method, pattern, options, handler);

  // Failed logins for emails that have no account are tracked in memory with the same lockout
  // rules as real accounts, so the response never reveals whether an account exists.
  const ghostFailures = new Map();
  const { maxFailures, durationMs } = config.lockout;

  function isLocked(email, user) {
    if (user) return user.lockedUntil > Date.now();
    const g = ghostFailures.get(email);
    return Boolean(g && g.until > Date.now());
  }

  function recordFailure(email, user) {
    if (user) return store.recordFailure(user.id, maxFailures, durationMs);
    let g = ghostFailures.get(email);
    if (!g || (g.until && g.until <= Date.now())) g = { count: 0, until: 0 };
    g.count += 1;
    if (g.count >= maxFailures) { g.count = 0; g.until = Date.now() + durationMs; }
    if (ghostFailures.size > 10000) ghostFailures.clear();
    ghostFailures.set(email, g);
    return { locked: g.until > Date.now() };
  }

  const tooMany = (res) => res.json(429, { error: 'Too many failed attempts. Please try again in a few minutes.' });

  // ── public ───────────────────────────────────────────────
  // (the public site endpoint lives below, next to the supporter helpers)

  // "Is the website itself up?" Safe to be public: it reveals nothing but that the app and its database answer.
  add('GET', '/healthz', {}, (_req, res) => {
    let db = false;
    try { db = store.ping(); } catch { db = false; }
    res.setHeader('Cache-Control', 'no-store');
    res.json(db ? 200 : 503, { ok: db, db, uptimeSec: Math.round(process.uptime()) });
  });

  add('GET', '/api/auth/providers', {}, (_req, res) => {
    res.json(200, {
      google: config.providers.google.enabled,
      discord: config.providers.discord.enabled,
      emailVerification: config.mail.enabled,
    });
  });

  add('GET', '/api/auth/me', {}, (req, res) => {
    if (!req.user) return res.json(200, { user: null });
    return res.json(200, { user: auth.publicUser(req.user), csrf: req.session.csrf });
  });

  // ── password accounts ────────────────────────────────────
  // ── security helpers ─────────────────────────────────────
  const sec = config.security;
  const safeEqualHex = (a, b) => typeof a === 'string' && typeof b === 'string' && a.length === b.length && safeEqual(a, b);

  async function assertNotBreached(password) {
    if (sec.breachedPasswordCheck && await isBreachedPassword(password, { api: sec.breachedPasswordApi })) {
      throw new HttpError(400, 'That password has appeared in a known data breach, so attackers try it first. Please choose a different one.');
    }
  }

  // Emails every owner (and optionally the affected person) about security-relevant events.
  function alertSecurity(subject, lines, alsoTo = []) {
    if (!mailer || !mailer.enabled) return;
    const to = new Set(store.listAdmins().filter((a) => a.isOwner).map((a) => a.email.toLowerCase()));
    for (const e of alsoTo) if (e) to.add(String(e).toLowerCase());
    const text = [...lines, '', `Time: ${new Date().toUTCString()}`, '',
      'If this was not expected, sign in, check Accounts and the activity log, and use "Sign out everywhere".', '— YuniDoc security'].join('\n');
    for (const addr of to) {
      Promise.resolve().then(() => mailer.send({ to: addr, subject: `[YuniDoc security] ${subject}`, text }))
        .catch((err) => console.error('security alert failed:', err.message));
    }
  }

  // Dangerous admin actions need a 2FA code entered in the last few minutes ("step-up"), so a
  // stolen or left-open session cannot quietly add admins, delete accounts or swap download links.
  function requireRecentMfa(req) {
    if (!sec.requireAdmin2fa && !req.user.totpEnabled) return;
    if (Date.now() - (req.session.mfaAt || 0) > sec.stepUpMs) {
      throw new HttpError(403, 'Please confirm this change with a code from your authenticator app.', undefined, 'reauth');
    }
  }

  // ── emailed links (verify + set password; also serves as password reset) ──
  function sendEmailLink(email, ip) {
    const last = store.lastEmailTokenAt(email);
    if (Date.now() - last < config.mail.cooldownMs) return; // quietly ignore rapid repeats
    const token = randomToken(32);
    store.saveEmailToken(email, sha256(token), Date.now() + config.mail.tokenTtlMs);
    const link = `${config.origin}/admin/verify.html?token=${token}`;
    const minutes = Math.round(config.mail.tokenTtlMs / 60000);
    const existing = store.getUserByEmail(email);
    store.addAudit(email, existing ? 'password.reset.request' : 'signup.request', null, ip);
    // Not awaited: the response must not depend on (or reveal) what happens to the email.
    Promise.resolve().then(() => mailer.send({
      to: email,
      subject: 'Confirm your email for YuniDoc',
      text: [
        'Hi,',
        '',
        existing
          ? 'We received a request to set a new password for your YuniDoc account.'
          : 'Thanks for signing up to YuniDoc. Confirm your email address and choose a password here:',
        existing ? 'Choose a new password here:' : '',
        '',
        link,
        '',
        `This link works once and expires in ${minutes} minutes.`,
        'If you did not ask for this, you can ignore this email; nothing will change.',
        '',
        '— YuniDoc',
      ].filter((l, i, a) => !(l === '' && a[i - 1] === '' )).join('\n'),
    })).catch((err) => console.error('email send failed:', err.message));
  }

  add('POST', '/api/auth/verify', { limit: 'auth' }, async (req, res) => {
    const token = typeof req.body.token === 'string' ? req.body.token : '';
    const password = req.body.password;
    const bad = () => new HttpError(400, 'This link is invalid or has expired. Request a new one.');
    if (!config.mail.enabled || token.length < 20 || token.length > 100) throw bad();

    const hash = sha256(token);
    const pending = store.peekEmailToken(hash);
    if (!pending) throw bad();
    const problems = checkPassword(password, pending.email);
    if (problems.length) throw new HttpError(400, problems.join(' ')); // the link stays valid so they can retry
    await assertNotBreached(password);
    const passwordHash = await hashPassword(password);

    const taken = store.takeEmailToken(hash); // single use
    if (!taken) throw bad();

    let user = store.getUserByEmail(taken.email);
    if (user) {
      store.setPassword(user.id, passwordHash);
      store.markVerified(user.id);
      store.deleteUserSessions(user.id); // a password change signs out every other device
      store.addAudit(taken.email, 'password.reset', null, req.ip);
      if (store.isAdminEmail(taken.email)) alertSecurity('Admin password changed', [`The password for admin ${taken.email} was changed using an emailed link.`, `IP address: ${req.ip}`], [taken.email]);
    } else {
      user = store.createUser({ email: taken.email, passwordHash, verified: true });
      store.addAudit(taken.email, 'signup', 'email verified', req.ip);
    }
    ghostFailures.delete(taken.email);
    store.recordLogin(user.id);
    const { csrf, user: sessionUser } = auth.startSession(req, res, store.getUserById(user.id));
    res.json(200, { user: auth.publicUser(sessionUser), csrf });
  });

  add('POST', '/api/auth/signup', { limit: 'auth' }, async (req, res) => {
    const email = normalizeEmail(req.body.email);
    if (!email) throw new HttpError(400, 'Enter a valid email address.');

    // With email enabled, signing up only proves you own the address: we mail a one-time link and the
    // password is chosen AFTER clicking it. Nobody can register (or pre-register) someone else's address,
    // and the answer is identical whether or not an account already exists.
    if (config.mail.enabled) {
      sendEmailLink(email, req.ip);
      return res.json(202, { ok: true, needsVerification: true });
    }

    const password = req.body.password;
    const problems = checkPassword(password, email);
    if (problems.length) throw new HttpError(400, problems.join(' '));
    await assertNotBreached(password);
    if (store.getUserByEmail(email)) throw new HttpError(409, 'An account with that email already exists. Try signing in instead.');

    let user;
    try {
      user = store.createUser({ email, passwordHash: await hashPassword(password), verified: false });
    } catch {
      throw new HttpError(409, 'An account with that email already exists. Try signing in instead.');
    }
    // Password sign-ups are never trusted as the owner of the email address, so they can never be admins
    // (admins must sign in with Google/Discord, or be created by the owner from the command line).
    const { csrf, user: sessionUser } = auth.startSession(req, res, user);
    store.addAudit(email, 'signup', null, req.ip);
    res.json(201, { user: auth.publicUser(sessionUser), csrf });
  });

  add('POST', '/api/auth/login', { limit: 'auth' }, async (req, res) => {
    const email = normalizeEmail(req.body.email);
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    const wrong = () => res.json(401, { error: 'Incorrect email or password.' });

    if (!email || !password || password.length > 128) {
      if (password) await burnPasswordTime(password.slice(0, 128));
      return wrong();
    }
    const user = store.getUserByEmail(email);
    if (isLocked(email, user)) return tooMany(res);

    if (!user || !user.passwordHash) {
      await burnPasswordTime(password);
      recordFailure(email, null);
      return wrong();
    }
    if (!(await verifyPassword(password, user.passwordHash))) {
      const { locked } = recordFailure(email, user);
      if (locked) {
        store.addAudit(email, 'login.locked', 'too many failed attempts', req.ip);
        if (store.isAdminEmail(email)) alertSecurity('Admin account locked', [`Too many wrong passwords for admin ${email}. Sign-in is blocked for 15 minutes.`, `Last attempt from IP: ${req.ip}`], [email]);
      }
      return wrong();
    }

    if (config.mail.enabled && !user.emailVerified) {
      // Correct password but the address was never confirmed (account predates email verification).
      return res.json(403, {
        error: 'Please confirm your email first. Use "Forgot password?" to get a link.',
        code: 'email_unverified',
      });
    }

    store.recordLogin(user.id);
    const { csrf, user: sessionUser } = auth.startSession(req, res, user);
    if (sessionUser.isListedAdmin) store.addAudit(email, 'login.password', sessionUser.mfaPending ? 'waiting for 2FA' : null, req.ip);
    return res.json(200, { user: auth.publicUser(sessionUser), csrf });
  });


  // ── two-factor authentication ──────────────────────────
  const key = sec.secretKey;
  const mfaLocked = (u) => u.totpLockedUntil > Date.now();
  const lockedError = (u) => new HttpError(429, `Too many wrong codes. Try again in ${Math.max(1, Math.ceil((u.totpLockedUntil - Date.now()) / 60000))} minutes.`);

  function failMfa(req, user) {
    const { locked } = store.recordTotpFailure(user.id, sec.mfaMaxFailures, sec.mfaLockMs);
    if (locked) {
      store.addAudit(user.email, '2fa.locked', 'too many wrong codes', req.ip);
      alertSecurity('2FA locked after wrong codes', [`Someone entered ${sec.mfaMaxFailures} wrong two-factor codes for ${user.email}.`,
        'That means they knew the password (or had a signed-in session). Change the password if this was not you.', `IP address: ${req.ip}`], [user.email]);
    }
    return new HttpError(401, locked ? 'Too many wrong codes. Two-factor sign-in is locked for 15 minutes.' : 'That code is not right. Check your app and try again.');
  }

  function newRecoveryCodes(userId) {
    const codes = totp.generateRecoveryCodes(10);
    store.replaceRecoveryCodes(userId, codes.map(totp.hashRecoveryCode));
    return codes;
  }

  // Step 1: create a secret (not active until a code from it is confirmed).
  add('POST', '/api/auth/2fa/setup', { access: 'user', limit: 'auth' }, (req, res) => {
    const user = store.getUserById(req.user.id);
    if (!req.user.isListedAdmin) throw new HttpError(403, 'Two-factor sign-in is for admin accounts.');
    if (user.totpEnabled) throw new HttpError(409, 'Two-factor sign-in is already on.');
    const secret = totp.generateSecret();
    store.setTotpPending(user.id, totp.encrypt(key, secret));

    // When email works, also prove control of the inbox right now, so a stolen password alone
    // is not enough for an attacker to enrol their own authenticator on an admin account.
    let emailCodeSent = false;
    if (mailer && mailer.enabled) {
      const fresh = user.mfaEmailExp - sec.mfaEmailCodeMs + 60 * 1000 > Date.now(); // sent < 1 minute ago
      if (!fresh) {
        const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
        store.setMfaEmailCode(user.id, sha256('mfa-email:' + code), Date.now() + sec.mfaEmailCodeMs);
        Promise.resolve().then(() => mailer.send({
          to: user.email,
          subject: 'Your YuniDoc security code',
          text: [`Your code to turn on two-factor sign-in is: ${code}`, '', 'It expires in 15 minutes.',
            'If you did not ask for this, someone may know your password: change it and tell the site owner.', '', '— YuniDoc'].join('\n'),
        })).catch((err) => console.error('email send failed:', err.message));
      }
      emailCodeSent = true;
    }
    res.json(200, {
      secret,
      uri: totp.otpauthUri({ issuer: 'YuniDoc', account: user.email, secret }),
      emailCodeSent,
    });
  });

  // Step 2: confirm with a code from the app → 2FA is on, recovery codes are shown once.
  add('POST', '/api/auth/2fa/enable', { access: 'user', limit: 'auth' }, (req, res) => {
    const user = store.getUserById(req.user.id);
    if (!req.user.isListedAdmin) throw new HttpError(403, 'Two-factor sign-in is for admin accounts.');
    if (user.totpEnabled) throw new HttpError(409, 'Two-factor sign-in is already on.');
    if (!user.totpSecret) throw new HttpError(400, 'Start the setup again.');
    if (mfaLocked(user)) throw lockedError(user);

    if (mailer && mailer.enabled) {
      const emailCode = String(req.body.emailCode || '').trim();
      if (!user.mfaEmailCode || user.mfaEmailExp < Date.now()) throw new HttpError(400, 'The emailed code expired. Start the setup again.');
      if (!/^\d{6}$/.test(emailCode) || !safeEqualHex(sha256('mfa-email:' + emailCode), user.mfaEmailCode)) throw failMfa(req, user);
    }
    const step = totp.verifyTotp(totp.decrypt(key, user.totpSecret), String(req.body.code || '').trim(), 0);
    if (step === null) throw failMfa(req, user);

    store.enableTotp(user.id, step);
    const codes = newRecoveryCodes(user.id);
    const session = auth.startSession(req, res, store.getUserById(user.id), { mfaAt: Date.now() });
    store.deleteOtherSessions(user.id, req.session.idHash); // anyone else signed in as this person is thrown out
    store.addAudit(user.email, '2fa.enabled', null, req.ip);
    store.addAudit(user.email, 'login.2fa', 'first setup', req.ip);
    alertSecurity('Two-factor sign-in turned on', [`Admin ${user.email} turned on two-factor sign-in.`, `IP address: ${req.ip}`], [user.email]);
    res.json(200, { user: auth.publicUser(session.user), csrf: session.csrf, recoveryCodes: codes });
  });

  // Enter a code: after signing in, or to confirm a dangerous action ("step-up").
  add('POST', '/api/auth/2fa/verify', { access: 'user', limit: 'auth' }, (req, res) => {
    const user = store.getUserById(req.user.id);
    if (!user.totpEnabled) throw new HttpError(400, 'Two-factor sign-in is not set up for this account.');
    if (mfaLocked(user)) throw lockedError(user);
    const input = String(req.body.code || '').trim();
    if (input.length > 40) throw failMfa(req, user);

    let usedRecovery = false;
    if (/^\d{6}$/.test(input.replace(/\s/g, ''))) {
      const step = totp.verifyTotp(totp.decrypt(key, user.totpSecret), input.replace(/\s/g, ''), user.totpLastStep);
      if (step === null) throw failMfa(req, user);
      store.totpSuccess(user.id, step);
    } else {
      if (!store.useRecoveryCode(user.id, totp.hashRecoveryCode(input))) throw failMfa(req, user);
      store.totpSuccess(user.id, 0);
      usedRecovery = true;
    }

    const wasPending = req.user.mfaPending;
    const session = auth.startSession(req, res, user, { mfaAt: Date.now() });
    const left = store.countRecoveryCodes(user.id);
    if (wasPending) {
      if (session.user.isListedAdmin && !store.hasAuditFrom(user.email, 'login.2fa', req.ip)) {
        alertSecurity('Admin signed in from a new IP address', [`Admin ${user.email} signed in from an IP address not seen before: ${req.ip}`,
          `Browser: ${String(req.headers['user-agent'] || 'unknown').slice(0, 160)}`], [user.email]);
      }
      store.addAudit(user.email, 'login.2fa', usedRecovery ? 'recovery code' : null, req.ip);
    }
    if (usedRecovery) {
      store.addAudit(user.email, '2fa.recovery_used', `${left} left`, req.ip);
      alertSecurity('Recovery code used', [`A recovery code was used to sign in as ${user.email}. ${left} codes are left.`, `IP address: ${req.ip}`], [user.email]);
    }
    res.json(200, { user: auth.publicUser(session.user), csrf: session.csrf, recoveryCodesLeft: left, usedRecovery });
  });

  add('POST', '/api/auth/2fa/recovery-codes', { access: 'admin', limit: 'auth' }, (req, res) => {
    requireRecentMfa(req);
    const codes = newRecoveryCodes(req.user.id);
    store.addAudit(req.user.email, '2fa.recovery_regenerated', null, req.ip);
    res.json(200, { recoveryCodes: codes });
  });

  add('GET', '/api/auth/security', { access: 'user' }, (req, res) => {
    res.json(200, {
      totpEnabled: req.user.totpEnabled,
      recoveryCodesLeft: req.user.totpEnabled ? store.countRecoveryCodes(req.user.id) : 0,
      activeSessions: store.countUserSessions(req.user.id),
      stepUpValidForMs: Math.max(0, sec.stepUpMs - (Date.now() - (req.session.mfaAt || 0))),
    });
  });

  // Signs this account out on every device (use it if you think someone else got in).
  add('POST', '/api/auth/logout-all', { access: 'user' }, (req, res) => {
    store.deleteUserSessions(req.user.id);
    store.addAudit(req.user.email, 'logout.all', null, req.ip);
    auth.endSession(req, res);
    res.json(200, { ok: true });
  });

  add('POST', '/api/auth/logout', {}, (req, res) => {
    auth.endSession(req, res);
    res.json(200, { ok: true });
  });

  add('GET', '/auth/:provider/start', { limit: 'auth' }, (req, res) => oauth.start(req, res));
  add('GET', '/auth/:provider/callback', { limit: 'auth' }, (req, res) => oauth.callback(req, res));

  // ── admin: site settings ─────────────────────────────────
  const siteResponse = (row) => ({
    site: row.data,
    meta: { version: row.version, updatedAt: row.updatedAt, updatedBy: row.updatedBy },
  });

  add('GET', '/api/admin/site', { access: 'admin' }, (_req, res) => res.json(200, siteResponse(store.getSite())));

  add('PUT', '/api/admin/site', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const baseVersion = Number(req.body.baseVersion);
    if (!Number.isInteger(baseVersion)) throw new HttpError(400, 'Missing version. Reload the page and try again.');
    const { value, errors } = normalizeSite(req.body.site);
    if (errors.length) throw new HttpError(400, 'Some settings need fixing.', errors);

    const result = store.saveSite(value, baseVersion, req.user.email);
    if (result.conflict) {
      return res.json(409, { error: 'Someone else saved changes first. Reload to see their version.', ...siteResponse(result.current) });
    }
    store.addAudit(req.user.email, 'site.save', `${value.servers.length} servers, ${value.modpacks.length} packs`, req.ip);
    return res.json(200, siteResponse(result.current));
  });

  // ── admin: who is an admin ───────────────────────────────
  add('GET', '/api/admin/admins', { access: 'admin' }, (_req, res) => res.json(200, { admins: store.listAdmins() }));

  add('POST', '/api/admin/admins', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const email = normalizeEmail(req.body.email);
    if (!email) throw new HttpError(400, 'Enter a valid email address.');
    if (store.isAdminEmail(email)) throw new HttpError(409, 'That email is already an admin.');
    store.addAdmin(email, req.user.email);
    store.addAudit(req.user.email, 'admin.add', email, req.ip);
    alertSecurity('New admin added', [`${req.user.email} gave admin access to ${email}.`, `IP address: ${req.ip}`], [email]);
    res.json(201, { admins: store.listAdmins() });
  });

  add('DELETE', '/api/admin/admins/:email', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const email = normalizeEmail(req.params.email);
    if (!email) throw new HttpError(400, 'Invalid email address.');
    if (email === req.user.email) throw new HttpError(400, 'You cannot remove your own admin access.');
    if (store.isOwnerEmail(email)) throw new HttpError(400, 'Owners are set in the server configuration (ADMIN_EMAILS) and cannot be removed here.');
    if (store.removeAdmin(email).changes === 0) throw new HttpError(404, 'That email is not an admin.');
    store.addAudit(req.user.email, 'admin.remove', email, req.ip);
    alertSecurity('Admin removed', [`${req.user.email} removed admin access from ${email}.`, `IP address: ${req.ip}`]);
    res.json(200, { admins: store.listAdmins() });
  });


  // ── bug reports (anyone signed in can report; admins triage) ──
  const BUG_CATEGORIES = ['website', 'server', 'modpack', 'account', 'other'];
  const BUG_STATUSES = ['open', 'in_progress', 'resolved', 'wont_fix'];
  const BUG_PRIORITIES = ['low', 'normal', 'high', 'critical'];
  const MAX_BUG_REPORTS = 5000;
  const MAX_NOTES = 500;

  // Plain text only: strip control characters, normalise line breaks, enforce a length range.
  function cleanText(value, label, { min = 0, max }) {
    if (value === undefined || value === null) value = '';
    if (typeof value !== 'string') throw new HttpError(400, `${label} must be text.`);
    const text = value.replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim();
    if (text.length < min) throw new HttpError(400, `${label} is too short (at least ${min} characters).`);
    if (text.length > max) throw new HttpError(400, `${label} is too long (at most ${max} characters).`);
    return text;
  }
  function idParam(req) {
    if (!/^\d{1,9}$/.test(String(req.params.id))) throw new HttpError(404, 'Not found.');
    return Number(req.params.id);
  }
  function oneOf(value, allowed, label) {
    if (!allowed.includes(value)) throw new HttpError(400, `${label} must be one of: ${allowed.join(', ')}.`);
    return value;
  }
  const bugForAdmin = (b) => b;
  const bugForReporter = (b) => ({
    id: b.id, title: b.title, category: b.category, serverName: b.serverName, status: b.status, createdAt: b.createdAt,
  });

  // ── supporters (patrons) and early access ────────────────
  const todayUTC = () => new Date().toISOString().slice(0, 10);

  // The person's active supporter record, or null. Needs a verified email: access is granted by email
  // address, so an unverified password account must not be able to claim someone else's perks.
  function patronOf(user) {
    if (!user || !user.emailVerified) return null;
    const p = store.getPatron(user.email);
    return p && p.active ? p : null;
  }

  function tierOf(site, patron) {
    return patron ? (site.support.tiers.find((t) => t.id === patron.tier) || null) : null;
  }

  // Early access = admin, or an active patron whose tier includes it.
  function hasEarlyAccess(site, user) {
    if (user && user.isAdmin) return true;
    const t = tierOf(site, patronOf(user));
    return Boolean(t && t.earlyAccess);
  }

  const isOpenToAll = (s) => s.access !== 'patrons' || Boolean(s.publicOn && s.publicOn <= todayUTC());

  add('GET', '/api/site', {}, (req, res) => {
    const { data } = store.getSite();
    const early = hasEarlyAccess(data, req.user);
    const visible = data.servers.filter((s) => !s.hidden);

    // An early-access server's address, port and downloads are only sent to people entitled to them.
    const servers = visible.map((s) => {
      const open = isOpenToAll(s);
      if (open || early) {
        return { icon: s.icon, name: s.name, ip: s.ip, port: s.port, description: s.description, early: !open, publicOn: open ? '' : s.publicOn };
      }
      return { icon: s.icon, name: s.name, ip: '', port: '', description: s.description, early: true, locked: true, publicOn: s.publicOn };
    });
    const lockedNames = new Set(servers.filter((s) => s.locked).map((s) => s.name.toLowerCase()));
    const names = new Set(visible.map((s) => s.name.toLowerCase()));

    const sp = data.support;
    // Never publish a tier's payment link or wall details unless the page is switched on.
    const support = sp.enabled ? sp : { enabled: false };
    // Cache-Control is private: this answer differs per person.
    res.setHeader('Cache-Control', 'private, no-cache');
    res.setHeader('Vary', 'Cookie');
    res.json(200, {
      servers,
      modpacks: data.modpacks.filter((p) => !p.serverName || (names.has(p.serverName.toLowerCase()) && !lockedNames.has(p.serverName.toLowerCase()))),
      fallback: data.fallback,
      announcement: data.announcement.enabled && data.announcement.text ? data.announcement : { enabled: false, text: '', level: 'info' },
      about: data.about,
      support,
    });
  });

  add('GET', '/api/patrons/wall', {}, (_req, res) => {
    const { data } = store.getSite();
    const tiers = new Map(data.support.tiers.map((t) => [t.id, t.name]));
    const wall = data.support.enabled && data.support.showWall
      ? store.patronWall().map((w) => ({ name: w.name, tier: tiers.get(w.tier) || '' }))
      : [];
    res.setHeader('Cache-Control', 'public, max-age=60');
    res.json(200, { wall });
  });

  // ── a person's own profile (Minecraft name + supporter wall choice) ──
  const MC_NAME = /^[A-Za-z0-9_]{3,16}$/;
  function profileFor(req) {
    const u = store.getUserById(req.user.id);
    const { data } = store.getSite();
    const patron = patronOf(req.user);
    const tier = tierOf(data, patron);
    return {
      mcUsername: u.mcUsername || '',
      displayName: u.displayName || '',
      wallOptIn: u.wallOptIn,
      emailVerified: req.user.emailVerified,
      patron: patron ? { tier: patron.tier, tierName: tier ? tier.name : patron.tier, until: patron.until, earlyAccess: Boolean(tier && tier.earlyAccess) } : null,
    };
  }
  add('GET', '/api/me/profile', { access: 'user' }, (req, res) => res.json(200, profileFor(req)));
  add('PUT', '/api/me/profile', { access: 'user', limit: 'report' }, (req, res) => {
    const mc = cleanText(req.body.mcUsername, 'Minecraft username', { max: 16 });
    if (mc && !MC_NAME.test(mc)) throw new HttpError(400, 'Minecraft usernames are 3–16 letters, numbers or underscores.');
    const name = cleanText(req.body.displayName, 'Display name', { max: 24 });
    if (name && name.length < 2) throw new HttpError(400, 'Display name must be at least 2 characters.');
    if (name && /[<>]/.test(name)) throw new HttpError(400, 'Display name cannot contain < or >.');
    const wall = req.body.wallOptIn === true;
    if (wall && !name) throw new HttpError(400, 'Choose a display name to appear on the supporter wall.');
    store.setProfile(req.user.id, { mcUsername: mc, displayName: name, wallOptIn: wall });
    res.json(200, profileFor(req));
  });

  // ── admin: supporters ──
  const tierIds = () => new Set(store.getSite().data.support.tiers.map((t) => t.id));
  function parseUntil(value) {
    if (value === undefined) return undefined;
    if (value === null || value === '') return null;
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T23:59:59Z`))) {
      throw new HttpError(400, 'The end date must look like 2026-12-31 (or be empty for no end date).');
    }
    return Date.parse(`${value}T23:59:59Z`);
  }
  const patronForAdmin = (p) => ({
    email: p.email, tier: p.tier, since: p.since, until: p.until, active: p.active, note: p.note, hideWall: p.hideWall,
    grantedBy: p.grantedBy, signedUp: p.signedUp, emailVerified: p.emailVerified, mcUsername: p.mcUsername, displayName: p.displayName,
  });

  add('GET', '/api/admin/patrons', { access: 'admin' }, (_req, res) => {
    const list = store.listPatrons();
    const soon = Date.now() + 7 * 24 * 3600 * 1000;
    res.json(200, {
      patrons: list.map(patronForAdmin),
      summary: { active: list.filter((p) => p.active).length, expiringSoon: list.filter((p) => p.active && p.until && p.until < soon).length, total: list.length },
    });
  });

  add('POST', '/api/admin/patrons', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const raw = Array.isArray(req.body.emails) ? req.body.emails : [req.body.email];
    if (raw.length > 50) throw new HttpError(400, 'Add at most 50 supporters at a time.');
    const emails = [...new Set(raw.map((e) => normalizeEmail(e)).filter(Boolean))];
    if (!emails.length) throw new HttpError(400, 'Enter at least one valid email address.');
    if (!tierIds().has(req.body.tier)) throw new HttpError(400, 'Choose one of your tiers (set them up in the Support tab first).');
    const until = parseUntil(req.body.until);
    const note = cleanText(req.body.note, 'The note', { max: 200 });
    for (const email of emails) {
      store.upsertPatron({ email, tier: req.body.tier, until, note, by: req.user.email });
      store.addAudit(req.user.email, 'patron.grant', `${email} → ${req.body.tier}`, req.ip);
    }
    res.json(201, { added: emails.length });
  });

  add('PUT', '/api/admin/patrons/:email', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const email = normalizeEmail(req.params.email);
    const patch = {};
    if (req.body.tier !== undefined) { if (!tierIds().has(req.body.tier)) throw new HttpError(400, 'Unknown tier.'); patch.tier = req.body.tier; }
    if (req.body.until !== undefined) patch.until = parseUntil(req.body.until);
    if (req.body.note !== undefined) patch.note = cleanText(req.body.note, 'The note', { max: 200 });
    if (req.body.hideWall !== undefined) patch.hideWall = req.body.hideWall === true;
    const updated = email && store.patchPatron(email, patch, req.user.email);
    if (!updated) throw new HttpError(404, 'That supporter does not exist.');
    store.addAudit(req.user.email, 'patron.update', email, req.ip);
    res.json(200, { patron: patronForAdmin(updated) });
  });

  add('DELETE', '/api/admin/patrons/:email', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const email = normalizeEmail(req.params.email);
    if (!email || !store.removePatron(email)) throw new HttpError(404, 'That supporter does not exist.');
    store.addAudit(req.user.email, 'patron.remove', email, req.ip);
    res.json(200, { ok: true });
  });

  // CSV for the game server: who has which cosmetics. Contains personal data, so it needs a fresh 2FA code
  // and is written to the activity log.
  const csvCell = (v) => {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // stops spreadsheet formula injection
    return `"${s.replace(/"/g, '""')}"`;
  };
  add('GET', '/api/admin/patrons/export', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const { data } = store.getSite();
    const rank = new Map(data.support.tiers.map((t, i) => [t.id, i]));
    const rows = store.listPatrons().map((p) => {
      const cosmetics = data.support.cosmetics
        .filter((c) => !c.tier || (rank.has(p.tier) && rank.get(p.tier) >= rank.get(c.tier)))
        .map((c) => c.name).join('; ');
      return [p.email, p.displayName, p.mcUsername, p.tier, new Date(p.since).toISOString().slice(0, 10),
        p.until ? new Date(p.until).toISOString().slice(0, 10) : '', p.active ? 'yes' : 'no', cosmetics];
    });
    const header = ['email', 'display_name', 'minecraft_username', 'tier', 'since', 'until', 'active', 'cosmetics'];
    const csv = [header, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
    store.addAudit(req.user.email, 'patron.export', `${rows.length} rows`, req.ip);
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="yunidoc-supporters.csv"',
      'Cache-Control': 'no-store',
    });
    res.end(csv);
  });

  // ── server problem reports: a community "is it down?" tracker ──
  // Not an automatic ping: it counts how many different people said a server has a problem recently.
  const OUTAGE_KINDS = ['down', 'laggy'];
  const OUTAGE_WINDOW_MS = 30 * 60 * 1000;   // reports this recent decide the current state
  const OUTAGE_REPEAT_MS = 15 * 60 * 1000;   // one person can report a server once per 15 minutes
  const OUTAGE_KEEP_MS = 8 * 24 * 3600 * 1000;
  const HOUR_MS = 3600 * 1000;
  function outageState(down, laggy) {
    if (down >= 4) return 'down';
    if (down + laggy >= 2) return 'issues';
    return 'ok';
  }
  // Servers this visitor is allowed to know about (hidden and still-locked servers are not).
  function knownServers(req) {
    const { data } = store.getSite();
    const early = hasEarlyAccess(data, req.user);
    return data.servers.filter((s) => !s.hidden && (early || isOpenToAll(s)));
  }

  add('POST', '/api/servers/report', { limit: 'report' }, (req, res) => {
    const kind = oneOf(req.body.kind, OUTAGE_KINDS, 'The problem type');
    const name = typeof req.body.server === 'string' ? req.body.server.trim().toLowerCase() : '';
    const server = knownServers(req).find((s) => s.name.toLowerCase() === name);
    if (!server) throw new HttpError(404, 'That server was not found.');
    const reporter = sha256(req.user ? `user:${req.user.id}` : `ip:${req.ip}`);
    const now = Date.now();
    if (store.hasRecentOutage(server.name, reporter, now - OUTAGE_REPEAT_MS)) {
      return res.json(200, { ok: true, already: true });
    }
    store.addOutage({ server: server.name, kind, reporter });
    store.purgeOutages(now - OUTAGE_KEEP_MS);
    return res.json(201, { ok: true, already: false });
  });

  add('GET', '/api/servers/health', {}, (req, res) => {
    const now = Date.now();
    const counts = store.outageCounts(now - OUTAGE_WINDOW_MS);
    const firstHour = Math.floor(now / HOUR_MS) - 23;
    const hours = store.outageHours((firstHour) * HOUR_MS);
    const servers = knownServers(req).map((s) => {
      const key = s.name.toLowerCase();
      const n = (kind) => (counts.find((c) => c.name.toLowerCase() === key && c.kind === kind) || { n: 0 }).n;
      const down = n('down');
      const laggy = n('laggy');
      const bars = Array.from({ length: 24 }, (_, i) => 0);
      let total = 0;
      for (const h of hours) if (h.name.toLowerCase() === key && h.hour >= firstHour) { bars[h.hour - firstHour] = h.n; total += h.n; }
      return { icon: s.icon, name: s.name, state: outageState(down, laggy), down, laggy, hours: bars, reports24h: total };
    });
    res.setHeader('Cache-Control', 'private, no-cache');
    res.setHeader('Vary', 'Cookie');
    res.json(200, { servers, windowMinutes: OUTAGE_WINDOW_MS / 60000, now });
  });

  add('GET', '/api/admin/outages', { access: 'admin' }, (_req, res) => {
    const now = Date.now();
    const day = store.outageCounts(now - 24 * HOUR_MS);
    res.json(200, {
      last24h: day,
      recent: store.recentOutages(50),
    });
  });

  add('POST', '/api/bugs', { access: 'user', limit: 'report' }, (req, res) => {
    const title = cleanText(req.body.title, 'The title', { min: 4, max: 120 });
    const description = cleanText(req.body.description, 'The description', { min: 10, max: 4000 });
    const category = oneOf(req.body.category || 'other', BUG_CATEGORIES, 'Category');
    const serverName = cleanText(req.body.serverName, 'The server name', { max: 60 });
    if (store.countBugsByUserSince(req.user.id, Date.now() - 60 * 60 * 1000) >= 5) {
      throw new HttpError(429, 'You have sent several reports in the last hour. Please wait a little before sending another.');
    }
    if (store.countBugs() >= MAX_BUG_REPORTS) throw new HttpError(503, 'Bug reports are temporarily closed. Please tell us on Discord.');
    const bug = store.createBug({ userId: req.user.id, reporter: req.user.email, title, description, category, serverName });
    res.json(201, { ok: true, id: bug.id });
  });

  add('GET', '/api/bugs/mine', { access: 'user' }, (req, res) => {
    res.json(200, { bugs: store.listBugsByUser(req.user.id).map(bugForReporter) }); // never includes admin notes
  });

  add('GET', '/api/admin/bugs', { access: 'admin' }, (_req, res) => {
    res.json(200, { bugs: store.listBugs().map(bugForAdmin) });
  });

  add('PUT', '/api/admin/bugs/:id', { access: 'admin' }, (req, res) => {
    const id = idParam(req);
    const patch = {};
    if (req.body.status !== undefined) patch.status = oneOf(req.body.status, BUG_STATUSES, 'Status');
    if (req.body.priority !== undefined) patch.priority = oneOf(req.body.priority, BUG_PRIORITIES, 'Priority');
    if (req.body.adminNote !== undefined) patch.adminNote = cleanText(req.body.adminNote, 'The note', { max: 2000 });
    const before = store.getBug(id);
    const bug = store.updateBug(id, patch, req.user.email);
    if (!bug) throw new HttpError(404, 'That report no longer exists.');
    if (patch.status && patch.status !== before.status) store.addAudit(req.user.email, 'bug.status', `#${id} → ${patch.status}`, req.ip);
    res.json(200, { bug: bugForAdmin(bug) });
  });

  add('DELETE', '/api/admin/bugs/:id', { access: 'admin' }, (req, res) => {
    const id = idParam(req);
    if (!store.deleteBug(id)) throw new HttpError(404, 'That report no longer exists.');
    store.addAudit(req.user.email, 'bug.delete', `#${id}`, req.ip);
    res.json(200, { ok: true });
  });

  // ── admin notes (shared between all admins) ──
  add('GET', '/api/admin/notes', { access: 'admin' }, (_req, res) => res.json(200, { notes: store.listNotes() }));

  add('POST', '/api/admin/notes', { access: 'admin' }, (req, res) => {
    const body = cleanText(req.body.body, 'The note', { min: 1, max: 4000 });
    if (store.countNotes() >= MAX_NOTES) throw new HttpError(400, 'There are too many notes. Delete some old ones first.');
    const note = store.createNote({ body, pinned: req.body.pinned === true, author: req.user.email });
    res.json(201, { note });
  });

  add('PUT', '/api/admin/notes/:id', { access: 'admin' }, (req, res) => {
    const id = idParam(req);
    const patch = {};
    if (req.body.body !== undefined) patch.body = cleanText(req.body.body, 'The note', { min: 1, max: 4000 });
    if (req.body.pinned !== undefined) {
      if (typeof req.body.pinned !== 'boolean') throw new HttpError(400, 'pinned must be true or false.');
      patch.pinned = req.body.pinned;
    }
    const note = store.updateNote(id, patch, req.user.email);
    if (!note) throw new HttpError(404, 'That note no longer exists.');
    res.json(200, { note });
  });

  add('DELETE', '/api/admin/notes/:id', { access: 'admin' }, (req, res) => {
    const id = idParam(req);
    if (!store.deleteNote(id)) throw new HttpError(404, 'That note no longer exists.');
    store.addAudit(req.user.email, 'note.delete', `#${id}`, req.ip);
    res.json(200, { ok: true });
  });

  // ── admin: accounts ──────────────────────────────────────
  add('GET', '/api/admin/users', { access: 'admin' }, (_req, res) => {
    const admins = new Set(store.listAdmins().map((a) => a.email.toLowerCase()));
    const owners = new Set(store.listAdmins().filter((a) => a.isOwner).map((a) => a.email.toLowerCase()));
    res.json(200, {
      users: store.listUsers().map((u) => ({
        id: u.id,
        email: u.email,
        providers: u.providers,
        hasPassword: Boolean(u.passwordHash),
        emailVerified: u.emailVerified,
        isAdminListed: admins.has(u.email.toLowerCase()),
        isAdmin: u.emailVerified && admins.has(u.email.toLowerCase()),
        isOwner: owners.has(u.email.toLowerCase()),
        createdAt: u.createdAt,
        lastLoginAt: u.lastLoginAt,
        totpEnabled: u.totpEnabled,
      })),
    });
  });

  add('DELETE', '/api/admin/users/:id', { access: 'admin' }, (req, res) => {
    requireRecentMfa(req);
    const id = Number(req.params.id);
    const target = Number.isInteger(id) ? store.getUserById(id) : null;
    if (!target) throw new HttpError(404, 'Account not found.');
    if (target.id === req.user.id) throw new HttpError(400, 'You cannot delete your own account.');
    if (store.isOwnerEmail(target.email)) throw new HttpError(400, 'Owner accounts cannot be deleted here.');
    store.deleteUser(target.id);
    store.addAudit(req.user.email, 'user.delete', target.email, req.ip);
    res.json(200, { ok: true });
  });

  add('GET', '/api/admin/audit', { access: 'admin' }, (req, res) => {
    res.json(200, { entries: store.listAudit(Number(req.query.limit) || 30) });
  });

  // ── admin: server status (asks a public Minecraft status API) ──
  const statusCache = new Map();
  add('GET', '/api/admin/status', { access: 'admin', limit: 'status' }, async (req, res) => {
    const host = String(req.query.host || '');
    const port = String(req.query.port || '');
    if (!HOST_RE.test(host) || host.length > 253 || (port && (!/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535))) {
      throw new HttpError(400, 'Invalid host or port.');
    }
    const key = `${host}:${port}`;
    const cached = statusCache.get(key);
    if (cached && cached.until > Date.now()) return res.json(200, cached.value);

    let value;
    try {
      const response = await fetch(`${config.statusApi}${encodeURIComponent(host)}${port ? `:${port}` : ''}`, {
        headers: { 'User-Agent': `YuniDoc-admin (${config.appUrl})`, Accept: 'application/json' },
        signal: AbortSignal.timeout(8000),
        redirect: 'error',
      });
      const data = await response.json();
      value = data.online
        ? { online: true, players: data.players ? { online: data.players.online, max: data.players.max } : null, version: String(data.version || '').slice(0, 40) }
        : { online: false };
    } catch {
      value = { error: 'Status service unavailable.' };
    }
    if (statusCache.size > 500) statusCache.clear();
    statusCache.set(key, { until: Date.now() + 30000, value });
    return res.json(200, value);
  });

  // ── admin: are the files the site points to actually there? ──
  add('GET', '/api/admin/health', { access: 'admin' }, (_req, res) => {
    const { data } = store.getSite();
    const problems = [];
    for (const pack of data.modpacks) {
      const m = /^\/?downloads\/([^/]+)$/.exec(pack.url);
      if (!m || pack.type !== 'zip') continue;
      let name;
      try { name = decodeURIComponent(m[1]); } catch { continue; }
      if (name.startsWith('.') || !fs.existsSync(path.join(config.downloadsDir, name))) {
        problems.push({ pack: pack.name, url: pack.url });
      }
    }
    res.json(200, { missingFiles: problems });
  });
}

module.exports = { registerRoutes };
