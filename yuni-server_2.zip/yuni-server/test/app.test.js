'use strict';
// End-to-end tests: a real server on a random port, a real SQLite database (in a temp dir),
// and a fake Google/Discord provider. Run with:  npm test

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');

const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');
const { hashPassword } = require('../src/security');

const OWNER = 'owner@example.com';
const PASSWORD = 'correct horse battery';

// ── fake OAuth provider ────────────────────────────────────
async function startMockProvider() {
  const state = { codes: {}, tokens: {}, lastToken: null };
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const url = new URL(req.url, 'http://x');
      const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
      if (url.pathname === '/token') {
        const form = new URLSearchParams(Buffer.concat(chunks).toString());
        state.lastToken = Object.fromEntries(form);
        const profile = state.codes[form.get('code')];
        if (form.get('client_secret') !== 'shh' || !profile) return send(400, { error: 'invalid_grant' });
        const token = `tok-${form.get('code')}`;
        state.tokens[token] = profile;
        return send(200, { access_token: token, token_type: 'Bearer' });
      }
      if (url.pathname === '/userinfo') {
        const profile = state.tokens[String(req.headers.authorization || '').replace('Bearer ', '')];
        return profile ? send(200, profile) : send(401, {});
      }
      return send(404, {});
    });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  state.url = `http://127.0.0.1:${server.address().port}`;
  state.close = () => new Promise((r) => server.close(r));
  return state;
}

// ── test app + cookie-aware client ─────────────────────────
async function startApp({ mock, tweak, mailer, mfa = false } = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'yuni-test-'));
  const config = loadConfig({ NODE_ENV: 'test', APP_URL: 'http://localhost:3000', DATA_DIR: dataDir, ADMIN_EMAILS: OWNER });
  config.rate.global.max = 100000;
  config.rate.auth.max = 100000;
  config.security.requireAdmin2fa = mfa; // the 2FA tests turn this on; the rest test everything else
  config.statusApi = mock ? `${mock.url}/status/` : config.statusApi;
  if (mock) {
    for (const [name, secretField] of [['google', 'sub'], ['discord', 'id']]) {
      Object.assign(config.providers[name], {
        clientId: `${name}-id`, clientSecret: 'shh', enabled: true,
        authUrl: `${mock.url}/authorize`, tokenUrl: `${mock.url}/token`, userinfoUrl: `${mock.url}/userinfo`,
      });
      void secretField;
    }
  }
  if (tweak) tweak(config);
  fs.mkdirSync(config.downloadsDir, { recursive: true });
  fs.writeFileSync(path.join(config.downloadsDir, 'pack.zip'), 'PK-fake-zip-contents-0123456789');
  fs.writeFileSync(path.join(config.downloadsDir, '.secret'), 'nope');

  const db = openDb(config.dbFile);
  const app = createApp({ config, db, log: false, mailer });
  const server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;

  const ctx = {
    config, db, store: app.store, base,
    client: () => makeClient(base, config.origin),
    async close() { await new Promise((r) => server.close(r)); app.close(); db.close(); fs.rmSync(dataDir, { recursive: true, force: true }); },
    async addVerifiedUser(email, { password = PASSWORD } = {}) {
      return app.store.createUser({ email, passwordHash: await hashPassword(password), verified: true });
    },
  };
  return ctx;
}

function makeClient(base, origin) {
  const jar = {};
  const self = { csrf: null, jar };
  self.request = async (method, p, { body, headers = {}, origin: o = origin } = {}) => {
    const h = { ...headers };
    if (o) h.Origin = o;
    const cookie = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
    if (cookie) h.Cookie = cookie;
    let payload;
    if (body !== undefined) {
      h['Content-Type'] = h['Content-Type'] || 'application/json';
      payload = typeof body === 'string' ? body : JSON.stringify(body);
    }
    if (self.csrf && method !== 'GET' && h['X-CSRF-Token'] === undefined) h['X-CSRF-Token'] = self.csrf;
    const res = await fetch(base + p, { method, headers: h, body: payload, redirect: 'manual' });
    for (const c of res.headers.getSetCookie()) {
      const pair = c.split(';')[0];
      const i = pair.indexOf('=');
      const name = pair.slice(0, i);
      const val = pair.slice(i + 1);
      if (/Max-Age=0/i.test(c) || val === '') delete jar[name]; else jar[name] = val;
    }
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* not json */ }
    if (json && json.csrf) self.csrf = json.csrf;
    return { status: res.status, headers: res.headers, text, json, location: res.headers.get('location') };
  };
  self.get = (p, o) => self.request('GET', p, o);
  self.post = (p, body, o) => self.request('POST', p, { body, ...o });
  self.put = (p, body, o) => self.request('PUT', p, { body, ...o });
  self.del = (p, o) => self.request('DELETE', p, o);
  self.login = (email, password = PASSWORD) => self.post('/api/auth/login', { email, password });
  return self;
}

// A normal valid settings document.
const validSite = () => ({
  servers: [
    { icon: '⚔️', name: 'Survival', ip: 'play.example.com', port: '25565', description: 'hello', hidden: false },
    { icon: '🔒', name: 'Staff', ip: '10.0.0.5', port: '25570', description: '', hidden: true },
  ],
  modpacks: [
    { serverName: 'Survival', name: 'Main', version: '1.0', type: 'zip', url: 'downloads/pack.zip' },
    { serverName: 'Staff', name: 'Secret', version: '', type: 'link', url: 'https://example.com/secret' },
  ],
  fallback: { name: 'Fallback', url: 'downloads/pack.zip', download: true },
  announcement: { enabled: true, text: 'Maintenance tonight', level: 'warn' },
});

// ═══════════════════════════════════════════════════════════
test('security headers are set and the server does not advertise itself', async () => {
  const app = await startApp();
  try {
    const r = await app.client().get('/api/site');
    const csp = r.headers.get('content-security-policy');
    assert.match(csp, /default-src 'self'/);
    assert.match(csp, /script-src 'self'(;|$)/);
    assert.match(csp, /frame-ancestors 'none'/);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(r.headers.get('x-frame-options'), 'DENY');
    assert.equal(r.headers.get('x-powered-by'), null);
    assert.equal(r.headers.get('cache-control'), 'private, no-cache');
  } finally { await app.close(); }
});

test('public site data hides hidden servers and never exposes admins or emails', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const admin = app.client();
    await admin.login(OWNER);
    const save = await admin.put('/api/admin/site', { site: validSite(), baseVersion: 1 });
    assert.equal(save.status, 200, save.text);

    const pub = await app.client().get('/api/site');
    assert.deepEqual(pub.json.servers.map((s) => s.name), ['Survival']);
    assert.deepEqual(pub.json.modpacks.map((p) => p.name), ['Main'], 'pack for a hidden server must not leak');
    assert.equal(pub.json.announcement.text, 'Maintenance tonight');
    assert.ok(!pub.text.includes(OWNER), 'no admin emails in public data');
    assert.ok(!pub.text.includes('10.0.0.5'), 'hidden server IP must not leak');
  } finally { await app.close(); }
});

// ── passwords & sessions ───────────────────────────────────
test('signup, session, me and logout work; cookie flags are safe', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    const weak = await c.post('/api/auth/signup', { email: 'a@example.com', password: 'short' });
    assert.equal(weak.status, 400);
    const common = await c.post('/api/auth/signup', { email: 'a@example.com', password: 'password123' });
    assert.equal(common.status, 400);

    const ok = await c.post('/api/auth/signup', { email: 'A@Example.com', password: PASSWORD });
    assert.equal(ok.status, 201);
    assert.equal(ok.json.user.email, 'a@example.com');
    assert.equal(ok.json.user.isAdmin, false);
    const setCookie = ok.headers.getSetCookie().join('\n');
    assert.match(setCookie, /HttpOnly/);
    assert.match(setCookie, /SameSite=Lax/);

    const me = await c.get('/api/auth/me');
    assert.equal(me.json.user.email, 'a@example.com');

    const dup = await app.client().post('/api/auth/signup', { email: 'a@example.com', password: PASSWORD });
    assert.equal(dup.status, 409);

    assert.equal((await c.post('/api/auth/logout', {})).status, 200);
    assert.equal((await c.get('/api/auth/me')).json.user, null);
  } finally { await app.close(); }
});

test('passwords are stored as salted scrypt hashes and session ids are stored hashed', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    await c.post('/api/auth/signup', { email: 'h@example.com', password: PASSWORD });
    const row = app.db.prepare('SELECT password_hash FROM users WHERE email = ?').get('h@example.com');
    assert.match(row.password_hash, /^scrypt\$32768\$8\$1\$/);
    assert.ok(!row.password_hash.includes(PASSWORD));
    const token = c.jar.yuni_sid;
    const sessions = app.db.prepare('SELECT id_hash FROM sessions').all();
    assert.ok(token && sessions.length === 1 && sessions[0].id_hash !== token, 'raw session token must not be stored');
  } finally { await app.close(); }
});

test('wrong password gives a generic error; 5 failures lock the account (and unknown emails behave the same)', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('real@example.com');
    const c = app.client();
    const wrongReal = await c.login('real@example.com', 'wrong-password-1');
    const wrongGhost = await c.login('nobody@example.com', 'wrong-password-1');
    assert.equal(wrongReal.status, 401);
    assert.equal(wrongGhost.status, 401);
    assert.equal(wrongReal.json.error, wrongGhost.json.error, 'must not reveal whether the account exists');

    for (let i = 0; i < 3; i += 1) await c.login('real@example.com', 'wrong-password-x');
    assert.equal((await c.login('real@example.com', 'wrong-password-y')).status, 401); // 5th failure triggers lock
    assert.equal((await c.login('real@example.com', PASSWORD)).status, 429, 'locked even with the right password');

    for (let i = 0; i < 4; i += 1) await c.login('nobody@example.com', 'wrong-password-x');
    assert.equal((await c.login('nobody@example.com', 'wrong-password-x')).status, 429, 'unknown email locks the same way');
  } finally { await app.close(); }
});

test('SQL injection strings are just wrong credentials', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('real@example.com');
    const r = await app.client().post('/api/auth/login', { email: "real@example.com' OR '1'='1", password: "' OR '1'='1" });
    assert.equal(r.status, 401);
    assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 1);
  } finally { await app.close(); }
});

test('the per-IP auth rate limit kicks in', async () => {
  const app = await startApp({ tweak: (c) => { c.rate.auth.max = 3; } });
  try {
    const c = app.client();
    const codes = [];
    for (let i = 0; i < 5; i += 1) codes.push((await c.login('x@example.com', 'whatever-123')).status);
    assert.deepEqual(codes.slice(0, 3), [401, 401, 401]);
    assert.equal(codes[4], 429);
  } finally { await app.close(); }
});

test('idle and absolute session expiry are enforced', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    assert.equal((await c.get('/api/admin/site')).status, 200);
    app.db.exec('UPDATE sessions SET last_seen = last_seen - 31 * 60 * 1000'); // admin idle limit is 30 min
    assert.equal((await c.get('/api/admin/site')).status, 401);

    await c.login(OWNER);
    app.db.exec('UPDATE sessions SET created_at = created_at - 13 * 60 * 60 * 1000'); // admin absolute limit is 12 h
    assert.equal((await c.get('/api/admin/site')).status, 401);
  } finally { await app.close(); }
});

test('logging in again issues a new session id (no session fixation)', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('u@example.com');
    const c = app.client();
    await c.login('u@example.com');
    const first = c.jar.yuni_sid;
    await c.login('u@example.com');
    assert.notEqual(c.jar.yuni_sid, first);
    assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 1, 'old session removed');
  } finally { await app.close(); }
});

// ── CSRF / cross-site protection ───────────────────────────
test('state-changing requests need the CSRF token, a same-site Origin and a JSON body', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    const body = { site: validSite(), baseVersion: 1 };

    assert.equal((await c.put('/api/admin/site', body, { headers: { 'X-CSRF-Token': 'wrong' } })).status, 403);
    const noToken = makeClient(app.base, app.config.origin);
    noToken.jar.yuni_sid = c.jar.yuni_sid; // stolen-cookie style request without the token
    assert.equal((await noToken.put('/api/admin/site', body)).status, 403);
    assert.equal((await c.put('/api/admin/site', body, { origin: 'https://evil.example' })).status, 403);
    assert.equal((await c.put('/api/admin/site', body, { origin: null })).status, 403, 'no Origin and no Fetch-Metadata → refused');
    assert.equal((await c.put('/api/admin/site', JSON.stringify(body), { headers: { 'Content-Type': 'text/plain' } })).status, 415);
    assert.equal((await c.put('/api/admin/site', body)).status, 200);
  } finally { await app.close(); }
});

test('cross-site login attempts are rejected', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('u@example.com');
    const r = await app.client().post('/api/auth/login', { email: 'u@example.com', password: PASSWORD }, { origin: 'https://evil.example' });
    assert.equal(r.status, 403);
  } finally { await app.close(); }
});

test('oversized and malformed JSON bodies are refused', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    assert.equal((await c.post('/api/auth/login', '{not json')).status, 400);
    assert.equal((await c.post('/api/auth/login', `{"email":"${'a'.repeat(300 * 1024)}"}`)).status, 413);
    assert.equal((await c.post('/api/auth/login', '[1,2]')).status, 400);
  } finally { await app.close(); }
});

// ── authorization ──────────────────────────────────────────
test('admin API is closed to anonymous users and ordinary members', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('member@example.com');
    const anon = app.client();
    for (const p of ['/api/admin/site', '/api/admin/users', '/api/admin/admins', '/api/admin/audit', '/api/admin/health']) {
      assert.equal((await anon.get(p)).status, 401, p);
    }
    const member = app.client();
    await member.login('member@example.com');
    for (const p of ['/api/admin/site', '/api/admin/users', '/api/admin/admins', '/api/admin/audit']) {
      assert.equal((await member.get(p)).status, 403, p);
    }
    assert.equal((await member.put('/api/admin/site', { site: validSite(), baseVersion: 1 })).status, 403);
    assert.equal((await member.post('/api/admin/admins', { email: 'me@example.com' })).status, 403);
  } finally { await app.close(); }
});

test('a password sign-up with an admin email is NOT an admin (email is unverified)', async () => {
  const app = await startApp();
  try {
    const squatter = app.client();
    const r = await squatter.post('/api/auth/signup', { email: OWNER, password: 'squatter-password-1' });
    assert.equal(r.status, 201);
    assert.equal(r.json.user.isAdmin, false);
    assert.equal((await squatter.get('/api/admin/site')).status, 403);
  } finally { await app.close(); }
});

test('admin pages are only served to admins', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    await app.addVerifiedUser('member@example.com');
    const anon = app.client();
    const r = await anon.get('/admin/dashboard.html');
    assert.equal(r.status, 302);
    assert.equal(r.location, '/admin/login.html');
    assert.equal((await anon.get('/admin/dashboard.js')).status, 404);
    assert.equal((await anon.get('/admin/member.html')).status, 302);

    const member = app.client();
    await member.login('member@example.com');
    assert.equal((await member.get('/admin/dashboard.html')).status, 302);
    assert.equal((await member.get('/admin/member.html')).status, 200);

    const admin = app.client();
    await admin.login(OWNER);
    assert.equal((await admin.get('/admin/dashboard.html')).status, 200);
  } finally { await app.close(); }
});

// ── site settings validation ───────────────────────────────
test('settings are validated on the server', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    const bad = validSite();
    bad.servers[0].port = '99999';
    bad.servers[1].name = 'survival'; // duplicate (case-insensitive)
    bad.modpacks[0].url = 'javascript:alert(1)';
    bad.modpacks[1].url = '//evil.example/x.zip';
    bad.servers[0].ip = 'bad host <script>';
    const r = await c.put('/api/admin/site', { site: bad, baseVersion: 1 });
    assert.equal(r.status, 400);
    assert.ok(r.json.details.length >= 4, JSON.stringify(r.json.details));

    const traversal = validSite();
    traversal.modpacks[0].url = 'downloads/../../etc/passwd';
    assert.equal((await c.put('/api/admin/site', { site: traversal, baseVersion: 1 })).status, 400);

    const empty = validSite();
    empty.servers = [];
    assert.equal((await c.put('/api/admin/site', { site: empty, baseVersion: 1 })).status, 400);

    // nothing was stored
    assert.equal(app.store.getSite().version, 1);
  } finally { await app.close(); }
});

test('two admins cannot silently overwrite each other (version check)', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const a = app.client();
    const b = app.client();
    await a.login(OWNER);
    await b.login(OWNER);
    const first = await a.put('/api/admin/site', { site: validSite(), baseVersion: 1 });
    assert.equal(first.status, 200);
    assert.equal(first.json.meta.version, 2);
    const stale = await b.put('/api/admin/site', { site: validSite(), baseVersion: 1 });
    assert.equal(stale.status, 409);
    assert.equal(stale.json.meta.version, 2);
  } finally { await app.close(); }
});

// ── managing admins and accounts ───────────────────────────
test('owners can add and remove admins; owners and yourself are protected', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);

    assert.equal((await c.post('/api/admin/admins', { email: 'not-an-email' })).status, 400);
    const added = await c.post('/api/admin/admins', { email: 'Friend@Example.com' });
    assert.equal(added.status, 201);
    assert.ok(added.json.admins.some((a) => a.email === 'friend@example.com'));
    assert.equal((await c.post('/api/admin/admins', { email: 'friend@example.com' })).status, 409);

    assert.equal((await c.del(`/api/admin/admins/${encodeURIComponent(OWNER)}`)).status, 400);
    assert.equal((await c.del('/api/admin/admins/friend%40example.com')).status, 200);
    assert.equal((await c.del('/api/admin/admins/friend%40example.com')).status, 404);

    const log = await c.get('/api/admin/audit');
    assert.ok(log.json.entries.some((e) => e.action === 'admin.add'));
    assert.ok(log.json.entries.some((e) => e.action === 'admin.remove'));
  } finally { await app.close(); }
});

test('a newly added admin gets access after their account is verified, and loses it when removed', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const owner = app.client();
    await owner.login(OWNER);
    await app.addVerifiedUser('helper@example.com');
    const helper = app.client();
    await helper.login('helper@example.com');
    assert.equal((await helper.get('/api/admin/site')).status, 403);

    await owner.post('/api/admin/admins', { email: 'helper@example.com' });
    assert.equal((await helper.get('/api/admin/site')).status, 200, 'takes effect immediately, no re-login needed');

    await owner.del('/api/admin/admins/helper%40example.com');
    assert.equal((await helper.get('/api/admin/site')).status, 403, 'removal also takes effect immediately');
  } finally { await app.close(); }
});

test('deleting an account revokes its sessions; owners and self cannot be deleted', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const victim = await app.addVerifiedUser('victim@example.com');
    const owner = app.client();
    await owner.login(OWNER);
    const v = app.client();
    await v.login('victim@example.com');
    assert.equal((await v.get('/api/auth/me')).json.user.email, 'victim@example.com');

    const users = (await owner.get('/api/admin/users')).json.users;
    const ownerRow = users.find((u) => u.email === OWNER);
    assert.equal((await owner.del(`/api/admin/users/${ownerRow.id}`)).status, 400);
    assert.equal((await owner.del(`/api/admin/users/${victim.id}`)).status, 200);
    assert.equal((await v.get('/api/auth/me')).json.user, null);
  } finally { await app.close(); }
});

// ── Google / Discord ───────────────────────────────────────
async function oauthLogin(app, mock, provider, profile, { tamper } = {}) {
  const c = app.client();
  const start = await c.get(`/auth/${provider}/start`);
  assert.equal(start.status, 302, start.text);
  const loc = new URL(start.location);
  const state = loc.searchParams.get('state');
  const code = `code-${Math.random().toString(36).slice(2)}`;
  mock.codes[code] = profile;
  const query = new URLSearchParams({ code, state: tamper === 'state' ? 'forged' : state });
  if (tamper === 'cookie') for (const k of Object.keys(c.jar)) delete c.jar[k];
  const cb = await c.get(`/auth/${provider}/callback?${query}`);
  return { c, start, loc, cb, state, code };
}

test('Google sign-in: state + PKCE, verified email required, session issued', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    const r = await oauthLogin(app, mock, 'google', { sub: 'g-1', email: 'Person@Example.com', email_verified: true });
    assert.equal(r.loc.origin, mock.url);
    assert.equal(r.loc.searchParams.get('client_id'), 'google-id');
    assert.equal(r.loc.searchParams.get('code_challenge_method'), 'S256');
    assert.ok(r.loc.searchParams.get('code_challenge'));
    assert.ok(mock.lastToken.code_verifier, 'PKCE verifier is sent to Google');
    assert.equal(mock.lastToken.client_secret, 'shh', 'secret is sent server-to-server');
    assert.ok(!r.start.location.includes('shh'), 'secret never goes through the browser');

    assert.equal(r.cb.status, 302);
    assert.equal(r.cb.location, '/profile.html');
    const me = await r.c.get('/api/auth/me');
    assert.equal(me.json.user.email, 'person@example.com');
    assert.equal(me.json.user.isAdmin, false);
    assert.equal(me.json.user.emailVerified, true);
  } finally { await app.close(); await mock.close(); }
});

test('Discord sign-in works, uses no PKCE, and sends an owner straight to the dashboard', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    const r = await oauthLogin(app, mock, 'discord', { id: 'd-1', email: OWNER, verified: true });
    assert.equal(r.loc.searchParams.get('code_challenge'), null);
    assert.equal(r.cb.location, '/admin/dashboard.html');
    const me = await r.c.get('/api/auth/me');
    assert.equal(me.json.user.isAdmin, true);
    assert.equal(me.json.user.isOwner, true);
    assert.equal((await r.c.get('/api/admin/site')).status, 200);
  } finally { await app.close(); await mock.close(); }
});

test('an admin added in the panel becomes admin when they sign in with Google, others stay members', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    await app.addVerifiedUser(OWNER);
    const owner = app.client();
    await owner.login(OWNER);
    await owner.post('/api/admin/admins', { email: 'newadmin@example.com' });

    const yes = await oauthLogin(app, mock, 'google', { sub: 'g-10', email: 'newadmin@example.com', email_verified: true });
    assert.equal(yes.cb.location, '/admin/dashboard.html');
    assert.equal((await yes.c.get('/api/admin/site')).status, 200);

    const no = await oauthLogin(app, mock, 'google', { sub: 'g-11', email: 'stranger@example.com', email_verified: true });
    assert.equal(no.cb.location, '/profile.html');
    assert.equal((await no.c.get('/api/admin/site')).status, 403);
  } finally { await app.close(); await mock.close(); }
});

test('OAuth rejects: unverified provider email, forged state, missing binding cookie, replayed state', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    const unverified = await oauthLogin(app, mock, 'google', { sub: 'g-2', email: OWNER, email_verified: false });
    assert.match(unverified.cb.location, /error=unverified/);
    assert.equal((await unverified.c.get('/api/auth/me')).json.user, null);

    const forged = await oauthLogin(app, mock, 'google', { sub: 'g-3', email: 'a@example.com', email_verified: true }, { tamper: 'state' });
    assert.match(forged.cb.location, /error=state/);

    const noCookie = await oauthLogin(app, mock, 'google', { sub: 'g-4', email: 'b@example.com', email_verified: true }, { tamper: 'cookie' });
    assert.match(noCookie.cb.location, /error=state/);

    const ok = await oauthLogin(app, mock, 'discord', { id: 'd-9', email: 'c@example.com', verified: true });
    assert.equal(ok.cb.location, '/profile.html');
    const replay = await ok.c.get(`/auth/discord/callback?code=${ok.code}&state=${ok.state}`);
    assert.match(replay.location, /error=state/);

    const denied = await app.client().get('/auth/google/callback?error=access_denied');
    assert.match(denied.location, /error=denied/);

    assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 1, 'only the one valid sign-in created an account');
  } finally { await app.close(); await mock.close(); }
});

test('disabled providers redirect back to the login page', async () => {
  const app = await startApp();
  try {
    const r = await app.client().get('/auth/google/start');
    assert.equal(r.status, 302);
    assert.match(r.location, /error=provider_unavailable/);
    assert.deepEqual((await app.client().get('/api/auth/providers')).json, { google: false, discord: false, emailVerification: false });
  } finally { await app.close(); }
});

test('pre-registration takeover is blocked: signing in with Google wipes an unverified password account', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    // An attacker signs up with the victim's email first and keeps a logged-in session.
    const attacker = app.client();
    const signup = await attacker.post('/api/auth/signup', { email: 'victim@example.com', password: 'attacker-password-9' });
    assert.equal(signup.status, 201);
    assert.equal((await attacker.get('/api/auth/me')).json.user.email, 'victim@example.com');

    // The real owner of that email signs in with Google.
    const real = await oauthLogin(app, mock, 'google', { sub: 'g-victim', email: 'victim@example.com', email_verified: true });
    assert.equal(real.cb.status, 302);
    assert.equal((await real.c.get('/api/auth/me')).json.user.email, 'victim@example.com');

    // The attacker's password and session are now useless.
    assert.equal((await attacker.get('/api/auth/me')).json.user, null, 'attacker session revoked');
    assert.equal((await app.client().login('victim@example.com', 'attacker-password-9')).status, 401, 'attacker password wiped');
    assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM users').get().n, 1);
  } finally { await app.close(); await mock.close(); }
});

// ── server status & health ─────────────────────────────────
test('server status check validates input and uses only the fixed status API', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock });
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    assert.equal((await c.get('/api/admin/status?host=bad%20host')).status, 400);
    assert.equal((await c.get('/api/admin/status?host=127.0.0.1%40evil.com')).status, 400);
    assert.equal((await c.get('/api/admin/status?host=play.example.com&port=70000')).status, 400);
    const ok = await c.get('/api/admin/status?host=play.example.com&port=25565');
    assert.equal(ok.status, 200);
    assert.ok(ok.json.error || ok.json.online !== undefined);
  } finally { await app.close(); await mock.close(); }
});

test('health check reports modpack files that do not exist', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    const site = validSite();
    site.modpacks = [
      { serverName: 'Survival', name: 'Exists', version: '', type: 'zip', url: 'downloads/pack.zip' },
      { serverName: 'Survival', name: 'Missing', version: '', type: 'zip', url: 'downloads/nope.zip' },
    ];
    await c.put('/api/admin/site', { site, baseVersion: 1 });
    const h = await c.get('/api/admin/health');
    assert.deepEqual(h.json.missingFiles.map((m) => m.pack), ['Missing']);
  } finally { await app.close(); }
});

// ── static files & downloads ───────────────────────────────
test('downloads are served as attachments, support resume, and cannot escape the folder', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    const full = await c.get('/downloads/pack.zip');
    assert.equal(full.status, 200);
    assert.match(full.headers.get('content-disposition'), /^attachment;/);
    assert.equal(full.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(full.text, 'PK-fake-zip-contents-0123456789');

    const part = await c.get('/downloads/pack.zip', { headers: { Range: 'bytes=3-6' } });
    assert.equal(part.status, 206);
    assert.equal(part.text, 'fake');

    for (const p of ['/downloads/.secret', '/downloads/..%2f..%2fetc%2fpasswd', '/downloads/%2e%2e/yuni.db', '/downloads/', '/downloads/missing.zip', '/downloads/..%5c..%5cwindows']) {
      assert.equal((await c.get(p)).status, 404, p);
    }
  } finally { await app.close(); }
});

test('source code, config and the database are never served', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    for (const p of ['/.env', '/package.json', '/src/app.js', '/src/config.js', '/test/app.test.js', '/data/yuni.db', '/yuni.db', '/../src/app.js', '/%2e%2e/src/app.js', '/.git/config', '/scripts/create-admin.js', '/Dockerfile']) {
      const r = await c.get(p);
      assert.equal(r.status, 404, `${p} -> ${r.status}`);
    }
  } finally { await app.close(); }
});

test('the home page and shared script are served', async () => {
  const app = await startApp();
  try {
    const c = app.client();
    const home = await c.get('/');
    assert.equal(home.status, 200);
    assert.match(home.headers.get('content-type'), /text\/html/);
    assert.equal((await c.get('/js/common.js')).status, 200);
    assert.equal((await c.get('/admin/login.html')).status, 200);
    assert.equal((await c.get('/healthz')).json.ok, true);
  } finally { await app.close(); }
});

test('no page uses inline scripts or inline event handlers (so the strict CSP holds)', () => {
  const root = path.join(__dirname, '..', 'public');
  const pages = [];
  (function walk(dir) {
    for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, f.name);
      if (f.isDirectory()) walk(p); else if (f.name.endsWith('.html')) pages.push(p);
    }
  }(root));
  assert.ok(pages.length >= 5);
  for (const page of pages) {
    const html = fs.readFileSync(page, 'utf8');
    for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
      assert.ok(/\bsrc=/.test(m[1]) && m[2].trim() === '', `${path.basename(page)} has an inline script`);
      assert.ok(!/src=["']https?:/i.test(m[1]), `${path.basename(page)} loads a third-party script`);
    }
    assert.ok(!/\son[a-z]+\s*=/i.test(html), `${path.basename(page)} has an inline event handler`);
  }
});

// ═══════════════════════ email verification ═══════════════════════
function fakeMailer() {
  const sent = [];
  return {
    enabled: true, sent,
    send: async (m) => { sent.push(m); },
    last: () => sent[sent.length - 1],
    tokenOf: (m) => /token=([A-Za-z0-9_-]+)/.exec(m.text)[1],
  };
}
const withMail = (extra = {}) => (c) => { c.mail.enabled = true; Object.assign(c.mail, extra); };
const flush = () => new Promise((r) => setTimeout(r, 20));

test('with email on, sign-up sends a link, creates nothing, and answers the same for existing accounts', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail({ cooldownMs: 0 }) });
  try {
    await app.addVerifiedUser('taken@example.com');
    const c = app.client();
    const fresh = await c.post('/api/auth/signup', { email: 'New@Example.com' });
    await flush();
    assert.equal(fresh.status, 202);
    assert.ok(!app.store.getUserByEmail('new@example.com'));
    assert.equal((await c.get('/api/auth/me')).json.user, null, 'no session before the link is used');
    assert.equal(mailer.sent.length, 1);
    assert.equal(mailer.last().to, 'new@example.com');
    assert.match(mailer.last().text, /^http:\/\/localhost:3000\/admin\/verify\.html\?token=/m);

    const existing = await c.post('/api/auth/signup', { email: 'taken@example.com' });
    assert.equal(existing.status, 202);
    assert.deepEqual(existing.json, fresh.json, 'identical response, so account existence is not revealed');
    const unknownBody = await c.post('/api/auth/signup', { email: 'not-an-email' });
    assert.equal(unknownBody.status, 400);

    // only a hash of the token is stored
    const token = mailer.tokenOf(mailer.sent[0]);
    const rows = app.db.prepare('SELECT * FROM email_tokens').all();
    assert.ok(rows.every((r) => r.token_hash !== token && !JSON.stringify(r).includes(token)));
  } finally { await app.close(); }
});

test('the emailed link creates a verified account once, after the user picks a password', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail() });
  try {
    const c = app.client();
    await c.post('/api/auth/signup', { email: 'kid@example.com' });
    await flush();
    const token = mailer.tokenOf(mailer.last());

    const weak = await c.post('/api/auth/verify', { token, password: 'short' });
    assert.equal(weak.status, 400);
    assert.ok(!app.store.getUserByEmail('kid@example.com'), 'a weak password does not consume the link');

    assert.equal((await c.post('/api/auth/verify', { token: token.slice(0, -2) + 'xx', password: 'a-good-long-password' })).status, 400);

    const ok = await c.post('/api/auth/verify', { token, password: 'a-good-long-password' });
    assert.equal(ok.status, 200);
    assert.equal(ok.json.user.emailVerified, true);
    assert.equal(ok.json.user.isAdmin, false);
    assert.equal(app.store.getUserByEmail('kid@example.com').emailVerified, true);
    assert.equal((await c.get('/api/auth/me')).json.user.email, 'kid@example.com');

    const replay = await app.client().post('/api/auth/verify', { token, password: 'another-long-password' });
    assert.equal(replay.status, 400, 'a link works only once');

    const login = await app.client().post('/api/auth/login', { email: 'kid@example.com', password: 'a-good-long-password' });
    assert.equal(login.status, 200);
  } finally { await app.close(); }
});

test('expired links are rejected', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail({ tokenTtlMs: 1 }) });
  try {
    const c = app.client();
    await c.post('/api/auth/signup', { email: 'late@example.com' });
    await flush();
    await new Promise((r) => setTimeout(r, 10));
    const r = await c.post('/api/auth/verify', { token: mailer.tokenOf(mailer.last()), password: 'a-good-long-password' });
    assert.equal(r.status, 400);
    assert.ok(!app.store.getUserByEmail('late@example.com'));
  } finally { await app.close(); }
});

test('an emailed link on an existing account resets the password and signs out other devices', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail() });
  try {
    await app.addVerifiedUser('pat@example.com');
    const other = app.client();
    assert.equal((await other.post('/api/auth/login', { email: 'pat@example.com', password: PASSWORD })).status, 200);

    const c = app.client();
    await c.post('/api/auth/signup', { email: 'pat@example.com' });
    await flush();
    const r = await c.post('/api/auth/verify', { token: mailer.tokenOf(mailer.last()), password: 'brand-new-password-1' });
    assert.equal(r.status, 200);

    assert.equal((await other.get('/api/auth/me')).json.user, null, 'old sessions are revoked');
    assert.equal((await app.client().post('/api/auth/login', { email: 'pat@example.com', password: PASSWORD })).status, 401);
    assert.equal((await app.client().post('/api/auth/login', { email: 'pat@example.com', password: 'brand-new-password-1' })).status, 200);
  } finally { await app.close(); }
});

test('requesting links is rate-limited per address (no mail bombing) and a newer link replaces the older', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail({ cooldownMs: 60000 }) });
  try {
    const c = app.client();
    for (let i = 0; i < 4; i++) assert.equal((await c.post('/api/auth/signup', { email: 'spam@example.com' })).status, 202);
    await flush();
    assert.equal(mailer.sent.length, 1, 'only one email within the cooldown');

    app.db.prepare('UPDATE email_tokens SET created_at = 0').run();
    await c.post('/api/auth/signup', { email: 'spam@example.com' });
    await flush();
    assert.equal(mailer.sent.length, 2);
    const old = mailer.tokenOf(mailer.sent[0]);
    assert.equal((await c.post('/api/auth/verify', { token: old, password: 'a-good-long-password' })).status, 400);
    assert.equal((await c.post('/api/auth/verify', { token: mailer.tokenOf(mailer.sent[1]), password: 'a-good-long-password' })).status, 200);
  } finally { await app.close(); }
});

test('an unverified password account cannot sign in once email is on; admin emails become admins only after verifying', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mailer, tweak: withMail({ cooldownMs: 0 }) });
  try {
    app.store.createUser({ email: 'legacy@example.com', passwordHash: await hashPassword(PASSWORD), verified: false });
    const bad = await app.client().post('/api/auth/login', { email: 'legacy@example.com', password: 'wrong-password-123' });
    assert.equal(bad.status, 401, 'wrong password still gives the generic answer');
    const blocked = await app.client().post('/api/auth/login', { email: 'legacy@example.com', password: PASSWORD });
    assert.equal(blocked.status, 403);
    assert.equal(blocked.json.code, 'email_unverified');

    const c = app.client();
    await c.post('/api/auth/signup', { email: OWNER });
    await flush();
    const r = await c.post('/api/auth/verify', { token: mailer.tokenOf(mailer.last()), password: 'a-sturdy-passphrase-77' });
    assert.equal(r.json.user.isAdmin, true, 'a verified address on the admin list is an admin');
  } finally { await app.close(); }
});

test('the verify endpoint is unavailable when email is off', async () => {
  const app = await startApp();
  try {
    const r = await app.client().post('/api/auth/verify', { token: 'x'.repeat(43), password: 'a-good-long-password' });
    assert.equal(r.status, 400);
  } finally { await app.close(); }
});

// ── SMTP client against a fake server ──────────────────────
const { sendMail } = require('../src/mail');
const net = require('node:net');
const tlsLib = require('node:tls');
const { execFileSync } = require('node:child_process');

function fakeSmtp({ starttls, implicitTls, offerStarttls = true, creds } = {}) {
  const log = { cmds: [], data: '', tlsUsed: false, authed: false };
  let key, cert;
  if (starttls || implicitTls) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'yuni-cert-'));
    execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', `${dir}/k.pem`, '-out', `${dir}/c.pem`,
      '-days', '1', '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost'], { stdio: 'ignore' });
    key = fs.readFileSync(`${dir}/k.pem`); cert = fs.readFileSync(`${dir}/c.pem`);
    log.cert = cert;
  }
  function serve(sock, greet = true) {
    let buf = ''; let inData = false;
    const w = (l) => sock.write(l + '\r\n');
    if (greet) w('220 fake ESMTP');
    sock.on('data', (d) => {
      buf += d.toString();
      let i;
      while ((i = buf.indexOf('\r\n')) !== -1) {
        const line = buf.slice(0, i); buf = buf.slice(i + 2);
        if (inData) { if (line === '.') { inData = false; w('250 queued'); } else log.data += line + '\n'; continue; }
        log.cmds.push(line.split(' ')[0]);
        if (/^EHLO/.test(line)) { sock.write('250-fake\r\n' + (starttls && !sock.encrypted && offerStarttls ? '250-STARTTLS\r\n' : '') + '250 AUTH PLAIN LOGIN\r\n'); }
        else if (/^STARTTLS/.test(line)) {
          w('220 go');
          sock.removeAllListeners('data');
          const t = new tlsLib.TLSSocket(sock, { isServer: true, key, cert });
          t.encrypted = true; log.tlsUsed = true;
          serveOn(t);
          return;
        } else if (/^AUTH PLAIN/.test(line)) {
          const [, u, p] = Buffer.from(line.split(' ')[2], 'base64').toString().split('\0');
          if (creds && u === creds.user && p === creds.pass) { log.authed = true; w('235 ok'); } else w('535 no');
        } else if (/^MAIL FROM|^RCPT TO/.test(line)) { log.last = line; log[line.startsWith('MAIL') ? 'from' : 'to'] = line; w('250 ok'); }
        else if (/^DATA/.test(line)) { inData = true; w('354 go'); }
        else if (/^QUIT/.test(line)) { w('221 bye'); sock.end(); }
      }
    });
  }
  function serveOn(t) { serve(t, false); }
  const server = implicitTls
    ? tlsLib.createServer({ key, cert }, (s) => { s.encrypted = true; log.tlsUsed = true; serve(s); })
    : net.createServer(serve);
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ port: server.address().port, log, close: () => new Promise((r) => server.close(r)) })));
}

const mailCfg = (port, extra = {}) => ({ host: '127.0.0.1', port, secure: false, user: '', pass: '', from: 'YuniDoc <no-reply@yuni.test>', ...extra });

test('SMTP: STARTTLS upgrade, login, dot-stuffing and encoded body', async () => {
  const smtp = await fakeSmtp({ starttls: true, creds: { user: 'u', pass: 'p' } });
  try {
    // certificate is for "localhost"
    await sendMail({ ...mailCfg(smtp.port, { user: 'u', pass: 'p', ca: smtp.log.cert }), host: 'localhost' },
      { to: 'a@example.com', subject: 'Hello ✓', text: 'line one\n.\nline three' });
    assert.ok(smtp.log.tlsUsed && smtp.log.authed);
    assert.equal(smtp.log.cmds.indexOf('AUTH') > smtp.log.cmds.indexOf('STARTTLS'), true, 'credentials only after TLS');
    assert.match(smtp.log.from, /<no-reply@yuni\.test>/);
    assert.match(smtp.log.to, /<a@example\.com>/);
    assert.match(smtp.log.data, /Subject: =\?UTF-8\?B\?/);
    const body = Buffer.from(smtp.log.data.split('\n\n')[1].replace(/\s+/g, ''), 'base64').toString();
    assert.equal(body, 'line one\n.\nline three');
  } finally { await smtp.close(); }
});

test('SMTP: implicit TLS works; plain servers are refused; header injection is blocked', async () => {
  const tlsSmtp = await fakeSmtp({ implicitTls: true });
  try {
    await sendMail({ ...mailCfg(tlsSmtp.port, { secure: true, ca: tlsSmtp.log.cert }), host: 'localhost' }, { to: 'a@example.com', subject: 's', text: 't' });
    assert.ok(tlsSmtp.log.tlsUsed);
  } finally { await tlsSmtp.close(); }

  const plain = await fakeSmtp({ starttls: false, creds: { user: 'u', pass: 'p' } });
  try {
    await assert.rejects(sendMail(mailCfg(plain.port, { user: 'u', pass: 'p' }), { to: 'a@example.com', subject: 's', text: 't' }), /STARTTLS|unencrypted/);
    assert.equal(plain.log.authed, false, 'credentials are never sent without TLS');
    await assert.rejects(sendMail(mailCfg(plain.port, { allowPlain: true }), { to: 'a@example.com\r\nBcc: x@y.z', subject: 's', text: 't' }), /Illegal/);
    await assert.rejects(sendMail(mailCfg(plain.port, { allowPlain: true }), { to: 'a@example.com', subject: 's\r\nBcc: x@y.z', text: 't' }), /Illegal/);
  } finally { await plain.close(); }
});

// ═══════════════════════ bug reports and admin notes ═══════════════════════
async function asAdmin(app) {
  await app.addVerifiedUser(OWNER);
  const c = app.client();
  assert.equal((await c.login(OWNER)).status, 200);
  return c;
}
async function asMember(app, email) {
  await app.addVerifiedUser(email);
  const c = app.client();
  assert.equal((await c.login(email)).status, 200);
  return c;
}
const BUG = { title: 'Crash when joining', description: 'The game crashes right after I click join.', category: 'server', serverName: 'Survival' };

test('bug reports: only signed-in users can send, input is validated, and the list is private', async () => {
  const app = await startApp();
  try {
    assert.equal((await app.client().post('/api/bugs', BUG)).status, 401);

    const alice = await asMember(app, 'alice@example.com');
    const bob = await asMember(app, 'bob@example.com');
    for (const bad of [
      { ...BUG, title: 'abc' }, { ...BUG, description: 'short' }, { ...BUG, category: 'nope' },
      { ...BUG, title: 'x'.repeat(121) }, { ...BUG, description: 'y'.repeat(4001) }, { ...BUG, title: 123 }, { ...BUG, serverName: 's'.repeat(61) },
    ]) assert.equal((await alice.post('/api/bugs', bad)).status, 400, JSON.stringify(bad).slice(0, 60));

    const ok = await alice.post('/api/bugs', { ...BUG, title: '<img src=x onerror=alert(1)> broken\u0007' });
    assert.equal(ok.status, 201);

    const mine = await alice.get('/api/bugs/mine');
    assert.equal(mine.json.bugs.length, 1);
    assert.deepEqual(Object.keys(mine.json.bugs[0]).sort(), ['category', 'createdAt', 'id', 'serverName', 'status', 'title'], 'reporters never see admin data');
    assert.equal(mine.json.bugs[0].title.includes('\u0007'), false, 'control characters are stripped');
    assert.equal((await bob.get('/api/bugs/mine')).json.bugs.length, 0, 'other people cannot see it');
    assert.equal((await alice.get('/api/admin/bugs')).status, 403);
  } finally { await app.close(); }
});

test('bug reports: at most 5 per hour per person', async () => {
  const app = await startApp();
  try {
    const c = await asMember(app, 'busy@example.com');
    for (let i = 0; i < 5; i++) assert.equal((await c.post('/api/bugs', { ...BUG, title: `Report number ${i}` })).status, 201);
    assert.equal((await c.post('/api/bugs', BUG)).status, 429);
    assert.equal((await (await asMember(app, 'other@example.com')).post('/api/bugs', BUG)).status, 201, 'the limit is per person');
  } finally { await app.close(); }
});

test('bug reports: admins triage them (status, priority, note), changes are audited, and deleting works', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    const reporter = await asMember(app, 'rep@example.com');
    const { json: { id } } = await reporter.post('/api/bugs', BUG);

    const list = (await admin.get('/api/admin/bugs')).json.bugs;
    assert.equal(list.length, 1);
    assert.equal(list[0].reporter, 'rep@example.com');
    assert.equal(list[0].status, 'open');

    assert.equal((await admin.put(`/api/admin/bugs/${id}`, { status: 'bogus' })).status, 400);
    assert.equal((await admin.put(`/api/admin/bugs/${id}`, { priority: 'urgent!!' })).status, 400);
    assert.equal((await admin.put(`/api/admin/bugs/${id}`, { adminNote: 'n'.repeat(2001) })).status, 400);
    assert.equal((await admin.put('/api/admin/bugs/9999', { status: 'resolved' })).status, 404);
    assert.equal((await admin.put('/api/admin/bugs/abc', { status: 'resolved' })).status, 404);

    const upd = await admin.put(`/api/admin/bugs/${id}`, { status: 'in_progress', priority: 'high', adminNote: 'Looking at the proxy logs' });
    assert.equal(upd.status, 200);
    assert.deepEqual([upd.json.bug.status, upd.json.bug.priority, upd.json.bug.adminNote, upd.json.bug.updatedBy], ['in_progress', 'high', 'Looking at the proxy logs', OWNER]);
    const cleared = await admin.put(`/api/admin/bugs/${id}`, { adminNote: '' });
    assert.equal(cleared.json.bug.adminNote, '');
    assert.equal(cleared.json.bug.status, 'in_progress', 'unspecified fields are left alone');

    assert.equal((await reporter.get('/api/bugs/mine')).json.bugs[0].status, 'in_progress', 'reporter sees the status');
    assert.ok((await admin.get('/api/admin/audit')).json.entries.some((e) => e.action === 'bug.status' && e.detail.includes('in_progress')));

    // a member cannot touch it
    assert.equal((await reporter.put(`/api/admin/bugs/${id}`, { status: 'resolved' })).status, 403);
    assert.equal((await reporter.del(`/api/admin/bugs/${id}`)).status, 403);

    assert.equal((await admin.del(`/api/admin/bugs/${id}`)).status, 200);
    assert.equal((await admin.get('/api/admin/bugs')).json.bugs.length, 0);
    assert.equal((await admin.del(`/api/admin/bugs/${id}`)).status, 404);
  } finally { await app.close(); }
});

test('bug reports: deleting the reporter keeps the report but removes their email; CSRF is enforced', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    const reporter = await asMember(app, 'leaving@example.com');
    await reporter.post('/api/bugs', BUG);
    const user = app.store.getUserByEmail('leaving@example.com');
    assert.equal((await admin.del(`/api/admin/users/${user.id}`)).status, 200);
    const bugs = (await admin.get('/api/admin/bugs')).json.bugs;
    assert.equal(bugs.length, 1);
    assert.equal(bugs[0].reporter, 'deleted account');
    assert.ok(!JSON.stringify(bugs).includes('leaving@example.com'));

    const noCsrf = await admin.put(`/api/admin/bugs/${bugs[0].id}`, { status: 'resolved' }, { headers: { 'X-CSRF-Token': 'wrong' } });
    assert.equal(noCsrf.status, 403);
  } finally { await app.close(); }
});

test('admin notes: create, pin ordering, edit, delete, validation, admins only', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    const member = await asMember(app, 'm@example.com');
    assert.equal((await member.get('/api/admin/notes')).status, 403);
    assert.equal((await member.post('/api/admin/notes', { body: 'hi' })).status, 403);
    assert.equal((await app.client().get('/api/admin/notes')).status, 401);

    assert.equal((await admin.post('/api/admin/notes', { body: '   ' })).status, 400);
    assert.equal((await admin.post('/api/admin/notes', { body: 'x'.repeat(4001) })).status, 400);
    assert.equal((await admin.post('/api/admin/notes', { body: 123 })).status, 400);

    const a = (await admin.post('/api/admin/notes', { body: 'First <b>note</b>' })).json.note;
    const b = (await admin.post('/api/admin/notes', { body: 'Second', pinned: true })).json.note;
    assert.equal(a.author, OWNER);
    assert.equal(a.pinned, false);
    let notes = (await admin.get('/api/admin/notes')).json.notes;
    assert.deepEqual(notes.map((n) => n.id), [b.id, a.id], 'pinned notes come first');
    assert.equal(notes[1].body, 'First <b>note</b>', 'stored as plain text (the panel escapes it)');

    assert.equal((await admin.put(`/api/admin/notes/${a.id}`, { pinned: 'yes' })).status, 400);
    assert.equal((await admin.put(`/api/admin/notes/${a.id}`, { body: '' })).status, 400);
    const edited = await admin.put(`/api/admin/notes/${a.id}`, { body: 'First (edited)', pinned: true });
    assert.equal(edited.json.note.body, 'First (edited)');
    assert.equal(edited.json.note.pinned, true);
    assert.equal((await admin.put('/api/admin/notes/9999', { body: 'x' })).status, 404);

    assert.equal((await admin.del(`/api/admin/notes/${b.id}`)).status, 200);
    notes = (await admin.get('/api/admin/notes')).json.notes;
    assert.deepEqual(notes.map((n) => n.id), [a.id]);
    assert.equal((await admin.del(`/api/admin/notes/${b.id}`)).status, 404);
  } finally { await app.close(); }
});

// ═══════════════════════ two-factor authentication & hardening ═══════════════════════
const totpLib = require('../src/totp');

// Codes for "now" and the following time steps (a code can never be used twice).
function codeFor(secret, offset = 0) { return totpLib.totpAt(secret, totpLib.currentStep() + offset); }

async function adminWith2fa(app, { email = OWNER } = {}) {
  if (!app.store.getUserByEmail(email)) await app.addVerifiedUser(email);
  const c = app.client();
  const login = await c.login(email);
  assert.equal(login.json.user.mfa, 'setup');
  const setup = await c.post('/api/auth/2fa/setup', {});
  const on = await c.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret) });
  assert.equal(on.status, 200, JSON.stringify(on.json));
  return { c, secret: setup.json.secret, recoveryCodes: on.json.recoveryCodes };
}

test('2FA: an admin without 2FA only gets member rights until they set it up', async () => {
  const app = await startApp({ mfa: true });
  try {
    await app.addVerifiedUser(OWNER);
    const other = app.client();
    await other.login(OWNER);
    const c = app.client();
    const login = await c.login(OWNER);
    assert.equal(login.json.user.isAdmin, false);
    assert.equal(login.json.user.mfa, 'setup');
    assert.equal((await c.get('/api/admin/site')).status, 403);
    assert.equal((await c.get('/admin/dashboard.html')).status, 302);
    assert.equal((await c.get('/admin/2fa.html')).status, 200);

    const setup = await c.post('/api/auth/2fa/setup', {});
    assert.equal(setup.status, 200);
    assert.match(setup.json.uri, /^otpauth:\/\/totp\/YuniDoc%3Aowner%40example\.com\?secret=[A-Z2-7]{32}&issuer=YuniDoc/);
    const stored = app.db.prepare('SELECT totp_secret FROM users WHERE email = ?').get(OWNER).totp_secret;
    assert.ok(stored.startsWith('v1.') && !stored.includes(setup.json.secret), 'the secret is encrypted in the database');

    assert.equal((await c.post('/api/auth/2fa/enable', { code: '000000' })).status, 401);
    const sidBefore = Object.values(c.jar).join();
    const on = await c.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret) });
    assert.equal(on.status, 200);
    assert.equal(on.json.user.isAdmin, true);
    assert.equal(on.json.recoveryCodes.length, 10);
    assert.notEqual(Object.values(c.jar).join(), sidBefore, 'session id is replaced when privileges go up');
    assert.equal((await c.get('/api/admin/site')).status, 200);
    assert.equal((await other.get('/api/auth/me')).json.user, null, 'other sessions are signed out when 2FA is turned on');
    assert.equal((await c.post('/api/auth/2fa/setup', {})).status, 409, 'cannot be replaced without a reset');
  } finally { await app.close(); }
});

test('2FA: signing in needs a valid code; codes cannot be replayed; wrong codes lock it', async () => {
  const app = await startApp({ mfa: true });
  try {
    const { secret } = await adminWith2fa(app);
    const c = app.client();
    const login = await c.login(OWNER);
    assert.equal(login.json.user.mfa, 'verify');
    assert.equal((await c.get('/api/admin/users')).status, 403);

    const used = codeFor(secret, 1);
    assert.equal((await c.post('/api/auth/2fa/verify', { code: used })).status, 200);
    assert.equal((await c.get('/api/admin/users')).status, 200);

    const thief = app.client();
    await thief.login(OWNER);
    assert.equal((await thief.post('/api/auth/2fa/verify', { code: used })).status, 401, 'a code seen once cannot be used again');

    for (let i = 0; i < 4; i++) assert.equal((await thief.post('/api/auth/2fa/verify', { code: '123456' })).status, 401);
    // 5th wrong code (the replay above counted as one) → locked, even a correct code is refused now
    const locked = await thief.post('/api/auth/2fa/verify', { code: codeFor(secret, 0) });
    assert.equal(locked.status, 429);
    assert.ok((await (await adminClientFrom(c)).get('/api/admin/audit')).json.entries.some((e) => e.action === '2fa.locked'));
  } finally { await app.close(); }
});
async function adminClientFrom(c) { return c; }

test('2FA: recovery codes work once each and are counted', async () => {
  const app = await startApp({ mfa: true });
  try {
    const { recoveryCodes } = await adminWith2fa(app);
    const c = app.client();
    await c.login(OWNER);
    const r = await c.post('/api/auth/2fa/verify', { code: recoveryCodes[0].toUpperCase() });
    assert.equal(r.status, 200);
    assert.equal(r.json.usedRecovery, true);
    assert.equal(r.json.recoveryCodesLeft, 9);
    const again = app.client();
    await again.login(OWNER);
    assert.equal((await again.post('/api/auth/2fa/verify', { code: recoveryCodes[0] })).status, 401);
    const rows = app.db.prepare('SELECT code_hash FROM recovery_codes').all();
    assert.ok(rows.every((x) => !recoveryCodes.some((code) => x.code_hash.includes(code.replace('-', '')))), 'only hashes are stored');
  } finally { await app.close(); }
});

test('2FA step-up: dangerous actions need a recent code', async () => {
  const app = await startApp({ mfa: true });
  try {
    const { c, secret } = await adminWith2fa(app);
    const site = (await c.get('/api/admin/site')).json;
    assert.equal((await c.put('/api/admin/site', { site: site.site, baseVersion: site.meta.version })).status, 200, 'fresh code: allowed');

    app.db.prepare('UPDATE sessions SET mfa_at = ?').run(Date.now() - 20 * 60 * 1000); // 20 minutes ago
    const blocked = await c.put('/api/admin/site', { site: site.site, baseVersion: site.meta.version + 1 });
    assert.equal(blocked.status, 403);
    assert.equal(blocked.json.code, 'reauth');
    for (const [m, p, b] of [['POST', '/api/admin/admins', { email: 'x@example.com' }], ['DELETE', '/api/admin/admins/x@example.com'], ['DELETE', '/api/admin/users/1'], ['POST', '/api/auth/2fa/recovery-codes', {}]]) {
      const r = await c.request(m, p, { body: b || {} });
      assert.equal(r.json.code, 'reauth', `${m} ${p}`);
    }
    assert.equal((await c.get('/api/admin/bugs')).status, 200, 'reading is still fine');

    assert.equal((await c.post('/api/auth/2fa/verify', { code: codeFor(secret, 1) })).status, 200);
    assert.equal((await c.put('/api/admin/site', { site: site.site, baseVersion: site.meta.version + 1 })).status, 200);
  } finally { await app.close(); }
});

test('2FA: members are unaffected; OAuth admins are sent to the 2FA page; a server reset forces new setup', async () => {
  const mock = await startMockProvider();
  const app = await startApp({ mock, mfa: true });
  try {
    await app.addVerifiedUser('member@example.com');
    const m = app.client();
    const login = await m.login('member@example.com');
    assert.equal(login.json.user.mfa, null);
    assert.equal((await m.post('/api/auth/2fa/setup', {})).status, 403);

    const profile = { sub: 'g-9', email: OWNER, email_verified: true };
    const oauth = await oauthLogin(app, mock, 'google', profile);
    assert.equal(oauth.cb.location, '/admin/2fa.html');
    const g = oauth.c;
    assert.equal((await g.get('/api/auth/me')).json.user.mfa, 'setup');
    const setup = await g.post('/api/auth/2fa/setup', {});
    assert.equal((await g.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret) })).json.user.isAdmin, true);

    const again = await oauthLogin(app, mock, 'google', profile);
    assert.equal(again.cb.location, '/admin/2fa.html', 'Google sign-in alone is not enough for admin rights');
    assert.equal((await again.c.get('/api/auth/me')).json.user.mfa, 'verify');

    // what "npm run reset-2fa" does
    const id = app.store.getUserByEmail(OWNER).id;
    app.store.resetTotp(id);
    app.store.deleteUserSessions(id);
    assert.equal((await g.get('/api/auth/me')).json.user, null);
    const fresh = await oauthLogin(app, mock, 'google', profile);
    assert.equal((await fresh.c.get('/api/auth/me')).json.user.mfa, 'setup');
  } finally { await app.close(); await mock.close(); }
});

test('2FA with email on: setup also needs an emailed code; owners get security alerts', async () => {
  const mailer = fakeMailer();
  const app = await startApp({ mfa: true, mailer, tweak: withMail() });
  try {
    await app.addVerifiedUser(OWNER);
    const c = app.client();
    await c.login(OWNER);
    const setup = await c.post('/api/auth/2fa/setup', {});
    assert.equal(setup.json.emailCodeSent, true);
    await flush();
    const mail = mailer.last();
    assert.equal(mail.to, OWNER);
    const emailCode = /(\d{6})/.exec(mail.text)[1];

    assert.equal((await c.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret) })).status, 401, 'app code alone is not enough');
    assert.equal((await c.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret), emailCode: '999999' === emailCode ? '000000' : '999999' })).status, 401);
    const on = await c.post('/api/auth/2fa/enable', { code: codeFor(setup.json.secret), emailCode });
    assert.equal(on.status, 200);
    await flush();
    assert.ok(mailer.sent.some((x) => /Two-factor sign-in turned on/.test(x.subject)));

    const before = mailer.sent.length;
    assert.equal((await c.post('/api/admin/admins', { email: 'newbie@example.com' })).status, 201);
    await flush();
    const alerts = mailer.sent.slice(before);
    assert.ok(alerts.some((x) => x.to === OWNER && /New admin added/.test(x.subject)));
    assert.ok(alerts.some((x) => x.to === 'newbie@example.com'), 'the new admin is told too');
  } finally { await app.close(); }
});

test('sign out everywhere ends every session of the account', async () => {
  const app = await startApp();
  try {
    await app.addVerifiedUser('pat@example.com');
    const a = app.client(); await a.login('pat@example.com');
    const b = app.client(); await b.login('pat@example.com');
    assert.equal((await a.get('/api/auth/security')).json.activeSessions, 2);
    assert.equal((await a.post('/api/auth/logout-all', {})).status, 200);
    assert.equal((await a.get('/api/auth/me')).json.user, null);
    assert.equal((await b.get('/api/auth/me')).json.user, null);
  } finally { await app.close(); }
});

test('passwords found in data breaches are rejected (and a broken check does not block sign-ups)', async () => {
  const crypto = require('node:crypto');
  const breached = 'password-from-a-leak-2024';
  const h = crypto.createHash('sha1').update(breached).digest('hex').toUpperCase();
  let up = true;
  const hibp = http.createServer((req, res) => {
    if (!up) { res.writeHead(500); return res.end(); }
    if (req.url === `/range/${h.slice(0, 5)}`) { res.end(`0000000000000000000000000000000000A:0\r\n${h.slice(5)}:1234\r\n`); return; }
    res.end('');
  });
  await new Promise((r) => hibp.listen(0, '127.0.0.1', r));
  const app = await startApp({ tweak: (c) => { c.security.breachedPasswordCheck = true; c.security.breachedPasswordApi = `http://127.0.0.1:${hibp.address().port}/range/`; } });
  try {
    const bad = await app.client().post('/api/auth/signup', { email: 'a@example.com', password: breached });
    assert.equal(bad.status, 400);
    assert.match(bad.json.error, /data breach/);
    assert.equal((await app.client().post('/api/auth/signup', { email: 'b@example.com', password: 'unique-and-long-password-x' })).status, 201);
    up = false;
    assert.equal((await app.client().post('/api/auth/signup', { email: 'c@example.com', password: breached })).status, 201, 'fails open if the service is down');
  } finally { await app.close(); await new Promise((r) => hibp.close(r)); }
});

test('production refuses to start without SECRET_KEY; older databases are upgraded in place', () => {
  assert.throws(() => loadConfig({ NODE_ENV: 'production', APP_URL: 'https://example.com' }), /SECRET_KEY is required/);
  assert.throws(() => loadConfig({ NODE_ENV: 'production', APP_URL: 'https://example.com', SECRET_KEY: 'short' }), /at least 32/);
  assert.ok(loadConfig({ NODE_ENV: 'production', APP_URL: 'https://example.com', SECRET_KEY: 'x'.repeat(40) }).security.requireAdmin2fa);

  const { DatabaseSync } = require('node:sqlite');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'yuni-old-'));
  const file = path.join(dir, 'old.db');
  const old = new DatabaseSync(file);
  old.exec(`CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT,
              email_verified INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, last_login_at INTEGER,
              failed_logins INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE sessions (id_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, csrf TEXT NOT NULL, created_at INTEGER NOT NULL,
              last_seen INTEGER NOT NULL, idle_ms INTEGER NOT NULL, abs_ms INTEGER NOT NULL, ip TEXT, ua TEXT);
            INSERT INTO users (email, created_at) VALUES ('legacy@example.com', 1);`);
  old.close();
  const db = openDb(file);
  const cols = db.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  assert.ok(cols.includes('totp_secret') && cols.includes('totp_enabled'));
  assert.ok(db.prepare('PRAGMA table_info(sessions)').all().some((c) => c.name === 'mfa_at'));
  assert.equal(db.prepare('SELECT email FROM users').get().email, 'legacy@example.com', 'existing data is kept');
  db.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

// ═══════════════════════ supporters, early access, about & support pages ═══════════════════════
const supportSite = (over = {}) => ({
  ...validSite(),
  servers: [
    { icon: '⚔️', name: 'Survival', ip: 'play.example.com', port: '25565', description: '', hidden: false },
    { icon: '🧪', name: 'Beta', ip: 'beta.example.com', port: '25580', description: 'Next season', hidden: false, access: 'patrons', publicOn: '' },
  ],
  modpacks: [
    { serverName: 'Survival', name: 'Main', version: '', type: 'zip', url: 'downloads/pack.zip' },
    { serverName: 'Beta', name: 'BetaPack', version: '', type: 'link', url: 'https://example.com/betapack' },
  ],
  announcement: { enabled: false, text: '', level: 'info' },
  about: { headline: 'Hello', story: 'Our story.\n\nSecond paragraph.', values: [{ title: 'Fair', text: 'No pay to win' }], team: [{ name: 'Yuni', role: 'Owner', bio: '' }] },
  support: {
    enabled: true, headline: 'Help', intro: 'Hi', pledge: ['Cosmetic only'], showWall: true,
    goal: { currency: '$', monthlyCost: 50, raised: 20, note: '' }, costs: [{ label: 'Hosting', amount: 50 }],
    tiers: [
      { id: 'basic', name: 'Basic', price: '$3', description: '', perks: ['Tag'], earlyAccess: false, url: 'https://ko-fi.com/yuni' },
      { id: 'gold', name: 'Gold', price: '$8', description: '', perks: ['Trail'], earlyAccess: true, url: '' },
    ],
    cosmetics: [{ name: 'Chat tag', description: '', tier: '' }, { name: '=Gold trail', description: '', tier: 'gold' }],
  },
  ...over,
});

async function saveSite(admin, site) {
  const cur = await admin.get('/api/admin/site');
  const r = await admin.put('/api/admin/site', { site, baseVersion: cur.json.meta.version });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r;
}
const leaks = (res) => /beta\.example\.com|25580|betapack/i.test(res.text);

test('early access: a locked server never leaks its address, port or pack to people without it', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    await saveSite(admin, supportSite());
    const grant = await admin.post('/api/admin/patrons', { emails: ['basic@example.com', 'gold@example.com', 'old@example.com'], tier: 'gold' });
    assert.equal(grant.status, 201);
    await admin.put('/api/admin/patrons/basic%40example.com', { tier: 'basic' });
    await admin.put('/api/admin/patrons/old%40example.com', { until: '2020-01-01' });

    const anon = await app.client().get('/api/site');
    assert.equal(anon.status, 200);
    assert.ok(!leaks(anon), 'anonymous visitors');
    const locked = anon.json.servers.find((s) => s.name === 'Beta');
    assert.equal(locked.locked, true);
    assert.equal(locked.ip, '');
    assert.match(anon.headers.get('cache-control'), /private/);
    assert.match(anon.headers.get('vary'), /Cookie/i);
    assert.ok(!anon.json.modpacks.some((p) => p.serverName === 'Beta'));

    const plain = await asMember(app, 'nobody@example.com');
    assert.ok(!leaks(await plain.get('/api/site')), 'signed-in non-supporter');

    const unverified = app.store.createUser({ email: 'basic2@example.com', passwordHash: await hashPassword(PASSWORD), verified: false });
    void unverified;
    await admin.post('/api/admin/patrons', { email: 'basic2@example.com', tier: 'gold' });
    const uv = app.client();
    await uv.login('basic2@example.com');
    assert.ok(!leaks(await uv.get('/api/site')), 'a supporter whose email is not verified');

    const basic = await asMember(app, 'basic@example.com');
    assert.ok(!leaks(await basic.get('/api/site')), 'a tier without early access');
    const expired = await asMember(app, 'old@example.com');
    assert.ok(!leaks(await expired.get('/api/site')), 'an expired supporter');

    const gold = await asMember(app, 'gold@example.com');
    const g = await gold.get('/api/site');
    assert.ok(leaks(g), 'an active early-access supporter gets the address');
    assert.equal(g.json.servers.find((s) => s.name === 'Beta').early, true);
    assert.ok(g.json.modpacks.some((p) => p.serverName === 'Beta'));
    assert.ok(leaks(await admin.get('/api/site')), 'admins always see it');

    // opens to everyone once the date passes
    const open = supportSite();
    open.servers[1].publicOn = '2020-01-01';
    await saveSite(admin, open);
    assert.ok(leaks(await app.client().get('/api/site')), 'publicOn in the past opens it to all');
  } finally { await app.close(); }
});

test('support page content is hidden until switched on, and payment links must be https', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    const off = supportSite();
    off.support.enabled = false;
    await saveSite(admin, off);
    const pub = (await app.client().get('/api/site')).json;
    assert.deepEqual(pub.support, { enabled: false });
    assert.ok(pub.about.story.length > 0, 'the about page is always public');
    assert.equal((await app.client().get('/api/patrons/wall')).json.wall.length, 0);

    const bad = supportSite();
    bad.support.tiers[0].url = 'javascript:alert(1)';
    const cur = await admin.get('/api/admin/site');
    const r = await admin.put('/api/admin/site', { site: bad, baseVersion: cur.json.meta.version });
    assert.equal(r.status, 400);
    const http = supportSite();
    http.support.tiers[0].url = 'http://ko-fi.com/x';
    assert.equal((await admin.put('/api/admin/site', { site: http, baseVersion: cur.json.meta.version })).status, 400);
    const orphan = supportSite();
    orphan.support.cosmetics[0].tier = 'nope';
    assert.equal((await admin.put('/api/admin/site', { site: orphan, baseVersion: cur.json.meta.version })).status, 400);
  } finally { await app.close(); }
});

test('supporters: only admins manage them, changes are audited, CSV is safe and per-tier', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    await saveSite(admin, supportSite());
    const member = await asMember(app, 'm@example.com');
    assert.equal((await member.get('/api/admin/patrons')).status, 403);
    assert.equal((await member.post('/api/admin/patrons', { email: 'x@example.com', tier: 'basic' })).status, 403);
    assert.equal((await app.client().get('/api/admin/patrons/export')).status, 401);

    assert.equal((await admin.post('/api/admin/patrons', { email: 'x@example.com', tier: 'nope' })).status, 400);
    assert.equal((await admin.post('/api/admin/patrons', { email: 'not-an-email', tier: 'basic' })).status, 400);
    assert.equal((await admin.post('/api/admin/patrons', { email: 'x@example.com', tier: 'basic', until: 'tomorrow' })).status, 400);
    assert.equal((await admin.post('/api/admin/patrons', { emails: Array.from({ length: 51 }, (_, i) => `u${i}@example.com`), tier: 'basic' })).status, 400);

    assert.equal((await admin.post('/api/admin/patrons', { emails: ['A@Example.com', 'a@example.com', 'g@example.com'], tier: 'basic', note: 'ko-fi' })).json.added, 2);
    await admin.put('/api/admin/patrons/g%40example.com', { tier: 'gold', hideWall: true });
    const list = await admin.get('/api/admin/patrons');
    assert.equal(list.json.summary.total, 2);
    assert.equal(list.json.summary.active, 2);
    assert.equal(list.json.patrons.find((p) => p.email === 'g@example.com').tier, 'gold');
    assert.equal((await admin.put('/api/admin/patrons/ghost%40example.com', { tier: 'gold' })).status, 404);

    const csv = await admin.get('/api/admin/patrons/export');
    assert.equal(csv.status, 200);
    assert.match(csv.headers.get('content-type'), /text\/csv/);
    const lines = csv.text.trim().split('\r\n');
    assert.equal(lines[0], '"email","display_name","minecraft_username","tier","since","until","active","cosmetics"');
    const gold = lines.find((l) => l.startsWith('"g@example.com"'));
    const basic = lines.find((l) => l.startsWith('"a@example.com"'));
    assert.match(gold, /Chat tag; =Gold trail/, 'gold gets both');
    assert.ok(basic.includes('Chat tag') && !basic.includes('Gold trail'), 'basic only gets the cosmetics for its tier');

    assert.equal((await admin.del('/api/admin/patrons/a%40example.com')).status, 200);
    assert.equal((await admin.del('/api/admin/patrons/a%40example.com')).status, 404);
    const actions = app.store.listAudit(50).map((e) => e.action);
    for (const a of ['patron.grant', 'patron.update', 'patron.remove', 'patron.export']) assert.ok(actions.includes(a), a);
  } finally { await app.close(); }
});

test('supporter profile and wall: validated, opt-in only, removed when hidden or expired', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    await saveSite(admin, supportSite());
    await admin.post('/api/admin/patrons', { emails: ['p@example.com', 'q@example.com'], tier: 'gold' });
    const p = await asMember(app, 'p@example.com');
    const q = await asMember(app, 'q@example.com');
    assert.equal((await app.client().get('/api/me/profile')).status, 401);

    assert.equal((await p.put('/api/me/profile', { mcUsername: 'no spaces!' })).status, 400);
    assert.equal((await p.put('/api/me/profile', { mcUsername: 'ab' })).status, 400);
    assert.equal((await p.put('/api/me/profile', { mcUsername: 'Steve_1', displayName: '<b>x</b>' })).status, 400);
    assert.equal((await p.put('/api/me/profile', { mcUsername: 'Steve_1', wallOptIn: true })).status, 400, 'the wall needs a display name');
    const ok = await p.put('/api/me/profile', { mcUsername: 'Steve_1', displayName: 'Steve', wallOptIn: true });
    assert.equal(ok.status, 200);
    assert.equal(ok.json.patron.tier, 'gold');
    assert.equal(ok.json.patron.earlyAccess, true);
    await q.put('/api/me/profile', { mcUsername: 'Alex_2', displayName: '=SUM(1)', wallOptIn: false });

    let wall = (await app.client().get('/api/patrons/wall')).json.wall;
    assert.deepEqual(wall, [{ name: 'Steve', tier: 'Gold' }], 'only opted-in supporters, and no emails');
    await admin.put('/api/admin/patrons/p%40example.com', { hideWall: true });
    assert.equal((await app.client().get('/api/patrons/wall')).json.wall.length, 0);
    await admin.put('/api/admin/patrons/p%40example.com', { hideWall: false, until: '2020-01-01' });
    assert.equal((await app.client().get('/api/patrons/wall')).json.wall.length, 0, 'expired supporters leave the wall');
    await admin.put('/api/admin/patrons/p%40example.com', { until: '' });
    assert.equal((await app.client().get('/api/patrons/wall')).json.wall.length, 1);
    const csv = await admin.get('/api/admin/patrons/export');
    assert.match(csv.text, /"Steve","Steve_1"/);
    assert.match(csv.text, /"'=SUM\(1\)"/, 'spreadsheet formulas in names are neutralised');
  } finally { await app.close(); }
});

test('site settings: about/support limits are enforced and defaults are valid', () => {
  const { normalizeSite, DEFAULT_SITE } = require('../src/validate');
  const base = normalizeSite(DEFAULT_SITE);
  assert.deepEqual(base.errors, []);
  assert.deepEqual(normalizeSite(base.value).value, base.value, 'normalising twice changes nothing');
  const tooMany = JSON.parse(JSON.stringify(DEFAULT_SITE));
  tooMany.support.tiers = Array.from({ length: 7 }, (_, i) => ({ name: `T${i}`, price: '$1', perks: [] }));
  assert.ok(normalizeSite(tooMany).errors.some((e) => /at most 6 tiers/.test(e)));
  const dupe = JSON.parse(JSON.stringify(DEFAULT_SITE));
  dupe.support.tiers = [{ name: 'Same' }, { name: 'Same' }];
  const ids = normalizeSite(dupe).value.support.tiers.map((t) => t.id);
  assert.equal(new Set(ids).size, 2, 'tier ids are made unique');
  const badDate = JSON.parse(JSON.stringify(DEFAULT_SITE));
  badDate.servers[0].publicOn = '31/12/2026';
  assert.ok(normalizeSite(badDate).errors.length > 0);
});

test('every public page, including the new ones, uses no inline scripts', () => {
  for (const f of ['about.html', 'support.html', 'profile.html']) {
    const html = fs.readFileSync(path.join(__dirname, '..', 'public', f), 'utf8');
    assert.ok(!/<script(?![^>]*\bsrc=)/i.test(html), f);
    assert.ok(!/\son[a-z]+\s*=/i.test(html), f);
  }
});

// ═══════════════════════ server problem reports ("is it down?" tracker) ═══════════════════════
test('problem reports: validated, de-duplicated, only for servers the visitor may see, and turn into a status', async () => {
  const app = await startApp();
  try {
    const admin = await asAdmin(app);
    await saveSite(admin, supportSite());
    const anon = app.client();
    assert.equal((await anon.post('/api/servers/report', { server: 'Survival', kind: 'explode' })).status, 400);
    assert.equal((await anon.post('/api/servers/report', { server: 'Nope', kind: 'down' })).status, 404);
    assert.equal((await anon.post('/api/servers/report', { server: 'Beta', kind: 'down' })).status, 404, 'a locked server cannot be reported (or discovered) by outsiders');
    assert.equal((await anon.post('/api/servers/report', { server: 'Staff', kind: 'down' })).status, 404, 'hidden servers either');

    const first = await anon.post('/api/servers/report', { server: 'survival', kind: 'down' });
    assert.equal(first.status, 201);
    const again = await anon.post('/api/servers/report', { server: 'Survival', kind: 'laggy' });
    assert.equal(again.status, 200);
    assert.equal(again.json.already, true, 'the same visitor cannot pile on within 15 minutes');

    let h = (await anon.get('/api/servers/health')).json;
    assert.deepEqual(h.servers.map((s) => s.name), ['Survival'], 'locked servers are not listed to outsiders');
    assert.equal(h.servers[0].state, 'ok', 'one report is not enough to change the status');
    assert.equal(h.servers[0].hours.length, 24);
    assert.equal(h.servers[0].reports24h, 1);

    const m1 = await asMember(app, 'm1@example.com');
    assert.equal((await m1.post('/api/servers/report', { server: 'Survival', kind: 'laggy' })).status, 201);
    h = (await anon.get('/api/servers/health')).json;
    assert.equal(h.servers[0].state, 'issues', 'two different people');

    for (const e of ['m2@example.com', 'm3@example.com']) {
      assert.equal((await (await asMember(app, e)).post('/api/servers/report', { server: 'Survival', kind: 'down' })).status, 201);
    }
    h = (await anon.get('/api/servers/health')).json;
    assert.equal(h.servers[0].down, 3);
    assert.equal(h.servers[0].state, 'issues');
    assert.equal((await (await asMember(app, 'm4@example.com')).post('/api/servers/report', { server: 'Survival', kind: 'down' })).status, 201);
    assert.equal((await anon.get('/api/servers/health')).json.servers[0].state, 'down');

    // early-access supporters can see and report the locked server
    await admin.post('/api/admin/patrons', { email: 'gold@example.com', tier: 'gold' });
    const gold = await asMember(app, 'gold@example.com');
    assert.deepEqual((await gold.get('/api/servers/health')).json.servers.map((s) => s.name), ['Survival', 'Beta']);
    assert.equal((await gold.post('/api/servers/report', { server: 'Beta', kind: 'down' })).status, 201);

    // admin view
    assert.equal((await anon.get('/api/admin/outages')).status, 401);
    assert.equal((await m1.get('/api/admin/outages')).status, 403);
    const o = (await admin.get('/api/admin/outages')).json;
    assert.ok(o.last24h.some((x) => x.name === 'Survival' && x.kind === 'down' && x.n === 4));
    assert.ok(o.recent.length >= 6);
    assert.ok(!JSON.stringify(o).includes('ip:'), 'no reporter identity is exposed');

    // old reports are cleaned up
    app.db.prepare('UPDATE outage_reports SET created_at = ?').run(Date.now() - 9 * 24 * 3600 * 1000);
    await (await asMember(app, 'm5@example.com')).post('/api/servers/report', { server: 'Survival', kind: 'down' });
    assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM outage_reports').get().n, 1);
  } finally { await app.close(); }
});

test('status page and new pages use no inline scripts', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'status.html'), 'utf8');
  assert.ok(!/<script(?![^>]*\bsrc=)/i.test(html));
  assert.ok(!/\son[a-z]+\s*=/i.test(html));
});

// ═══════════════════════ running directly on a server (no Docker, no proxy) ═══════════════════════
test('direct mode: config rules, built-in HTTPS, secure cookies, and no trusted proxy headers', async () => {
  const base = { NODE_ENV: 'production', SECRET_KEY: 'x'.repeat(40), PORT: '25569' };
  assert.throws(() => loadConfig({ ...base, APP_URL: 'http://104.254.222.120:25569' }), /https/, 'plain http is refused in production by default');
  assert.throws(() => loadConfig({ ...base, APP_URL: 'https://1.2.3.4:25569', TLS_CERT_FILE: 'a.pem' }), /both TLS_CERT_FILE and TLS_KEY_FILE/);
  assert.throws(() => loadConfig({ ...base, APP_URL: 'http://1.2.3.4:25569', TLS_CERT_FILE: 'a.pem', TLS_KEY_FILE: 'b.pem' }), /must start with https/);
  const plain = loadConfig({ ...base, APP_URL: 'http://104.254.222.120:25569', ALLOW_INSECURE_HTTP: '1' });
  assert.equal(plain.secureCookies, false);
  assert.equal(plain.trustProxy, 0, 'visitors connect directly, so X-Forwarded-For must not be trusted');
  assert.ok(require('../src/checks').checkInstallation(plain).some((r) => r.level === 'warn' && /unencrypted/.test(r.msg)));
  assert.equal(loadConfig({ ...base, APP_URL: 'https://example.com' }).trustProxy, 1, 'behind a proxy it still trusts one hop');

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'yuni-tls-'));
  const { makeCert } = require('../scripts/make-cert');
  const files = makeCert('127.0.0.1', dir);
  const https = require('node:https');
  const { createServer } = require('../src/server');
  const config = loadConfig({ ...base, APP_URL: 'https://127.0.0.1:25569', DATA_DIR: dir, HOST: '127.0.0.1',
    TLS_CERT_FILE: files.cert, TLS_KEY_FILE: files.key, ADMIN_EMAILS: OWNER });
  assert.equal(config.trustProxy, 0);
  fs.mkdirSync(config.downloadsDir, { recursive: true });
  const db = openDb(config.dbFile);
  const app = createApp({ config, db, log: false });
  const server = createServer(config, app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  try {
    const { port } = server.address();
    const get = (p, headers = {}) => new Promise((resolve, reject) => {
      https.get({ host: '127.0.0.1', port, path: p, ca: fs.readFileSync(files.cert), headers }, (res) => {
        let body = ''; res.on('data', (c) => { body += c; }); res.on('end', () => resolve({ res, body }));
      }).on('error', reject);
    });
    const home = await get('/');
    assert.equal(home.res.statusCode, 200);
    assert.match(home.res.headers['strict-transport-security'], /max-age/);
    // a forged X-Forwarded-For must not change who the app thinks the visitor is
    await get('/api/site', { 'X-Forwarded-For': '9.9.9.9' });
    assert.equal(config.trustProxy, 0);
    // the session cookie is Secure and uses the __Host- prefix on HTTPS
    app.store.createUser({ email: OWNER, passwordHash: await hashPassword(PASSWORD), verified: true });
    const login = await new Promise((resolve, reject) => {
      const req = https.request({ host: '127.0.0.1', port, path: '/api/auth/login', method: 'POST', ca: fs.readFileSync(files.cert),
        headers: { 'Content-Type': 'application/json', Origin: config.origin } }, (res) => { res.resume(); res.on('end', () => resolve(res)); });
      req.on('error', reject); req.end(JSON.stringify({ email: OWNER, password: PASSWORD }));
    });
    assert.equal(login.statusCode, 200);
    assert.match(String(login.headers['set-cookie']), /__Host-yuni_sid=.*; Secure/);
    // plain HTTP to the TLS port gets nothing useful
    await assert.rejects(fetch(`http://127.0.0.1:${port}/`));
  } finally {
    await new Promise((r) => server.close(r));
    app.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('/healthz: public, minimal, and reflects the database', async () => {
  const app = await startApp();
  try {
    const r = await app.client().get('/healthz');
    assert.equal(r.status, 200);
    assert.equal(r.json.ok, true);
    assert.equal(r.json.db, true);
    assert.ok(Number.isInteger(r.json.uptimeSec));
    assert.deepEqual(Object.keys(r.json).sort(), ['db', 'ok', 'uptimeSec'], 'reveals nothing else');
    assert.match(r.headers.get('cache-control'), /no-store/);
  } finally { await app.close(); }
});

test('make-cert: pure-Node self-signed certificates are valid for IPs, hostnames and IPv6', () => {
  const { makeCert } = require('../scripts/make-cert');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'yuni-cert-'));
  try {
    const ip = new crypto.X509Certificate(fs.readFileSync(makeCert('104.254.222.120', path.join(dir, 'a')).cert));
    assert.equal(ip.subject, 'CN=104.254.222.120');
    assert.ok(ip.checkIP('104.254.222.120') && !ip.checkIP('1.2.3.4'));
    assert.equal(ip.ca, false);
    assert.ok(ip.verify(ip.publicKey), 'signature is valid');
    const days = (new Date(ip.validTo) - new Date(ip.validFrom)) / 86400000;
    assert.ok(days > 360 && days < 370);
    const dns = new crypto.X509Certificate(fs.readFileSync(makeCert('example.com', path.join(dir, 'b')).cert));
    assert.ok(dns.checkHost('example.com'));
    const v6 = new crypto.X509Certificate(fs.readFileSync(makeCert('2001:db8::1', path.join(dir, 'c')).cert));
    assert.ok(v6.checkIP('2001:db8::1'));
    assert.throws(() => makeCert('bad host!', path.join(dir, 'd')), /IP address or hostname/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
